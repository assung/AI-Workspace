---
paths:
  - "**/*.tsx"
  - "**/*.ts"
  - "packages/design-system/src/**"
  - "src/explorations/**"
  - "src/app/**"
---

# UI 開發 + Tailwind + Token + Props 命名規則(path-scoped)

僅在編 `.tsx` / `.ts` 或 DS / explorations / app code 時 load。

## Public component vs Internal primitive canonical(SSOT,2026-05-23 user 拍板;**2026-06-06 refine 為 intent-based,retire 舊「空 render 測試」**)

**唯一判準 = 「DS 是否想讓 consumer 直接 import 來用它」(public-API intent)** —— **不是**「空 `<X/>` 能不能 render 出有意義 UI」。世界級實證:MUI Base 官方「**requiring composition and styling does NOT make something internal — these are explicitly public primitives**」;Atlassian Primitives(Box/Stack/Inline)/ Bootstrap input-group / Ant Space.Compact 皆 public 卻需 compose。

**Public**(consumer-facing):DS 想讓 consumer 直接用的東西,**包含**:(a) 成品元件 `<Button>` / `<Avatar>` / `<Dialog>` / `<DataTable>` / `<Select>`;(b) **組合 primitive —— consumer 把自己內容塞進去 / 自接 callback 才完整**:`<FieldControlGroup>`(塞 field controls = Bootstrap input-group idiom)/ `<ResizeHandle>`(接 drag math = VS Code/Figma resize idiom)/ `<ChromeHeader>`(自建 chrome header chrome,follow `header-canonical` anatomy = 對標 item-anatomy 的公開 anatomy primitive)/ `<ItemIcon>` `<ItemAvatar>`(row context 內 consumer 塞 icon/avatar 的公開 named slot —— item-anatomy.spec.md「Helper 程式化封裝」段 mandate consumer 必用 + root barrel 匯出;對齊 Material ListItemIcon/ListItemAvatar、Primer ActionList.LeadingVisual 公開 named-slot 模型;**row-context-scoped**:離開 row primitive 子樹無意義,如 Material ListItemIcon 離開 List 無意義)。**「需要 children / 接線 / 組合」是正常 public 用法,不是 internal**。判斷訊號:benchmark 對標 consumer-facing primitive / spec「何時用」是 consumer 場景 / 有 standalone 用法 / export 給 consumer。

**Internal primitive**:**主要給 DS 內部其他元件用;不進 root barrel front-door、consumer 不「直接裸用」——但 internal ≠ 禁用:consumer 可經 per-component subpath(`@qijenchen/design-system/{components,patterns}/<Dir>`)「另外包裝過 + 自行確認」後消費**(見下方「Root barrel front-door 排除」2026-06-05 user Q2 拍板 SSOT = 權威定義,取代舊「永遠不碰」絕對措辭 —— 2026-07-10 修此 spec-internal 矛盾,該矛盾曾誤導判定 `<MenuItem>`「consumer 不可用」)。Examples:`<SurfaceHeader/Body/Footer>`(只 Dialog 內部)/ `useOverflowItems` hook / `<RowSizeProvider>` `<ItemInlineAction(Button)>`(item-anatomy.tsx `@internal` 標記的 L3 row-size / inline-action primitive,經 MenuItem/Row 消費)。⚠️ `<ItemIcon>` / `<ItemAvatar>` **不是** internal —— 是 public 組合 primitive(見上方 (b);2026-07-14 修 stale drift:spec mandate + root barrel 匯出 + app template 實用四處一致 public,本行舊列法與其全牴觸)。判斷訊號:無 standalone consumer 直用場景 / 主要被其他 DS 元件 import / 是別元件的 sub-part/slot/chrome。**`isInternal` = 需 subpath + 包裝後才用(如 `<MenuItem>` 之於 nav row),非「禁止 consumer 使用」。**

**決策(verifiable)**:
- 問:DS 想讓 end-user 在自己 app 直接 import 並用它嗎(看 benchmark / 何時用 / 是否 export 給 consumer)?
  - YES(**即使需要 compose/wire**)→ **public**
  - 只有 DS 內部元件用、consumer 用 wrapper 不碰它 → **internal**
- ⚠️ **禁用舊「空 render 測試」當判準**(2026-06-06 retire):它把 composition primitive(`<FieldControlGroup>` 空 = 透明 div)誤判 internal。anchor:2026-06-06 我用機械測試(空 render / 0-current-usage / 需接線)連環誤判 FieldControlGroup·ResizeHandle 為 internal,user 抓「它明明是 Bootstrap input-group / VS Code resize 那種 consumer 直接用的 primitive」。**「現在 DS 自家沒用到」≠ internal**。
- **note(pattern guidance / anatomy 參照)**:`action-bar`(組合指南,**無 component**)、`item-anatomy`(anatomy 參照 doc)不是「元件」,不走本判準 —— 它們是**可見的設計參照 Pattern**(per `patterns/README.md` charter)。

**Folder + storybook canonical**:
- public:`components/<Name>/` OR `patterns/<name>/`(frontmatter 無 `internal: true`),storybook title `Design System/Components/<Name>/...` OR `Design System/Patterns/<Name>`
- internal:in-place `components/<Name>/` 或 `patterns/<name>/` + frontmatter `internal: true` / `- isInternal`(主路徑;現行 10 個 internal 單元全走 frontmatter,`components/Internal/<Name>/` folder 路線同樣支援但目前無住戶),storybook title `Design System/Internal/<Name>/...` OR `Design System/Internal Patterns/<Name>`(end-user 設計師 default 過濾掉,DS contributor 看 reference 用)
- export jsDoc 加 `@internal` marker(IDE intellisense 警示 end-user)
- **Root barrel front-door 排除(2026-06-05 dim-72 SSOT,user Q2 拍板)**:internal 元件/pattern **不進** `packages/design-system/src/index.ts`(root barrel = 直接 front-door),**只**經 per-component subpath `@qijenchen/design-system/{components,patterns}/<Dir>` 取用 —— 對應 user 原則「internal 要**另外包裝過 + 自行確認**才可用,不得直接 front-door 使用;public 才可直接用」。SSOT = spec frontmatter isInternal;機械 = `gen-design-system-barrel.mjs`(生成時自動排除)+ `--check`(current required CI / deterministic audit gate)。改 public/internal → 改 frontmatter 後重跑 generator。
  - **符號級 `@internal` 排除(2026-07-18 決策3)**:public 元件內個別 export 若帶 `/** @internal */` JSDoc tag(如 `ButtonGroupContext` / `floatingLayerClass` / `RowSizeProvider` / `ItemInlineAction(Button)` 等私有 context/helper/primitive),generator 亦排除出 root front-door(subpath `export *` 仍有,DS 內部 relative import 不受影響)。對齊 TS `stripInternal` / MUI `@ignore` / API-Extractor `@internal` release tag。**偵測鐵律**:`@internal` 必為 JSDoc(`/** */`)tag(行首),`//` line-comment prose 提及不算(否則自身 doc 提及兄弟 `@internal` 的 public 型別如 `FieldVariant` 會被誤殺)。加/移私有符號的 front-door 排除 → 改該 export 的 `@internal` marker 後重跑 generator。
  - **`export *` 來源同一條(2026-10-07)**:tokens / hooks / lib 走 `export *`,規則一樣 —— 符號標 `@internal` → 該模組改具名出口、排除它;**檔頭第一段 JSDoc 帶 `@internal` 且不貼著第一個 statement**(模組層,如 `lib/roving-list-keyboard.ts`)或每個出口都標 → 整個模組不進 root。tokens / hooks 另有 subpath;**lib 沒有 subpath**,排除後只剩 DS 內部相對 import。判定表 `scripts/test-gen-design-system-barrel.mjs`(CI 必跑,對照組 = 舊版產生器必紅)。

**對齊世界級**:Polaris 「Building blocks」(public) vs「layout primitives」(internal)/ Material UI `@mui/material`(public)vs `@mui/utils` `@mui/system`(internal hooks/primitives)/ Atlassian `@atlaskit/<component>`(public)vs internal `<unstyled>` primitives / Carbon turnkey components + internal utilities / Apple HIG「Presented controls」vs「implementation primitives」 共識。

## 建立 UI 前必讀

**先 `ls packages/design-system/src/{components,patterns}/`**。必查 spec:Tokens(`tokens/{color|typography|density|uiSize|layoutSpace|elevation|radius}/*.spec.md`)/ Row + List item(`item-anatomy.spec.md` Family 1+2 SSOT)/ Action bar / Overflow / Overlay(`patterns/{action-bar,horizontal-overflow,overlay-surface}/*.spec.md`)/ Field(`components/Field/*.spec.md`)。

**既有 primitive 優先消費**:命中既有 → 必消費不 hand-craft。**自我檢查**:icon+text 垂直 → `<Empty>`;橫向 row → `<MenuItem>` + slot(消費 item-anatomy);chrome header(toolbar / page top bar / panel 標題列)→ `<ChromeHeader>`(消費 header-canonical,讀其 spec + `Patterns/Header Anatomy` story);浮層 → `overlay-surface`;跨 OS 捲軸 → `<ScrollArea>`;鎖長寬比 → `<AspectRatio>`。完整對照 → `packages/design-system/ds-canonical/references/build-ui-canonicals.md`。

## UI 開發 4 條核心

必重用既有 `components/` / 必用 design tokens(禁硬寫色/字/間距/圓角)/ 建新 UI 前查 pattern / 用 `cn()`(`@/lib/utils`)合併 Tailwind class。

深度規則 → `packages/design-system/ds-canonical/references/ui-dev-rules.md`(slot 幾何 / Padding source / Icon size 3 層)。

**一句話 pointer**:
- 新 row 元件 → `patterns/element-anatomy/item-anatomy.spec.md`「自我檢查」
- 清 unused imports / export 異動後:`npm run build:lib`(型別證明;設計系統本庫的 `tsc -b` 不檢查 DS 原始碼,見 AGENTS.md 失敗記憶索引)→ grep `export {}` → `npm run storybook` → 互動驗
- Inline Action vs Button → item-anatomy.spec.md「Inline Action 設計規格」
- 陰影:必 `--elevation-*`;禁 `shadow-sm/md/lg/xl/2xl`
- 視覺容器 breathing:有邊界 → 必 inner padding

## Tailwind 5 條核心(每條過真實 bug,詳 `packages/design-system/ds-canonical/references/tailwind-gotchas.md`)

1. **CSS variable 必 `var()` 包覆** — `w-[var(--foo)]` 而非 `w-[--foo]`(v4 silent 失效)
2. **自訂 utility 必在 `lib/utils.ts` 註冊 group** — 否則 tailwind-merge 誤判 strip
3. **禁 `shadow-sm/md/lg` / `text-xs/sm/base` / 硬寫色值** — 用 `shadow-[var(--elevation-N)]` (N ∈ {100,200},+`-hover` 變體) / `text-body`
4. **禁 shadcn compat alias**(`bg-popover` / `text-muted-foreground` / `bg-accent` 等)— 用 direct token
5. **禁 primitive 色名作 utility**(`bg-neutral-3` / `text-blue-6`)— 用 semantic utility 或 `bg-[var(--color-blue-6)]`

## Token 命名 4 條硬規則

1. **對齊既有 family**(不孤立發明)— 詳 `tokens/color/color.spec.md`
2. **不混語義與色名**:Tag/Avatar 用 primitive(`var(--color-deep-orange-1)`);Button/Checkbox 用 semantic(`var(--error-subtle)`)
3. **新增語意色相**走 `tokens/color/color.spec.md`「新增語意色相流程」SSOT。本系統採 **Atlassian-style Semantic State Token**
4. **禁止**:籠統命名 / 孤立命名 / 自創縮寫 / Primitive 帶語意 / Semantic 帶色相 / Categorical 中間層(已廢除)

## 元件 Props 命名

**按「是什麼」命名,不按「在哪裡」命名**(Material Chip / Ant Tag idiom):
- slot 只接 icon → `startIcon` / `endIcon`(型別 `LucideIcon`,元件控尺寸)
- slot 接任意視覺 → 描述內容類型(`avatar`,型別 `ReactNode`)
- slot 是行為 → callback(`onDismiss`,元件渲染互動 + 樣式)
- ❌ 禁 `prefix` / `suffix` / `left` / `right` 當**內容插槽** prop(位置名不傳達本質)→ 用 `startIcon`/`endContent`。**例外**:值格式 affix 字串(`NumberInput.prefix='$'`)+ 結構 anatomy 詞彙合法,判準見 `packages/design-system/ds-canonical/references/props-naming.md`「prefix/suffix canonical」

**4 名關閉 / 移除 callback**(詳 `packages/design-system/ds-canonical/references/props-naming.md`):
`onClose` / `onDismiss` / `onRemove` / `onClear` 各有語意不合併。

**Badge 命名按放置**:`badge`(inline)/ `overlayBadge`(疊視覺重心 iconOnly)/ `badgeCount`(Avatar count)/ `status`(presence dot — Avatar / ProfileCard / PeoplePicker;另有 lifecycle value-set 用於 FileItem / FileUpload / ProgressBar,詳 `props-naming.md`)。

**Icon canonical**:Overflow `MoreVertical` / Breadcrumb ellipsis `MoreHorizontal` / Close `X` / 成功 `Check` / 警告 `TriangleAlert` / 資訊 `Info`。

## shadcn 元件規範

**結構**:每元件 `{name}.{tsx,spec.md,stories.tsx,anatomy.stories.tsx,principles.stories.tsx}`。tsx 用 forwardRef + cva + VariantProps + cn() + `{Component, componentVariants}` export。Import `@/design-system/components/{Name}/{name}`(無 barrel)。`npx shadcn add` 後**立刻 grep 移除 shadcn compat alias**。

**cva 適用**:className-only 差異 → cva;style 物件 → object map + `style={{}}`;不同 JSX 樹 → conditional rendering。

**元件不得自包全域 Provider**(Tooltip / Theme / Toast / Portal)— 由應用層統一設定。**判斷**:Context 是行為狀態(open / size)→ 可包;全域外觀配置(delay / theme / portal / variant defaults)→ 禁止。

**shadcn 目錄後續新增元件 vs DS 既有(2026-07-07 codify,anchor:Attachment vs FileItem)**:「遵循 shadcn 框架」= 結構 idiom(forwardRef / Slot / data-* / cva),**非**「必須消費目錄每個元件」。shadcn 是 copy-in scaffold 非 runtime 依賴——遷移無上游更新流入。目錄新增元件時二分:(a) 帶 primitive / behavior 增益(Radix core、新 interaction model)且 DS 無等價 → 走 `/new-component` 近親評估;(b) **純組合式且 DS 已有 Family-compliant 等價物 → 不換架構、不改名**(M23 禁外部覆蓋既有 canonical),只做 API 對照:值得的 state / pattern 逐項評估為 DS prop 演進(SSOT-affecting → ASK),該元件 spec 補 M22 benchmark 對照行 + known-gap 記錄。同類先例:Empty / Item(≈item-anatomy)/ Field / Spinner(≈CircularProgress)/ InputGroup(≈FieldControlGroup)。
