# 展示 Story Trait-Based Typology v2(2026-04-26)

世界級 DS(Polaris / Material / Atlassian / Ant / Carbon / Storybook 官方)的 Storybook story 結構**不是** category-based prescription(「button-likes 必有 5 stories」),是**trait-based**——元件依自身能力宣告 traits,required stories 由 trait 衍生。本 doc 是本 DS canonical typology v2,取代 v1 7-category。

對應 `packages/design-system/ds-canonical/rules/story-rules.md`「拆分原則」+ M8 world-class benchmark。

## 為什麼 v2 trait-based(取代 v1 category-based)

v1 7 categories(A 視覺 variant / B field control / C selection / D structural / E scenario / F media / G internal)在實踐中暴露 4 盲點:
1. **Over-engineered**:A 要求 ≥5 stories 比 Carbon 整 component 還多
2. **Switch 一刀切**:C 要求 group stories,但 Material/Polaris/Carbon 的 Switch 全是 standalone(對齊 single-toggle idiom)
3. **Scope-N/A 沒寫**:Toast 沒 size 軸,A 卻硬要 AllSizes
4. **G 不該定 required stories**:Internal 是 DS visibility governance,不是 story shape

**M8 benchmark 證據**(2026-04-26 raw source 掃 5 系統):
- **Carbon Button**:10 stories,disabled/sizes 走 args(Controls)
- **Polaris Button**:24 stories(variant × tone matrix,但 sizes 散在 per-variant)
- **MUI Button**:18 example files,trait-driven(BasicButtons / OutlinedButtons / IconLabelButtons / LoadingButtons)
- **Ant Button**:22 demos,one demo = one focused trait
- **Storybook 官方**:推薦把代表性 baseline 放前面 + CSF3 args,**不 prescribe exact export name、count or required set**
- **共識**:每個 showcase 至少一個 reader-facing 代表範例；`Default` 只有在 minimal baseline 本身值得獨立存在時才用 / `WithIcon` merged grid 不拆 / overlay default-open `useState(true)` / Disabled 多數有但非絕對 / scenarios 多寡看 component 性質

→ trait-based 對齊 5/5 benchmark systems(M8 ≥ 3 ✓ overshot)。

## Trait-based core canonical

### Universal(每元件必有)

- **至少一個 reader-facing representative story** — export 名按它真正教的情境命名；`Default` 是可選名稱，不是 compliance token。只有最小 baseline 能獨立教會讀者時才開 `Default`，否則由第一個完整 scenario／matrix 擔任代表範例。

### Conditional traits → required stories

元件在 **spec.md frontmatter** 的 `traits: [...]` 宣告,`scripts/compile-stories.mjs` + hook 會驗證 required stories 齊全:

| Trait | 何時宣告 | Required stories(traits 觸發後必有) |
|-------|---------|----------------------------------|
| `hasVariants` | ≥ 2 visual variants(primary/secondary/danger 等) | `AllVariants` 對照 grid,**或** ≥ 2 個 per-variant exports |
| `hasSizes` | ≥ 2 sizes(sm/md/lg 等) | `AllSizes` merged grid(❌ 禁止 per-size 拆 `Small`+`Medium`+`Large`) |
| `hasInteractiveStates` | hover / focus / disabled / loading 任一可見 | `Disabled` own story(`Loading` 視 prop / `Error` 視 validation 而定) |
| `isOverlay` | Dialog / Sheet / Popover / Tooltip / Drawer 類 portal-rendered | `OpenSnapshot` story(`defaultOpen` / `useState(true)` 對齊 M15)+ ≥ 3 業務 scenarios |
| `isInputLike` | text / number / search / textarea field | `WithError` + `WithHelpText` + `WithIcon` merged grid |
| `isSelectionMulti` | Checkbox / Radio / 多選 toggle | `States`(checked/unchecked/indeterminate/disabled)+ `VerticalGroup` + `Disabled`(group level) |
| `isSelectionSingle` | Switch / 單一 toggle(無群組概念) | `States` only(對齊 Material/Polaris/Carbon Switch idiom — 無 group story) |
| `isMatrixHeavy` | Avatar / Skeleton / Spinner / Badge / Slider 等 token × size 正交視覺軸 | ≥ 4 matrix stories(`Modes` / `Shapes` / `Colors` / `AllSizes` 任 4) |
| `isStructural` | DataTable / Steps / Tabs / Accordion 結構主導 | 每結構變體 1 story(無固定數,過 earn-existence) |
| `isInternal` | L3 building block(被其他元件消費) | 1 個代表性 primitive story + ≤ 1 composition scenario(寬鬆,Internal/ 命名空間下；不強迫命名 `Default`) |

### Optional universal

- 1+ `RealScenario` story(Jira / Stripe / Notion / Figma / Slack / Gmail 真實業務情境),**過 earn-existence 2 test 才開**:
  - Q1:教別 story 沒教的原則?
  - Q2:移除後 spec 理解 degrade?
  - 兩題皆 NO → retire 候選

## Typical story counts(對齊 Carbon / Polaris median)

| 元件類型 | Stories range | 對照 |
|---------|---------------|------|
| L1 minimal(Switch / Skeleton)| 1-3 | Carbon Checkbox 5 |
| L1 standard(Button / Input)| 4-8 | Carbon Button 10 |
| Overlay(Dialog / Sheet)| 6-12 | Polaris Modal 16 / Ant Modal 17 |
| Matrix-heavy(Avatar)| 4-6 | Polaris Avatar 5 |
| Structural(DataTable)| 8-12 | (本 DS 11) |
| Internal primitive | 1-2 | Carbon hidden _PrefixedExport |

## Scope-N/A 例外子句

某 trait 在 spec.md「邊界案例 scope」明示 N/A → 該 trait required stories 跳過,不違反 typology:

- **Toast**:`hasSizes=false`(ephemeral notification 單尺寸)→ AllSizes 跳過
- **Coachmark**:`hasInteractiveStates=false`(無 disabled / loading 概念)→ Disabled 跳過
- **Skeleton**:`hasVariants=false`(只 default skeleton 形狀)→ AllVariants 跳過

**規則**:跳過 trait 時 spec.md 必明文 rationale(例「Toast 是 ephemeral notification,單尺寸對齊 Sonner / Polaris Toast idiom,無 size 軸」)。**禁止**默默 skip。

## How to use(寫 / audit story 時)

1. 該元件宣告哪些 traits?(讀 spec.md frontmatter `traits:` array)
2. 對照本 doc traits → required stories list
3. 缺哪個 → 補(若 spec.md 該 trait 真有效)
4. 多哪個 → 過 earn-existence 2 test;不過 → retire
5. **scope-N/A 例外**:該 trait 在 spec.md 明示 N/A → 跳過 OK,但 spec.md 必有 rationale

## 邊界 case

- **多 trait 元件**(e.g. Button = `hasVariants` + `hasSizes` + `hasInteractiveStates`)→ 各 trait required 都有
- **Family 跨界**(Field control 同時 isInputLike + hasInteractiveStates)→ Union of all traits
- **新 trait 提議**:跑 M8(≥ 3 家 DS benchmark)；若仍涉及 public component/UI
  semantics 真取捨才進 exact P2H checkpoint，工程 metadata／治理調整則 P2E AUTO。

## Typology 演進規則(對齊 user mandate「除非調整標準」)

本 typology 是 canonical SSOT。**禁止**單元件偏離不記 rationale。Typology 本身可演進,但流程:

1. 提案 invoke `/ensure-canonical` skill(M19 trigger)
2. 跑 M8 benchmark(≥ 3 家 DS)
3. 依 authority classifier 處理:P2E 自主決策；只有產品／UI／UX SSOT 真取捨才 exact P2H sign-off
4. 落地 5-layer pipeline(typology + hook + audit + scaffold + memory)

## Cross-link

- `packages/design-system/ds-canonical/rules/story-rules.md`「拆分原則」— canonical 上游 one-liner
- `/story-writing` SKILL.md Phase 0 — write-time mapping
- Hook `check_story_invariants.sh` R3 category — pre-write enforcement(攔不符 trait core)
- `/design-system-audit` Dim 29 — periodic verify
- `/new-component` Phase 5 — 新元件 trait-based scaffold
- `scripts/compile-stories.mjs` — runtime trait → required stories check

# Principles canonical(設計原則層,2026-04-26 加)

第三層 stories `{name}.principles.stories.tsx` 的 canonical structure。對齊 M8 benchmark(Polaris / Carbon / Ant 3 家 verifiable):

## 世界級對照

3 種哲學:
- **Carbon**(超嚴謹):~10 H2(`Overview / Formatting / Content / Universal behaviors / Modifiers / Related`)
- **Polaris**(中等):4 H2(`Best practices / Content guidelines / Related components / Accessibility`)
- **Ant**(極薄):1 H2(`When To Use`)

採 **Polaris-aligned 中等**(避免 Carbon-style 過細 + Ant-style 過薄)+ 接受既有 project naming(`VsXRule` 對齊 Carbon「X versus Y」)。

## Universal core(每元件 ≥ 1)— 2026-04-26 v3 整合

**重要**:WhenToUse + WhenNotToUse + VsXRule 都教「何時用 X」decision tree,**過度切割造成 noise**。對齊 Polaris/Material/Ant 共識(ONE integrated section),預設整合成單一 story。

| Story name(canonical)| 教什麼 | 世界級 anchor |
|---------------------|--------|---------------|
| **`UsageGuidance`**(預設,整合)| **何時用 + 何時不用 + 替代元件 / sibling comparison** 統一 decision tree | Polaris `Best practices` / Material `Usage` / Ant `When To Use`(共識) |
| `Vs{Sibling}Rule` | 視覺 deep-dive 對照(若需要 visual matrix 比較,deep-dive 才用)| Carbon `X versus Y` H3 |
| `ContentGuidelines` | 文案 do/don't(若元件 render 使用者文案)| Polaris `Content guidelines` H2 |

**判斷整合 vs split**:
- 對 80% 元件:**ONE `UsageGuidance`** 涵蓋 何時用 / 何時不用 / sibling 已足夠 — 對齊 Polaris/Material/Ant
- 對 20% 元件(超複雜 sibling matrix,如 Toast vs Alert vs Dialog):integrate 後加 `VsXRule` deep-dive(視覺 do/don't 對照,文字無法表達)
- `ContentGuidelines` 永遠獨立(文案 vs 元件選擇 是不同主題)

**Legacy aliases 接受**(不強制 rename 既存 stories):
- split style 必涵蓋至少 2 個不同 decision dimensions:`WhenToUse` / `WhenNotToUse` / `Vs*Rule` / `ContentGuidelines`
- 新元件預設用單一完整 `UsageGuidance`(何時用 + 何時不用 + sibling boundary)

**規則**:**ONE complete `UsageGuidance` is sufficient**。不得為了湊數再開第二篇；額外 principles story 只有在教 distinct topic 且通過 earn-existence 2-test 時才保留。若採 split style，至少需要 2 個不同 decision dimensions；任意兩個 implementation notes／視覺重演不能靠 export 數量取得 compliance。Audit `audit-content-quality.mjs` 與 hook `check_canonical_propagation.sh` E.1 同規則。 **使用指引的固定骨架(2026-10-20,補在同一行,不移動被引用的行號)**:`UsageGuidance` 的 story 名稱一律「使用指引」;`TutorialPage` 底下**依序剛好三段** `<UsageSection kind="when">` / `"whenNot"` / `"siblings"` —— 段名「何時用」/「何時不用」/「和相近元件怎麼選」只住在 `src/stories-helpers/examples/tutorial-page.tsx` 的 `USAGE_SECTION_TITLES`,各頁不手寫段名、不在段落外放前言。段裡放清單(`TutorialList`)或規則(`TutorialRule`);內容準則、尺寸、動態這類別的主題另開一則 story,不塞進使用指引(三段的世界級對照見上表「Universal core」)。出處:user 2026-10-20「你提的問題可以都照你建議」(主 session 轉達;對應教學頁稽核 T4 的建議甲)。上面的 split style(例:InlineEdit)照舊接受。機械:`scripts/tutorial-page-invariant.mjs` R9。

## Canonical naming(取代既有 drift 變體)

| 既有 drift 命名 | Canonical | Rationale |
|---------------|-----------|-----------|
| `Forbidden*` / `Donts` / `Pitfalls` / `Prohibitions` / `NonGoals` / `VisualDonts` | **`WhenNotToUse`** | Polaris/Carbon 共識用「When NOT to use」semantics |
| `UsageScenarioRule` / `WhatItIs` / `MvpScope` | **`WhenToUse`** | 對齊 Polaris/Carbon/Ant 三家 |
| `Vs{X}Rule`(`VsTabsRule` / `VsCheckboxRule` 等) | **保留**(對齊 Carbon `versus` idiom)| 已是世界級 |
| `{Topic}Rule`(其他 component-specific) | **保留**(過 earn-existence 即可)| 可選 component-specific 規則 |

## 可選 stories(過 earn-existence)

- `VariantDecision` — 元件 ≥ 3 variants 各自 semantic 不同(Button / Banner / Notification)時可加
- `CompositionRules` — 元件可 non-trivial 組合(Field family / ActionBar)時可加
- `AccessibilityNotes` — 非 mechanical a11y(mechanical 留 anatomy)
- 其他 component-specific `XRule` — 過 earn-existence 2-test

## 跟 anatomy / showcase 分權

| 該放 principles | 該放 anatomy | 該放 showcase |
|-----------------|--------------|---------------|
| Do/don't 視覺對照 | Token / size matrix | 真實場景 + variant grid |
| 跟近親元件比較 | Inspector 數值 | AllVariants / AllSizes |
| 何時用 / 不該用 | StateBehavior 視覺 | Disabled / Loading state demo |
| 文案 / 內容 guidelines | ColorMatrix | 業務 scenario 範例 |

**禁止**:do/don't 對照放 showcase(屬 principles)/ token table 放 showcase(屬 anatomy)/ 純 variant grid 無 rule 放 principles(屬 showcase)。

## 教學框的間距與標題(2026-10-01;段落層級 2026-10-14)

- **教學頁的版面只有一個住所** `src/stories-helpers/examples/tutorial-page.tsx`(2026-10-14):每則教學 story 以 `<TutorialPage>` 起頭,段落用 `<TutorialSection title>`,規則用每頁一行 `createTutorialRule({ examples: true, … })` 產出的 `<TutorialRule title note>`(規則的內容是範例 → 給 `examples: true`,走 `CaptionedExamples`,範例的說明一律 `ExampleCaption`;是一段文字 / 清單 → 不給)。不在各頁自定 Rule / Section(看結構不看名字:自己畫標題、再接內容的小元件就是,不論叫什麼)、不手寫 `<h2>` / `<section>`、不拿別的容器包規則或段落(包在下一層也一樣)、頁 / 段落裡的區塊不自帶上下 margin / padding、不放撐高度的空白塊(class 加 `sm:` / `[&>*+*]:` 前綴、寫成 `style` 都算)、不在 `TutorialPage` 放間距。範圍 = 全部設計原則頁(`*.principles.stories.tsx`)+ Patterns 文件頁的教學框 + **Tokens / Patterns 文件頁的段落**(2026-10-20 T7 甲:token 頁段落之間原本只剩 loose,與段落內同量級、段落分不開;`layoutSpace.spec.md` 規則 3 同步一句);產品範例與展示頁不套用。 **單一住所**(2026-10-20,教學頁稽核 T2 / T3 / T6):頁裡沒寫字級的內文 = `text-body`(`TutorialPage` 擁有,`typography.spec.md:39`;各頁不在頁根寫字級);範例說明 = `ExampleCaption`(`warn` = 反例);說明清單 = `TutorialList`(圓點 + 縮排 + 列距);跳到別則 story = `StoryLink`;使用指引三段 = `UsageSection`。各頁不自抄同功能的小元件。
- **規則 ↔ 規則 = 段落 ↔ 段落 = `--layout-space-loose` × 2**(md 32 / lg 48;`calc(var(--layout-space-loose) * 2)`,只寫在 tutorial-page.tsx):從 loose 推出,所以永遠是「範例組 ↔ 範例組」的兩倍、跟著密度走;**不借 `--layout-space-bottom`**(它的語意是 `layoutSpace.spec.md:13`「結論留白:內容到 action buttons」,值剛好可能一樣而已)。間距由外層 gap 一次給,各塊不留自己的下方 margin(頁尾不多空白)。出處:user 2026-10-07 原話「第一題照你建議」,採 AI 同日的建議 ②(規則之間 = 段落之間 = loose × 2、範例之間維持 loose、段落標題 text-h3 半粗體 + 淺分隔線、只用在教學頁、所有教學頁收成一個共用元件;待辦總帳 `governance/planning/2026-09-25-interaction-and-hover-remediation.md` P7 列)。
- **範例 ↔ 它的說明** = `--layout-space-tight`(`layoutSpace.spec.md` 規則 3 labeling);**範例組 ↔ 範例組** = `--layout-space-loose`。住所 `src/stories-helpers/examples/example-captions.tsx`:規則的範例區一律 `<CaptionedExamples>`(`createTutorialRule({ examples: true })` 已內建;說明元件 `ExampleCaption` 只有這一份,自動併進它說的範例),手寫的「樣本 + 說明」小格用 `<ExampleGroup>`;只有一則說明貼著一個樣本的單格,直接在說明上寫 `mb-` / `mt-[var(--layout-space-tight)]` 是同一個值。不在各頁自寫其他值或外框。 **對錯記號**只用 ✅ / ❌:寫在規則標題(這條規則是要 / 不要)或 `ExampleCaption`(這一則範例是對 / 錯);說明開頭的 ↑ / ← 指向它說的那則範例;清單項與手寫標題不帶對錯記號(要分對錯就拆成規則)。同一列「✅/❌ 符號 + 樣本 + 一兩個字」的行內群照 `example-captions.tsx` 不收。程式碼字樣用 `<code>`(canvas 不解析 Markdown,反引號會原樣顯示)。
- **教學框說明文字(Rule 的 note)** = `text-caption` + `text-fg-muted`(`color.spec.md`「文字 / Icon 層級」caption 列;2026-10-20 起不再逐頁選字色),行高用字級本身的 1.3,不疊 `leading-relaxed`(`typography.spec.md:50-53`「`text-caption`（12px）/ `text-footnote`（10px）：全部 lh 1.3 固定」)。
- **卡片 / 列裡「標題 ↔ 說明」**(同一個文字塊)= `--item-gap-label-desc-*`(`item-anatomy.spec.md`「Label ↔ Desc 間距」),不是 tight、不是寫死 4 / 8px。
- **標題**一律 `<h1>`–`<h6>` + DS 字級:**教學頁段落標題 = `<h2>` `text-h3`(24px)`font-semibold` + `border-divider` 淺分隔線**(`typography.spec.md` Token 表 text-h3「子區塊標題」—— 教學頁的段落就是頁裡的子區塊;同一個 ② 拍板);**規則標題 = `<h3>` `text-h6`(14px)`font-semibold`**;其餘教學框小標用 `text-h5`(16px)/ `text-h6`(`typography.spec.md:85-88`);範例裡的產品標題 `font-medium`;chrome 標題沿用 `text-body-lg font-medium`(header-canonical)。段落 / 規則標題由 tutorial-page.tsx 畫,各頁不手寫。
- 機械:`scripts/story-layer-drift-invariant.mjs`((b) 寫死間距 / (c) div 當標題 / (d) 不存在的字級或 DS 顏色、設計原則層寫死的任意字級 text-[Npx]);`scripts/tutorial-page-invariant.mjs`(教學頁繞過共用元件 —— 含 CSF2 函式 story、自抄 Rule / Section(看結構不看名字)、手寫段落 / 規則間距(margin / padding / 空白塊 / style,含前綴)、共用元件不再是 ② → 紅;2026-10-20 起另收 R9 使用指引骨架、R10 說明 / 清單 / 連結 / 對錯記號 / 反引號 / 範例自然寬度 / 工具列示範框(用 ChromeHeader,不手刻寫死高度的標題列)的單一住所、R11 空的範例區、R12 Tokens / Patterns 文件頁的手刻段落)。

## 強制機制

- **Hook** `check_canonical_propagation.sh` E.1 principles:PreToolUse 接受單一完整 `UsageGuidance`，split style 則攔少於 2 個 decision dimensions
- **Audit Dim 30**:periodic verify
- **`/new-component` Phase 5.3**:預設 scaffold 單一完整 `UsageGuidance`；只有 distinct topic 才加第二篇
