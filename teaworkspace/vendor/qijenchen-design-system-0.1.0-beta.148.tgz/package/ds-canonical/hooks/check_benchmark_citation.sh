#!/bin/bash
set -uo pipefail
# PreToolUse hook:阻止「沒 source citation 的 world-class benchmark claim」(對齊 M22)。
#
# Bug 史(2026-05-02):
#   AI 在 spec.md / tsx comment 寫「對齊 Ant Design」「Material 共識」「Polaris 派」
#   但沒附 source URL / screenshot / specific impl reference → 寫 code 時憑印象解讀,
#   常常**錯誤**(e.g., 我寫 Ant showTime range 是 2 calendar,實證是 1 calendar)。
#
# 機械化規則:
#   寫 spec / tsx 含 benchmark 關鍵詞 → 必同段含**至少一條** citation:
#     - Inline URL(`https://...` 包含 ant-design / material / polaris / atlassian / carbon / shadcn / radix-ui domain)
#     - GitHub issue / PR / source path(`#L42` line ref)
#     - Screenshot reference(`snapshots/...`)
#     - Marked `@benchmark-unverified`(顯式撤回)
#
# Component-spec zero-debt rule:
#   `packages/design-system/src/components/**/*.spec.md` may not add any benchmark escape.
#   Claims must either carry direct inline evidence or be rewritten as internal product rationale.
#
# 其他 scope 允許 escape:
#   檔頭加 `// @benchmark-citation-allow: <reason>` 整檔豁免(legacy,M22 hook 上線過渡期)
#   檔頭加 `// @benchmark-unverified-blanket: <reason>` 整檔 M22 (d) 撤回(file-level unverified)

source "$(dirname "$0")/_log-fire.sh" 2>/dev/null && log_hook_fire

set -euo pipefail

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // ""')
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // ""')

case "$TOOL" in
  Edit|Write|MultiEdit) ;;
  *) exit 0 ;;
esac

# Only spec.md / .tsx in design-system
case "$FILE_PATH" in
  */packages/design-system/src/**/*.spec.md|*/packages/design-system/src/**/*.tsx) ;;
  *) exit 0 ;;
esac

NEW_CONTENT=$(echo "$INPUT" | jq -r '
  (.tool_input.content // "") + "\n" +
  (.tool_input.new_string // "") + "\n" +
  ([.tool_input.edits[]? | .new_string] | join("\n"))
' 2>/dev/null || echo "")

grep -q '[^[:space:]]' <<<"$NEW_CONTENT" || exit 0

# Component specs are the public authoring contract and completed their D9 evidence-debt
# migration in beta.107. Do not allow either a per-claim retraction or a file-level bypass to
# recreate that debt. This intentionally runs before the legacy file-level allowlist below.
case "$FILE_PATH" in
  */packages/design-system/src/components/**/*.spec.md)
    if grep -qE '@benchmark-unverified([^-[:alnum:]]|-blanket:)|@benchmark-citation-allow:' <<<"$NEW_CONTENT"; then
      cat >&2 <<EOF

┄┄┄┄ check_benchmark_citation — component spec benchmark evidence debt ┄┄┄┄

[P0 BLOCKER] ${FILE_PATH}
Component specs are a zero-debt scope: \`@benchmark-unverified\`,
\`@benchmark-unverified-blanket\`, and \`@benchmark-citation-allow\` are forbidden.

Keep the claim only with a direct inline primary-source citation that supports it;
otherwise remove the external comparison and state the DS-internal product rationale.
EOF
      exit 2
    fi
    ;;
esac

# File-level allowlist
FIRST_LINES=$(printf '%s\n' "$NEW_CONTENT" | sed -n '1,5p')
if grep -qE '@benchmark-citation-allow:|@benchmark-unverified-blanket:' <<<"$FIRST_LINES"; then
  exit 0
fi
if [ -f "$FILE_PATH" ]; then
  ON_DISK_FIRST=$(sed -n '1,5p' "$FILE_PATH" 2>/dev/null || true)
  if grep -qE '@benchmark-citation-allow:|@benchmark-unverified-blanket:' <<<"$ON_DISK_FIRST"; then
    exit 0
  fi
fi

# Detect benchmark claim keywords + check inline citation in same paragraph
# 用 perl -0777 slurp 比 awk simpler;每個含 benchmark keyword 的「段」(連續非空行)
# 必含 citation evidence。
# 缺 perl = 這道 M22 防線無法判 → 明確 BLOCK,不得靜默放行(fail-closed;cloud 前提宣告)。
if ! command -v perl >/dev/null 2>&1; then
  echo '🚨 check_benchmark_citation: required interpreter perl is unavailable — M22 citation gate cannot run(fail-closed)' >&2
  exit 2
fi
VIOLATIONS=$(printf '%s' "$NEW_CONTENT" | perl -0777 -ne '
  my $bench = qr/(Ant Design|Material(\s+X|\s+Design|\s+UI|\s+3)?|Polaris|Atlassian|Carbon|shadcn|Radix UI?|Apple HIG|Notion|Airtable|ClickUp|Figma|Linear)/;
  my $cite = qr/(https?:\/\/(www\.)?(m3\.material|ant-design|material|polaris\.shopify|atlassian\.design|carbon|shadcn|ui\.shadcn|radix-ui|github|developer\.apple)|#L\d|snapshots\/|@benchmark-unverified)/;
  # Iterate paragraphs(separated by blank lines)
  for my $para (split /\n\s*\n/) {
    next unless $para =~ $bench;
    # Skip paragraphs that ARE source citations(URL line itself)
    next if $para =~ /^\s*[\*-]?\s*https?:\/\//;
    # Has citation? OK
    next if $para =~ $cite;
    # Violation:claim 但沒 cite
    my $first_line = (split /\n/, $para)[0];
    print "  - " . substr($first_line, 0, 80) . "...\n";
  }
'
)

if [ -n "$VIOLATIONS" ]; then
  cat >&2 <<EOF

┄┄┄┄ check_benchmark_citation — world-class benchmark claim 缺 source ┄┄┄┄

[P0 BLOCKER] ${FILE_PATH}
偵測到 benchmark claim 段缺 inline citation:
${VIOLATIONS}
M22 canonical(2026-05-02):**寫 spec / code 含「Ant / Material / Polaris / ...」claim 必附**:
  (a) Inline URL(domain 含 ant-design / material / polaris / atlassian / radix-ui / github 等)
  (b) GitHub source path + line ref(\`#L42\`)
  (c) Screenshot reference(\`snapshots/...\`)
  (d) 顯式撤回 \`@benchmark-unverified\`

歷史教訓(2026-05-02):
  - 我 claim「Ant showTime range = 2 calendars」憑印象 → 實證是 1 calendar,白忙一場
  - User: 「下次到底該如何完全避免你自己不斷說鬼話?」→ M22 + 本 hook

整檔豁免:
  - \`// @benchmark-citation-allow: <reason>\`(legacy 過渡期暫掛)
  - \`// @benchmark-unverified-blanket: <reason>\`(M22 (d) file-level 撤回)
EOF
  # P0 BLOCKER(2026-07-07 治理進化方向 2:對齊 user 2026-05-27 doctrine「SSOT canonical
  # 必 P0 BLOCKER 禁 P1 WARN」— escape 已備:@benchmark-unverified 逐句撤回 /
  # @benchmark-citation-allow / @benchmark-unverified-blanket 檔級,故升級不增誤殺)
  exit 2
fi

exit 0
