#!/bin/bash
# Tests for check_audit_post_report_validator.sh
#
# Hook(PostToolUse Write/Edit/MultiEdit):驗 audit report quality:
#   A) NO-SAMPLE keyword 偵測
#   B) matrix-derived full Dim coverage
#   C) audit-prompts.md prompt count
#   D) @benchmark-unverified-blanket count drift
#   E) prune-chain-trigger → emit additionalContext JSON
#
# 只 fire 在 file_path matches `*/audit-report-*.json` 或 `*/project_audit_progress.md`,
# 且 file 必須真實存在於 disk(`[ -f "$FILE_PATH" ] || exit 0`)。
# 輸出至 stdout(JSON additionalContext)時是 trigger_prune=1 路徑;非 prune trigger 走 silent。
# 注意:hook 內 WARNINGS 累積但 stderr 不直接 print(只 stdout JSON);此測試 verify stdout JSON。

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK="$SCRIPT_DIR/../check_audit_post_report_validator.sh"
TMPDIR_TEST=$(mktemp -d)
trap 'rm -rf "$TMPDIR_TEST"' EXIT
mkdir -p "$TMPDIR_TEST/.claude/logs"
mkdir -p "$TMPDIR_TEST/corpus/packages/governance/canonical" \
  "$TMPDIR_TEST/corpus/canonical/skills/design-system-audit/references" \
  "$TMPDIR_TEST/scripts"
cat > "$TMPDIR_TEST/scripts/verify-deep-audit-coverage.mjs" <<'EOF'
import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const rootIndex = process.argv.indexOf('--repo-root')
const root = rootIndex >= 0 ? process.argv[rootIndex + 1] : process.cwd()
const modePath = resolve(root, '.fixture-review-mode')
const mode = existsSync(modePath) ? readFileSync(modePath, 'utf8').trim() : 'missing'
if (mode === 'waived') {
  process.stdout.write(JSON.stringify({
    evidenceKind: 'deep-audit-coverage-verification',
    secondOpinion: 'waived-by-user',
    providers: { self: 'alpha', peer: null },
  }))
  process.exit(0)
}
if (mode === 'selected') {
  process.stdout.write(JSON.stringify({
    evidenceKind: 'deep-audit-coverage-verification',
    secondOpinion: 'completed',
    providers: { self: 'alpha', peer: 'beta' },
  }))
  process.exit(0)
}
process.exit(2)
EOF
cat > "$TMPDIR_TEST/corpus/packages/governance/canonical/providers.json" <<'EOF'
{
  "canonical": {"roots": {"skills": "canonical/skills"}},
  "providers": [
    {
      "id": "alpha",
      "displayName": "Alpha",
      "adapter": {"skillBindings": {"deep-audit-cross-codex": {
        "self": "alpha",
        "peer": "beta",
        "certificationContract": "exact-provider-runtime-surface-role-target-v1"
      }}}
    },
    {"id": "beta", "displayName": "Beta", "adapter": {"skillBindings": {}}},
    {
      "id": "future-author",
      "displayName": "Future Author",
      "adapter": {"skillBindings": {"deep-audit-cross-codex": {
        "self": "future-author",
        "peer": "nebula",
        "certificationContract": "exact-provider-runtime-surface-role-target-v1"
      }}}
    },
    {"id": "nebula", "displayName": "Nebula", "adapter": {"skillBindings": {}}}
  ]
}
EOF

# Model the provider-hook adapter boundary:the hook receives only a concrete peer
# resolved from a certified independent-review binding,never a guessed provider literal.
resolve_fixture_peer() {
  local self_provider="$1" resolved
  resolved=$(jq -cer --arg self "$self_provider" '
    . as $registry
    | first($registry.providers[] | select(.id == $self)) as $selfProvider
    | $selfProvider.adapter.skillBindings["deep-audit-cross-codex"] as $binding
    | select(
        $binding.self == $self
        and $binding.certificationContract == "exact-provider-runtime-surface-role-target-v1"
      )
    | first($registry.providers[] | select(.id == $binding.peer))
    | {id, displayName}
  ' "$TMPDIR_TEST/corpus/packages/governance/canonical/providers.json") || return 1
  export GOVERNANCE_SELF_PROVIDER="$self_provider"
  GOVERNANCE_PEER_PROVIDER=$(printf '%s' "$resolved" | jq -er '.id') || return 1
  GOVERNANCE_PEER_DISPLAY_NAME=$(printf '%s' "$resolved" | jq -er '.displayName') || return 1
  export GOVERNANCE_PEER_PROVIDER GOVERNANCE_PEER_DISPLAY_NAME
}

if [ ! -f "$HOOK" ]; then echo "FATAL: hook not found: $HOOK"; exit 1; fi

PASS=0
FAIL=0
FAILED_TESTS=""

run_hook() {
  local file_path="$1"; local tool="$2"
  local payload
  payload=$(jq -n --arg fp "$file_path" --arg tn "$tool" \
    '{tool_name: $tn, tool_input: {file_path: $fp}}')
  STDOUT=$(mktemp); STDERR=$(mktemp)
  set +e
  export GOVERNANCE_PROJECT_DIR="$TMPDIR_TEST"
  export GOVERNANCE_CORPUS_ROOT="$TMPDIR_TEST/corpus"
  export GOVERNANCE_READ_ONLY=1
  printf '%s' "$payload" | bash "$HOOK" >"$STDOUT" 2>"$STDERR"
  EXIT=$?
  set -e
  STDOUT_TEXT=$(cat "$STDOUT")
  STDERR_TEXT=$(cat "$STDERR")
  rm -f "$STDOUT" "$STDERR"
}

expect_silent() {
  local name="$1"
  if [ "$EXIT" = "0" ] && [ -z "$STDOUT_TEXT" ] && [ -z "$STDERR_TEXT" ]; then
    echo "  PASS  $name"; PASS=$((PASS+1))
  else
    echo "  FAIL  $name (exit=$EXIT, stdout=[$STDOUT_TEXT], stderr non-empty=$([ -n "$STDERR_TEXT" ] && echo yes))"
    FAIL=$((FAIL+1)); FAILED_TESTS="${FAILED_TESTS}\n  - $name"
  fi
}

expect_stdout_contains() {
  local name="$1"; local needle="$2"
  if [ "$EXIT" = "0" ] && echo "$STDOUT_TEXT" | grep -qF "$needle"; then
    echo "  PASS  $name"; PASS=$((PASS+1))
  else
    echo "  FAIL  $name (expected stdout contains '$needle', got exit $EXIT)"
    echo "  --- stdout ---"; echo "$STDOUT_TEXT" | sed 's/^/    /'; echo "  --- end ---"
    FAIL=$((FAIL+1)); FAILED_TESTS="${FAILED_TESTS}\n  - $name"
  fi
}

# 2026-05-31:Validator C/F/G critical fail 現 exit 2 真 block(原只 additionalContext soft)。
expect_block_stderr() {
  local name="$1"; local needle="$2"
  if [ "$EXIT" = "2" ] && echo "$STDERR_TEXT" | grep -qF "$needle"; then
    echo "  PASS  $name"; PASS=$((PASS+1))
  else
    echo "  FAIL  $name (expected exit 2 + stderr '$needle', got exit $EXIT)"
    FAIL=$((FAIL+1)); FAILED_TESTS="${FAILED_TESTS}\n  - $name"
  fi
}

expect_integrity() {
  local name="$1"; local needle="$2"
  if [ "$EXIT" = "70" ] && [ -z "$STDOUT_TEXT" ] \
    && echo "$STDERR_TEXT" | grep -qF "GOVERNANCE_INTEGRITY:" \
    && echo "$STDERR_TEXT" | grep -qF "$needle"; then
    echo "  PASS  $name"; PASS=$((PASS+1))
  else
    echo "  FAIL  $name (expected integrity exit 70 + '$needle', got exit $EXIT)"
    FAIL=$((FAIL+1)); FAILED_TESTS="${FAILED_TESTS}\n  - $name"
  fi
}

echo "=== check_audit_post_report_validator tests ==="

# 1. Non-audit file path → skip silently
run_hook "/tmp/random.txt" "Write"
expect_silent "1. non-audit path → skip"

# 2. Non-Write/Edit tool → skip silently
run_hook "$TMPDIR_TEST/.claude/logs/audit-report-foo.json" "Read"
expect_silent "2. Read tool → skip"

# 3. Audit-report path but file not on disk → skip
run_hook "$TMPDIR_TEST/.claude/logs/audit-report-missing.json" "Write"
expect_silent "3. missing file → skip"

# 4. project_audit_progress.md with NO-SAMPLE keyword but no audit-prompts.md → no prune trigger, silent stdout
mkdir -p "$TMPDIR_TEST/governance/memory"
cat > "$TMPDIR_TEST/governance/memory/project_audit_progress.md" <<'EOF'
# Audit progress
Dim 1: pass
Dim 2: pass
Dim 3: pass
EOF
run_hook "$TMPDIR_TEST/governance/memory/project_audit_progress.md" "Write"
# B fires (DIM_COUNT < matrix-derived total) but no TRIGGER_PRUNE since audit-prompts.md absent + no bench debt
# stdout should be silent (TRIGGER_PRUNE=0)
expect_silent "4. valid file no prune trigger → silent stdout"

# 5. judgment dim(dim 99 PURE-JUDGMENT)缺 `## 99.` prompt → Validator C CRITICAL → exit 2 真 block
#    (2026-05-31:原測 additionalContext soft;改測 set-membership C + exit-2 block)
mkdir -p "$TMPDIR_TEST/.claude/skills/design-system-audit/references" "$TMPDIR_TEST/generated/governance"
cat > "$TMPDIR_TEST/generated/governance/audit-coverage-matrix.json" <<'EOF'
{"coverage_by_dim":{"99":{"tier":"PURE-JUDGMENT","mechanism":"test judgment dim"}}}
EOF
cat > "$TMPDIR_TEST/corpus/canonical/skills/design-system-audit/references/audit-prompts.md" <<'EOF'
## 1. foo
prompt
EOF
# Poisoned generated Claude view claims dim 99 exists. Canonical authority must ignore it.
cat > "$TMPDIR_TEST/.claude/skills/design-system-audit/references/audit-prompts.md" <<'EOF'
## 1. foo
prompt
## 99. poisoned generated view
prompt
EOF
cat > "$TMPDIR_TEST/governance/memory/project_audit_progress.md" <<'EOF'
# Audit progress
Dim 1: pass
EOF
run_hook "$TMPDIR_TEST/governance/memory/project_audit_progress.md" "Edit"
expect_block_stderr "5. judgment dim 缺 prompt → Validator C exit-2 block" "VALIDATOR BLOCK"

# 6/7. Validator K:when review is required,a decision needs SSOT-check /
#    world-class cite / registry-resolved peer verdict / design-fit.
#    First satisfy Validator C so these cases isolate K.
cat > "$TMPDIR_TEST/corpus/canonical/skills/design-system-audit/references/audit-prompts.md" <<'EOF'
## 1. foo
prompt
## 99. test judgment dim
prompt
EOF
mkdir -p "$TMPDIR_TEST/.claude/logs/deep-audit-test"
resolve_fixture_peer alpha || {
  echo "FATAL:fixture lacks a concrete certified independent-review peer"
  exit 1
}
cat > "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
# Deep Audit 報告
Dim 1: pass

### 待你拍板
1. 決策一:Popover 內距是否改 12px
   - SSOT 理由:改跨元件 canonical 視覺結構
   - SSOT-check:grep spec + memory,無既有拍板
   - Beta verdict:agree(辯論共識)
   - 設計語言 fit:符合 density canonical
EOF
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_block_stderr "6. 決策缺世界級 cite → Validator K exit-2 block" "決策品質要件不全"

cat > "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
# Deep Audit 報告
Dim 1: pass

### 待你拍板
1. 決策一:Popover 內距是否改 12px
   - SSOT 理由:改跨元件 canonical 視覺結構
   - SSOT-check:grep spec + memory,無既有拍板
   - 世界級:Polaris https://polaris.shopify.com/tokens/space / Material / Ant(3 家)
   - Beta verdict:agree(辯論共識)
   - 設計語言 fit:符合 density canonical
EOF
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
if [ "$EXIT" = "0" ]; then
  echo "  PASS  7. 四要件齊 → Validator K pass(exit 0)"; PASS=$((PASS+1))
else
  echo "  FAIL  7. 四要件齊 → Validator K pass (expected exit 0, got $EXIT, stderr=[$STDERR_TEXT])"
  FAIL=$((FAIL+1)); FAILED_TESTS="${FAILED_TESTS}\n  - 7. 四要件齊 pass"
fi

# 8. The independent-review requirement follows the registry-resolved peer,
#    not a provider literal baked into the validator.
cat > "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
# Deep Audit 報告
Dim 1: pass

### 待你拍板
1. 決策一:Popover 內距是否改 12px
   - SSOT 理由:改跨元件 canonical 視覺結構
   - SSOT-check:grep spec + memory,無既有拍板
   - 世界級:Polaris https://polaris.shopify.com/tokens/space / Material / Ant(3 家)
   - Nebula verdict:agree
   - 設計語言 fit:符合 density canonical
EOF
resolve_fixture_peer future-author || {
  echo "  FAIL  8. future peer fixture lacks a certified registry binding"
  FAIL=$((FAIL+1)); FAILED_TESTS="${FAILED_TESTS}\n  - 8. future peer fixture binding"
}
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
if [ "$EXIT" = "0" ]; then
  echo "  PASS  8. future peer verdict satisfies the same four requirements"; PASS=$((PASS+1))
else
  echo "  FAIL  8. future peer was coupled to a Codex literal (exit=$EXIT, stderr=[$STDERR_TEXT])"
  FAIL=$((FAIL+1)); FAILED_TESTS="${FAILED_TESTS}\n  - 8. future peer verdict"
fi

# 9. Report prose alone cannot authorize a waiver. The same receipt passes only
#    when the current immutable run verifier proves the exact one-run waiver.
unset GOVERNANCE_PEER_PROVIDER GOVERNANCE_PEER_DISPLAY_NAME
cat > "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
# Deep Audit 報告
Dim 1: pass
second opinion: waived by user

### 待你拍板
1. 決策一:Popover 內距是否改 12px
   - SSOT 理由:改跨元件 canonical 視覺結構
   - SSOT-check:grep spec + memory,無既有拍板
   - 世界級:Polaris https://polaris.shopify.com/tokens/space / Material / Ant(3 家)
   - 設計語言 fit:符合 density canonical
EOF
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_block_stderr "9. text-only user waiver → block" "Report 文字不是 second-opinion waiver authority"

printf 'waived\n' > "$TMPDIR_TEST/.fixture-review-mode"
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_silent "9b. immutable user-waived run → no peer context required"

printf 'selected\n' > "$TMPDIR_TEST/.fixture-review-mode"
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_block_stderr "9c. selected run cannot be waived by report prose" "Report 文字不是 second-opinion waiver authority"

printf 'tampered\n' > "$TMPDIR_TEST/.fixture-review-mode"
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_block_stderr "9d. tampered/missing active waiver proof → block" "Report 文字不是 second-opinion waiver authority"

printf 'waived\n' > "$TMPDIR_TEST/.fixture-review-mode"
cat > "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
# Deep Audit 報告
Dim 1: pass

### 待你拍板
1. 決策一:Popover 內距是否改 12px
   - SSOT 理由:改跨元件 canonical 視覺結構
   - SSOT-check:grep spec + memory,無既有拍板
   - 世界級:Polaris https://polaris.shopify.com/tokens/space / Material / Ant(3 家)
   - 設計語言 fit:符合 density canonical
EOF
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_block_stderr "9e. active waiver still requires explicit report receipt" "registry-resolved peer provider"

# 10. A general report with no decision and an explicit task-level receipt also
#     has no peer dependency.
cat > "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
# Scoped Audit 報告
Dim 1: pass
second opinion: not required by task
EOF
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_silent "10. no-decision scoped report → no peer context required"

# 11. If the report does require independent review,it must carry the adapter's
#     registry-resolved peer context.
cat > "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
# Scoped Audit 報告
Dim 1: pass
second opinion: required
EOF
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_block_stderr "11. required review without peer → block" "registry-resolved peer provider"

# 12/13. A deep final report must close knowledge prune and governance coverage
#        in the same run. The recovery trigger is not a final-report receipt.
cat > "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
# Deep Audit 報告
Dim 1: pass
Dim 2: pass
Dim 3: pass
Dim 4: pass
Dim 5: pass
Dim 6: pass
Dim 7: pass
Dim 8: pass
Dim 9: pass
Dim 10: pass
A.1b story-vs-code: files scanned: 1; 0 findings
performance-audit: N/A; ux-audit: N/A; visual-audit: N/A
second opinion: waived by user
governance-coverage: same-run reconciled; unavailable telemetry = UNOBSERVED
EOF
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_block_stderr "12. deep final missing same-run prune receipt → block" "Same-run knowledge-prune receipt"

cat >> "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" <<'EOF'
knowledge-prune: same-run complete
EOF
run_hook "$TMPDIR_TEST/.claude/logs/deep-audit-test/C1-final-report.md" "Write"
expect_silent "13. deep final with all same-run receipts → pass"

echo ""
echo "=== Summary ==="
echo "Passed: $PASS / $((PASS + FAIL))"
if [ "$FAIL" -gt 0 ]; then
  echo "Failed:$FAILED_TESTS"
  exit 1
fi
