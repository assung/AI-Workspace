#!/bin/bash
# Field family unified invariant hook(2026-05-08 cluster A consolidation)
#
# Merges PreToolUse hooks(原各檔已 retire,合併入此)— 共 6 條 sub-rules:
#   A.1 naked row-mode propagation(原 check_naked_row_mode_propagation,P0 BLOCKER)
#   A.2 FieldControlGroup wrapper direct child(原 check_field_control_group_direct_child,P1 WARN)
#   A.3 Field state ring SSOT(原 check_field_state_token_consume 3 sub-rules,P0 BLOCKER)
#   A.4 disabled placeholder color(原 check_disabled_placeholder_color,P1 context)
#   A.5 _Group child fieldCtx.id 隔離(2026-05-31 折入,M4 AR34 regression detector,P0 BLOCKER)
#   A.6 空值顯示 SSOT(2026-07-08 user 拍板半形 hyphen,P0 BLOCKER)
#
# Why merge:皆 Field 家族 invariant,共用 INPUT parsing + Edit/Write filter pattern,
#   分散在 4 個 hook 是「散裝 SSOT」(M17 + Anthropic ≤ 15 hook best practice 違反)。
#
# Output precedence:BLOCK(2,stderr)> WARN(0,單一 governanceContext)> silent(0)。
#
# Per-rule allowlist(各自獨立):
#   A.1: `// @naked-row-mode-allow: <reason>`
#   A.2: `// @fcg-wrapper-allow: <reason>` 或檔頭
#   A.3: `// @field-state-ring-allow: <reason>`
#   A.4: `// @disabled-color-allow: <reason>`
#   A.5: `// @group-fieldctx-allow: <reason>`
#   A.6: `// @empty-display-allow: <reason>`

source "$(dirname "$0")/_log-fire.sh" 2>/dev/null && log_hook_fire

set -uo pipefail

_HOOK_CONTEXT_EVENT="PreToolUse"
_HOOK_OUTPUT_CAPTURE=$(mktemp "${TMPDIR:-/tmp}/check-field-family-invariants.XXXXXX") || {
  printf 'GOVERNANCE_INTEGRITY: field family invariants output capture unavailable\n' >&2
  exit 70
}
exec 3>&1 4>&2
exec >"$_HOOK_OUTPUT_CAPTURE" 2>&1

_finalize_hook_output() {
  _hook_rc=$?
  trap - EXIT
  exec 1>&3 2>&4
  _hook_output=$(cat "$_HOOK_OUTPUT_CAPTURE" 2>/dev/null || true)
  rm -f "$_HOOK_OUTPUT_CAPTURE" 2>/dev/null || true

  case "$_hook_rc" in
    0)
      [ -z "$_hook_output" ] && exit 0
      if ! jq -cn \
        --arg event "$_HOOK_CONTEXT_EVENT" \
        --arg message "$_hook_output" \
        '{governanceContext:{hookEventName:$event,message:$message}}'; then
        printf 'GOVERNANCE_INTEGRITY: field family invariants warning envelope encoding failed\n' >&2
        exit 70
      fi
      exit 0
      ;;
    2)
      if grep -q 'GOVERNANCE_INTEGRITY:' <<<"$_hook_output"; then
        printf '%s\n' "$_hook_output" >&2
        exit 70
      elif [ -n "$_hook_output" ]; then
        printf '%s\n' "$_hook_output" >&2
      else
        printf 'field family invariants hook blocked without diagnostic\n' >&2
      fi
      exit 2
      ;;
    70)
      if [ -n "$_hook_output" ]; then
        printf '%s\n' "$_hook_output" >&2
      else
        printf 'GOVERNANCE_INTEGRITY: field family invariants failed without diagnostic\n' >&2
      fi
      exit 70
      ;;
    *)
      printf 'GOVERNANCE_INTEGRITY: field family invariants undefined exit code %s\n' "$_hook_rc" >&2
      [ -n "$_hook_output" ] && printf '%s\n' "$_hook_output" >&2
      exit 70
      ;;
  esac
}
trap _finalize_hook_output EXIT

source "$(dirname "$0")/lib/_hook_integrity.sh" 2>/dev/null || {
  printf 'GOVERNANCE_INTEGRITY: hook integrity helper unavailable\n' >&2
  exit 70
}
governance_hook_load_input
TOOL=$(printf '%s' "$INPUT" | jq -r '.tool_name // ""' 2>/dev/null) \
  || governance_hook_integrity_fail 'field family tool extraction failed'
FILE_PATH=$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // ""' 2>/dev/null) \
  || governance_hook_integrity_fail 'field family path extraction failed'

# Tool filter — 只 Edit/Write/MultiEdit 跑
case "$TOOL" in
  Edit|Write|MultiEdit) ;;
  *) exit 0 ;;
esac

# 不是 .tsx / .ts 直接過(各 rule 內部還會再 narrow)
case "$FILE_PATH" in
  *.tsx|*.ts) ;;
  *) exit 0 ;;
esac

# 讀 merged content(舊檔 + 新 edit 拼起)— A.1 / A.3 需要整檔判 naked variant 存在性
FILE_CONTENT=""
if [ -e "$FILE_PATH" ] || [ -L "$FILE_PATH" ]; then
  FILE_PATH=$(governance_hook_project_file_path "$FILE_PATH" 2>/dev/null) \
    || governance_hook_integrity_fail 'field family target escapes the project or crosses a symlink'
  if [ -L "$FILE_PATH" ] || [ ! -f "$FILE_PATH" ] || [ ! -r "$FILE_PATH" ]; then
    governance_hook_integrity_fail 'field family target is unavailable or unsafe'
  fi
  FILE_CONTENT=$(cat "$FILE_PATH" 2>/dev/null) \
    || governance_hook_integrity_fail 'field family target read failed'
fi
NEW_CONTENT=$(printf '%s' "$INPUT" | jq -r '
  (.tool_input.content // "") + "\n" +
  (.tool_input.new_string // "") + "\n" +
  ([.tool_input.edits[]? | .new_string] | join("\n"))
' 2>/dev/null) || governance_hook_integrity_fail 'field family edit payload extraction failed'

# A.2 / A.4 只看 NEW_CONTENT(diff-level signal),A.1 / A.3 看 MERGED
MERGED_CONTENT="${FILE_CONTENT}
${NEW_CONTENT}"

grep -q '[^[:space:]]' <<<"$MERGED_CONTENT" || exit 0

WORST=0
record_worst() { local lvl=$1; [ "$lvl" -gt "$WORST" ] && WORST=$lvl; }

# ── A.1 naked row-mode propagation(P0 BLOCKER)─────────────────────────────────
case "$FILE_PATH" in
  *components/*.tsx)
    case "$FILE_PATH" in
      */field-wrapper.tsx|*/textarea.tsx) ;; # SSOT host skip
      *)
        if ! grep -q '@naked-row-mode-allow' <<<"$MERGED_CONTENT" \
           && echo "$MERGED_CONTENT" | grep -E "variant:\s*['\"]naked['\"]|variant=\{?['\"]naked['\"]" >/dev/null \
           && echo "$MERGED_CONTENT" | tr '\n' ' ' | grep -E "(inline-flex|flex)[^\"'\`]*items-center" >/dev/null \
           && ! grep -q "nakedCellRowModeAlign" <<<"$MERGED_CONTENT"; then
          cat >&2 <<EOF

┄┄┄ A.1 check_field_family_invariants — naked row-mode propagation BLOCKER ┄┄┄

[P0] ${FILE_PATH}
偵測到此檔消費 \`variant="naked"\` + 內部 wrapper hardcode \`items-center\`,
但**未** import / apply \`nakedCellRowModeAlign\` SSOT。

⚠️  M19 canonical:naked variant 元件所有內部 wrapper 必 propagate host cell
    \`data-row-mode\`(autoRow→items-start / fixed→items-center)。

修法:
  1. import { nakedCellRowModeAlign } from '@/design-system/components/Field/field-wrapper'
  2. wrapper className 加上 SSOT(eg \`cn('flex-1 min-w-0 inline-flex items-center', nakedCellRowModeAlign)\`)
  3. 例外:行尾 \`// @naked-row-mode-allow: <reason>\`

EOF
          record_worst 2
        fi
        ;;
    esac
    ;;
esac

# ── A.2 FieldControlGroup wrapper direct child(P1 WARN)────────────────────────
case "$FILE_PATH" in
  *.tsx)
    if grep -q '<FieldControlGroup' <<<"$NEW_CONTENT" \
       && ! grep -q '@fcg-wrapper-allow' <<<"$NEW_CONTENT"; then
      SUSPECT=$(printf '%s' "$NEW_CONTENT" | awk '
        /<FieldControlGroup/ { inFCG=1; next }
        /<\/FieldControlGroup>/ { inFCG=0; next }
        inFCG && /^[[:space:]]*<(div|span)[[:space:]>]/ {
          if ($0 !~ /display:[[:space:]]*contents/ && $0 !~ /@fcg-wrapper-allow/) print NR ":" $0
        }
      ')
      if [ -n "$SUSPECT" ]; then
        cat >&2 <<EOF

┄┄┄ A.2 check_field_family_invariants — FieldControlGroup wrapper WARN ┄┄┄

[P1] ${FILE_PATH}
偵測到 FieldControlGroup 內有 \`<div>\` / \`<span>\` wrapper(可能破壞 CSS \`[&>*]\` variants):
${SUSPECT}

修法 3 擇 1:
  1. 移除 wrapper,Field control 直接是 FieldControlGroup direct child
  2. 透過 prop forward className(eg \`<FilterValuePicker className="flex-1 min-w-0">\`)
  3. wrapper 用 \`display:contents\` / 加 \`// @fcg-wrapper-allow: <reason>\`

EOF
      fi
    fi
    ;;
esac

# ── A.3 Field state ring SSOT(P0 BLOCKER,3 sub-rules)─────────────────────────
case "$FILE_PATH" in
  *components/*.tsx)
    case "$FILE_PATH" in
      */field-wrapper.tsx|*/textarea.tsx|*.stories.tsx|*.test.*|*.spec.tsx) ;; # SSOT/test skip
      *)
        if ! grep -q '@field-state-ring-allow' <<<"$NEW_CONTENT"; then
          # A.3.1 舊 box-shadow inset
          if echo "$NEW_CONTENT" | grep -E "(hover|focus-within|data-\[state=open\]):shadow-\[inset" >/dev/null; then
            cat >&2 <<'EOF'

┄┄┄ A.3.1 check_field_family_invariants — Field state ring shadow inset BLOCKER ┄┄┄

[P0] naked variant state ring 用 `box-shadow inset` — v9 retire pattern。
修法:讓 Field default state machine 自動繼承(border-based);cell hover 用 `nakedCellEditableDisplayHover` const。

EOF
            record_worst 2
          fi
          # A.3.2 自寫 outline state ring
          if echo "$NEW_CONTENT" | grep -E "(hover|focus-within|focus-visible|data-\[state=open\]):outline-(border|primary)" >/dev/null; then
            cat >&2 <<'EOF'

┄┄┄ A.3.2 check_field_family_invariants — Field state ring outline BLOCKER ┄┄┄

[P0] 自寫 `hover:outline-border` / `focus-within:outline-primary` — v13 canonical 禁。
修法:Field default 自動繼承 / cell 用 `nakedCellEditableDisplayHover` const。

EOF
            record_worst 2
          fi
          # A.3.3 per-control open=blue override(v13.5)
          # 2026-06-11 deep-audit R2(n=38)精準化(M7 broad-vs-narrow 3-column):
          #   Spec wording:v13.3 禁「open 時 per-control 把 border 轉 primary(藍)」。
          #   Hook regex(舊):substring 無 boundary + 不分註解行。
          #   Gap:誤命中 (a) `data-[state=open]:border-primary-hover` canonical(button.tsx:99,109
          #     overlay trigger 維持 hover 樣式,-hover/-active 是合法 token 後綴);(b) v13.3 retire
          #     註解內引用舊 pattern 文字(combobox.tsx:725 / select.tsx:594)。
          #   修:純註解行剝離 + border-primary 加字尾 boundary([^-a-zA-Z]|$)。
          #   DS-wide counter-example scan 2026-06-11:新 regex 全 components/ 0 hit(真違規 shape
          #   `open && 'border-primary'` / `data-[state=open]:border-primary` 結尾 仍 BLOCK,fixture 驗證)。
          A33_CONTENT=$(echo "$NEW_CONTENT" | grep -vE '^[[:space:]]*(//|\*|/\*)')
          if echo "$A33_CONTENT" | grep -E "(open|isOpen) +&& +.{0,40}('border-primary'|\"border-primary\")" >/dev/null \
             || echo "$A33_CONTENT" | grep -E "data-\[state=open\]:border-primary([^-a-zA-Z]|$)" >/dev/null; then
            cat >&2 <<'EOF'

┄┄┄ A.3.3 check_field_family_invariants — per-control open=blue BLOCKER ┄┄┄

[P0] per-control `open && 'border-primary'` / `data-[state=open]:border-primary` — v13.3 canonical「focus dominates everything」禁。
修法:刪 override。Radix Popover open 時 trigger 通常 focused → focus-within fires → 藍(自然 Ant 風)。改 Field default SSOT 須 spec 補 rationale。

EOF
            record_worst 2
          fi
        fi
        ;;
    esac
    ;;
esac

# ── A.4 disabled placeholder color(P1 context,exit 0 不 block)─────────────────
if ! grep -q '@disabled-color-allow' <<<"$NEW_CONTENT"; then
  SUSPECT_DP=""
  if echo "$NEW_CONTENT" | grep -E "placeholder:text-fg-muted" >/dev/null \
     && ! echo "$NEW_CONTENT" | grep -E "(disabled:placeholder:text-fg-disabled|group-data-\[field-mode=disabled\].*placeholder:text-fg-disabled|resolvedMode\s*===\s*'disabled'.*text-fg-disabled)" >/dev/null; then
    SUSPECT_DP="$SUSPECT_DP [placeholder:text-fg-muted 無 disabled override]"
  fi
  if echo "$NEW_CONTENT" | tr '\n' ' ' | grep -E '<span[^>]*"text-fg-muted"[^>]*>[[:space:]]*\{[^}]*placeholder' >/dev/null 2>&1 \
     && ! echo "$NEW_CONTENT" | grep -E "resolvedMode\s*===\s*'disabled'" >/dev/null; then
    SUSPECT_DP="$SUSPECT_DP [<span text-fg-muted>{placeholder} 不分 mode]"
  fi
  if [ -n "$SUSPECT_DP" ]; then
    cat >&2 <<EOF

┄┄┄ A.4 check_field_family_invariants — disabled placeholder color WARN ┄┄┄

[P1] ${FILE_PATH}
${SUSPECT_DP}
修法:disabled:placeholder:text-fg-disabled / group-data-[field-mode=disabled]/field:placeholder:text-fg-disabled / JSX 條件
詳:tokens/color/color.spec.md「Disabled state precedence canonical」/ M24
例外:行尾 \`// @disabled-color-allow: <reason>\`

EOF
    # A.4 維持非阻擋 warning,由最外層聚合成 governanceContext。
  fi
fi

# ── A.5 _Group child fieldCtx.id 隔離(P0 BLOCKER,2026-05-31 折入,M4 AR34 regression detector)──
# M4:_Group 元件(CheckboxGroup/RadioGroup/SwitchGroup)的 child item 不可共用 fieldCtx.id —— 否則
# group 內所有 label 被抑制 + 點 label 只 toggle 第一個(AR34 root bug)。正解:item 在 group 內走自己
# 的 generatedId,不 fall back 到共用 fieldCtx.id。偵測 AR34 regression shape(MERGED 整檔,3-signal AND):
#   (1) 消費 *GroupContext  (2) bare `idProp ?? fieldCtx?.id ?? generatedId` fallback
#   (3) 缺 `insideGroup ? generatedId` / `inGroup ? generatedId` group guard
case "$FILE_PATH" in
  *components/*.tsx)
    if ! grep -q '@group-fieldctx-allow' <<<"$MERGED_CONTENT" \
       && grep -qE 'useContext\([A-Za-z_]*GroupContext\)' <<<"$MERGED_CONTENT" \
       && grep -qE 'idProp[[:space:]]*\?\?[[:space:]]*fieldCtx\?\.id[[:space:]]*\?\?[[:space:]]*generatedId' <<<"$MERGED_CONTENT" \
       && ! grep -qE '(insideGroup|inGroup)[[:space:]]*\?[[:space:]]*generatedId' <<<"$MERGED_CONTENT"; then
      cat >&2 <<EOF

┄┄┄ A.5 check_field_family_invariants — _Group child fieldCtx.id 隔離 BLOCKER ┄┄┄

[P0] ${FILE_PATH}
偵測到 _Group child item 消費 GroupContext + bare \`idProp ?? fieldCtx?.id ?? generatedId\` fallback,
但**缺** group guard(\`insideGroup ? generatedId\`)= M4 AR34 regression shape。

⚠️  M4 canonical:Group 內 item 不可共用 fieldCtx.id(否則所有 label 被抑制 + 點 label 只 toggle 第一個)。

修法:
  inputId = idProp ?? (insideGroup ? generatedId : (fieldCtx?.id ?? generatedId))
  即 group 內走自己的 generatedId,不 fall back 共用 fieldCtx.id。
  例外:行尾 \`// @group-fieldctx-allow: <reason>\`

EOF
      record_worst 2
    fi
    ;;
esac

# ── A.6 空值顯示 SSOT(P0 BLOCKER,2026-07-08 user 拍板半形 hyphen)────────────────
# user verbatim「我從頭到尾哪裡有說要用全形的」+ 五情境空值框架。SSOT:符號常數 =
#   field-wrapper.tsx `EMPTY_DISPLAY = '-'`(U+002D 半形);分流 hook = field-context.ts
#   `useFieldEmptyDisplay()`。禁 2 shape:
#   A.6.1 非 owner 檔直接 import `EMPTY_DISPLAY` 常數(應消費 hook 分流,否則 table-cell
#         editable→'' 分流會漏);
#   A.6.2 components/ tsx display 路徑 hardcode 全形 em dash `'—'`/`"—"`(U+2014)字面。
# M7 broad-vs-narrow:spec wording 廣(「禁 hardcode 空值符號」);hook 取「quoted em dash 字面」
#   高信號 subset + owner skip + comment 剝離 + `@empty-display-allow` escape,零誤判導向。
if ! grep -q '@empty-display-allow' <<<"$NEW_CONTENT"; then
  # A.6.1 非 owner 檔 import EMPTY_DISPLAY 常數(剝離註解行)
  case "$FILE_PATH" in
    */field-context.ts|*/field-wrapper.tsx) ;; # SSOT owner(定義 + 分流 hook)skip
    *)
      A61_CONTENT=$(echo "$NEW_CONTENT" | grep -vE '^[[:space:]]*(//|\*|/\*)')
      if printf '%s' "$A61_CONTENT" | grep -E "import.*EMPTY_DISPLAY|EMPTY_DISPLAY.*from" >/dev/null; then
        cat >&2 <<EOF

┄┄┄ A.6.1 check_field_family_invariants — EMPTY_DISPLAY 直引 BLOCKER ┄┄┄

[P0] ${FILE_PATH}
偵測到直接 import \`EMPTY_DISPLAY\` 常數(非 field-context.ts owner)。
空值顯示必經 \`useFieldEmptyDisplay()\` hook 分流(table-cell 可編輯→空白 / 其餘→半形 '-'),
直引常數會漏 surface × editable 分流。

修法:import { useFieldEmptyDisplay } from '@/design-system/components/Field/field-context'
      const emptyDisplay = useFieldEmptyDisplay()
例外:行尾 \`// @empty-display-allow: <reason>\`

EOF
        record_worst 2
      fi
      ;;
  esac
  # A.6.2 components/ tsx hardcode 全形 em dash 空值字面(剝離註解行 + owner/story skip)
  case "$FILE_PATH" in
    *.stories.tsx|*/field-context.ts|*/field-wrapper.tsx) ;; # doc N/A marker + SSOT owner skip
    *components/*.tsx)
      A62_CONTENT=$(echo "$NEW_CONTENT" | grep -vE '^[[:space:]]*(//|\*|/\*)')
      if printf '%s' "$A62_CONTENT" | grep -E "['\"]—['\"]" >/dev/null; then
        cat >&2 <<EOF

┄┄┄ A.6.2 check_field_family_invariants — 全形 em dash 空值 BLOCKER ┄┄┄

[P0] ${FILE_PATH}
偵測到 components/ 實作檔 hardcode 全形 em dash \`'—'\`(U+2014)字面。
user 2026-07-08 拍板:空值符號 = **半形 hyphen '-'(U+002D)**,禁全形。

修法:空值一律 \`{value ?? emptyDisplay}\`(emptyDisplay = useFieldEmptyDisplay()),不 hardcode 符號。
例外:行尾 \`// @empty-display-allow: <reason>\`

EOF
        record_worst 2
      fi
      ;;
  esac
fi

exit $WORST
