#!/bin/bash
# check_ds_anchor_preflight.sh — M29 mechanical enforcement(2026-05-26 backfill per user verbatim
# 「該程式化的都沒程式化,導致你他媽那麼容易便宜」+「未來其他人 fork 用其他元件也偏移」)。
#
# Purpose: PreToolUse Edit/Write/MultiEdit 偵測 production tsx wrap DS primitive
# (`<Sidebar>` / `<AppShell>` / `<DataTable>` / `<Dialog>` / `<Field>` 等)
# 沒同 turn 跑過 Grep / Read DS canonical baseline → P0 BLOCKER(exit 2,2026-07-07 治理進化方向 2 升級;
# escape GOVERNANCE_BYPASS_DS_ANCHOR=1 audit-logged),propose 前必出 3-column owner table。
#
# Scope:同 check_substantive_edit_approval_preflight.sh extended scope
#   - node_modules/@qijenchen/design-system/src/**.tsx (DS internal)
#   - apps/**.tsx (consumer fork-user code) ← M29 gap absorption(2026-05-26)
#   - node_modules/@qijenchen/design-system/** (禁改)
#
# Excluded: *.stories.tsx (story_invariants R7/R8 already cover) / *.test.tsx / *.spec.md.
#
# Why mechanical:M29 anchor preflight 在 meta-patterns.md 喊很久,5 個文件 reference but file 0,
# 結果 2026-05-26 product-workspace App.tsx mock-drift 沒被攔 → user 抓「肌肉沒長出來」。
# 本 hook 將「propose / write 視覺結構 前必 grep DS spec.md / canonical story」從 mindset 升 mechanical。
#
# Detection:scan transcript 過去 ~30 turns:
#   (a) 有 Grep / Read tool call hit `node_modules/@qijenchen/design-system/src/**/*.spec.md` OR
#       `**/*.stories.tsx`(canonical baseline) → PASS
#   (b) 無 → P0 BLOCKER(exit 2),並在 stderr 印出「grep canonical → 3-column owner table」的修法。
#
# 對齊 meta-patterns.md M29 「視覺/結構 propose 前必 grep DS spec.md 找 owner SSOT(M29)— 出 3-column 表」+
# `packages/design-system/ds-canonical/rules/self-verify.md` Pre-edit phase
# 「M29 3-column owner table」。

source "$(dirname "$0")/_log-fire.sh" 2>/dev/null && log_hook_fire
source "$(dirname "$0")/lib/_hook_integrity.sh" 2>/dev/null || {
  printf 'GOVERNANCE_INTEGRITY: hook integrity helper unavailable\n' >&2
  exit 70
}

set -uo pipefail
governance_hook_load_input
governance_hook_require_commands basename find grep paste sort tail
TOOL=$(printf '%s' "$INPUT" | jq -r '.tool_name // ""' 2>/dev/null) \
  || governance_hook_integrity_fail 'DS anchor tool extraction failed'
FILE_PATH=$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // ""' 2>/dev/null) \
  || governance_hook_integrity_fail 'DS anchor path extraction failed'
TRANSCRIPT_PATH=$(printf '%s' "$INPUT" | jq -r '.transcript_path // ""' 2>/dev/null) \
  || governance_hook_integrity_fail 'DS anchor transcript extraction failed'
EVENT=$(printf '%s' "$INPUT" | jq -r '.hook_event_name // ""' 2>/dev/null) \
  || governance_hook_integrity_fail 'DS anchor event extraction failed'

[ "$EVENT" != "PreToolUse" ] && exit 0
case "$TOOL" in Edit|Write|MultiEdit) ;; *) exit 0 ;; esac

# Scope:DS production code + consumer fork-user app code(不含 stories / spec / test)
case "$FILE_PATH" in
  */node_modules/@qijenchen/design-system/src/*.tsx) ;;
  */apps/*.tsx) ;;
  */node_modules/@qijenchen/design-system/*.tsx) ;;
  *) exit 0 ;;
esac

case "$FILE_PATH" in
  *.stories.tsx|*.test.tsx|*.spec.md|*.spec.ts) exit 0 ;;
esac

# Extract content being written/edited
NEW_CONTENT=$(printf '%s' "$INPUT" | jq -r '.tool_input.content // .tool_input.new_string // ""' 2>/dev/null) \
  || governance_hook_integrity_fail 'DS anchor content extraction failed'

# DS primitive 名單(wrap 這些就觸發 anchor preflight)
# 2026-07-16 dim 57 修 stale hardcode(含已改名 NameCard→ProfileCard、缺 InlineEdit 等 34 現役元件):
# 元件名改「機械生成」— 由 components/ dir 動態 ls 派生(hook 每 fire 跑一次 find,成本 <10ms 可接受),
# 新增/改名元件自動同步,不再靠人手維護清單。
# 非-dir primitive(patterns/ export + sub-component:MenuItem/Item* slots/TabsList/ChromeHeader/
# Surface*/OverlaySurface/ActionBar)無 dir 可派生 → 維護小清單於 _PATTERN_PRIMITIVES。
_COMPONENTS_DIR=""
for _root in "${GOVERNANCE_PROJECT_DIR:-}" "$(pwd)"; do
  if [ -n "$_root" ] && [ -d "$_root/node_modules/@qijenchen/design-system/src/components" ]; then
    _COMPONENTS_DIR="$_root/node_modules/@qijenchen/design-system/src/components"
    break
  fi
done
if [ -n "$_COMPONENTS_DIR" ]; then
  if [ -L "$_COMPONENTS_DIR" ] || [ ! -r "$_COMPONENTS_DIR" ]; then
    governance_hook_integrity_fail 'DS components registry directory is unavailable or unsafe'
  fi
  _COMP_NAMES=$(find "$_COMPONENTS_DIR" -mindepth 1 -maxdepth 1 -type d -exec basename {} \; 2>/dev/null | sort | paste -sd'|' -) \
    || governance_hook_integrity_fail 'DS component registry discovery failed'
fi
# 靜態 fallback(consumer fork repo 無 node_modules/@qijenchen/design-system/src/ → 用 snapshot;
# 與 DS repo components/ dir 同步,新增元件必補 — snapshot 2026-07-16,63 元件)
if [ -z "${_COMP_NAMES:-}" ]; then
  _COMP_NAMES='Accordion|Alert|AppShell|AspectRatio|Avatar|Badge|Breadcrumb|BulkActionBar|Button|Calendar|Carousel|Chart|Checkbox|Chip|CircularProgress|Coachmark|Combobox|Command|DataTable|DateGrid|DatePicker|DescriptionList|Dialog|DropdownMenu|Empty|Field|FieldControlGroup|FileItem|FileUpload|FileViewer|HoverCard|InlineEdit|Input|LinkInput|Menu|Notice|NumberInput|OverflowIndicator|Pagination|PeoplePicker|Popover|ProfileCard|ProgressBar|RadioGroup|Rating|ScrollArea|SegmentedControl|Select|SelectionControl|SelectMenu|Separator|Sheet|Sidebar|Skeleton|Slider|Steps|Switch|Tabs|Tag|Textarea|TimePicker|Toast|Tooltip|TreeView'
fi
_PATTERN_PRIMITIVES='MenuItem|ItemAvatar|ItemLabel|ItemIcon|TabsList|TabsTrigger|ChromeHeader|SurfaceHeader|SurfaceBody|SurfaceFooter|OverlaySurface|ActionBar'
DS_PRIMITIVES_RE="<(${_COMP_NAMES}|${_PATTERN_PRIMITIVES})\b"

# 沒 wrap DS primitive → 檢「純手刻」洞(2026-07-07 治理進化方向 3 洞 b:原本此分支直接放行,
# 「該用 primitive 卻整個手刻」反而抓不到 — 內部盤點 file:line 證據見 planning/2026-07-07-governance-evolution-roadmap.md)
if ! governance_hook_grep_q 'DS primitive registry matcher failed' "$NEW_CONTENT" -qE "$DS_PRIMITIVES_RE"; then
  # 視覺簽名:row/浮層/chrome 手刻特徵(flex row + padding/border/rounded/shadow 組合)
  governance_hook_grep_capture HANDCRAFT_SIG 'DS handcraft signature matcher failed' \
    "$NEW_CONTENT" -cE 'className="[^"]*\b(flex|absolute|fixed)\b[^"]*\b(border|rounded|shadow|px-|py-|gap-)'
  HANDCRAFT_SIG=${HANDCRAFT_SIG:-0}
  if [ "$HANDCRAFT_SIG" -ge 3 ] \
    && ! governance_hook_grep_q 'DS handcraft escape matcher failed' "$NEW_CONTENT" -q '@handcraft-ok:'; then
    MESSAGE=$(cat <<'EOF_HC'
⚠️ [第一期 WARN] M23(d)/mindset #2 純手刻嫌疑:本段 production tsx 有 ≥3 處視覺結構 className
   但零 DS primitive 消費。先查 patterns/(item-anatomy / overlay-surface / ChromeHeader /
   horizontal-overflow)有無現成 primitive;真需自建 → 行內 `@handcraft-ok: <rationale>` +
   spec「自建 + 理由」宣告。誤殺率驗證期後升 P0(roadmap 方向 3)。
EOF_HC
    )
    printf '{"governanceContext":{"hookEventName":"PreToolUse","message":%s}}\n' "$(printf '%s' "$MESSAGE" | jq -Rs .)"
  fi
  exit 0
fi

# A committed marker is deterministic evidence that every provider and CI can verify without a
# provider-private transcript. Native transcript inspection remains useful acceleration, but a null
# transcript (valid in Codex and some Claude surfaces) must never turn the hard rule into a no-op.
if governance_hook_grep_q 'DS story-baseline marker matcher failed' "$NEW_CONTENT" \
  -qE '@story-baseline:[[:space:]]*[^[:space:]]+'; then
  exit 0
fi

if [ "${GOVERNANCE_STATIC_REPLAY:-0}" = "1" ] || [ -z "$TRANSCRIPT_PATH" ]; then
  cat >&2 <<'EOF_STATIC'
🚨 M29 DS Anchor Preflight — deterministic evidence missing
DS primitive production code must contain `@story-baseline: <canonical-path>#<StoryName>` when no
provider transcript is available. Transcript-dependent advice is not counted as CI enforcement.
EOF_STATIC
  exit 2
fi

if [ -L "$TRANSCRIPT_PATH" ] || [ ! -f "$TRANSCRIPT_PATH" ] || [ ! -r "$TRANSCRIPT_PATH" ]; then
  governance_hook_integrity_fail 'supplied DS anchor transcript is unavailable or unsafe'
fi

# Scan last ~30 turns(~600 lines transcript)— 找 Grep/Read 對 DS spec.md / canonical story 的 trace
RECENT_TRANSCRIPT=$(tail -600 "$TRANSCRIPT_PATH" 2>/dev/null) \
  || governance_hook_integrity_fail 'DS anchor transcript read failed'
if ! printf '%s' "$RECENT_TRANSCRIPT" | jq -s -e 'all(.[]; type == "object")' >/dev/null 2>&1; then
  governance_hook_integrity_fail 'DS anchor transcript is malformed'
fi

# Pass condition(a):有 Grep tool call pattern hit spec.md / stories.tsx
CANONICAL_TRACE=$(printf '%s' "$RECENT_TRANSCRIPT" | \
  jq -r 'select(type == "object" and .message.content != null) |
    .message.content // empty |
    if type == "array" then
      (.[]? | select(.type == "tool_use") |
        select(.name == "Grep" or .name == "Read" or .name == "Glob") |
        .input | tostring)
    else empty
    end' 2>/dev/null) || governance_hook_integrity_fail 'DS anchor transcript query failed'
HAS_CANONICAL_READ=$(printf '%s' "$CANONICAL_TRACE" | \
  grep -cE 'node_modules/@qijenchen/design-system/src/.*\.(spec\.md|stories\.tsx)|stories\.tsx#' 2>/dev/null)
_GREP_RC=$?
if [ "$_GREP_RC" -gt 1 ]; then
  governance_hook_integrity_fail 'DS anchor canonical evidence matcher failed'
fi
HAS_CANONICAL_READ=${HAS_CANONICAL_READ:-0}

# Pass condition(b):AI 已 written 3-column owner table OR cite `@story-baseline:` marker
HAS_3COL_OR_MARKER=$(printf '%s' "$RECENT_TRANSCRIPT" | \
  grep -cE '@story-baseline:|owner spec|canonical sentence|3-column' 2>/dev/null)
_GREP_RC=$?
if [ "$_GREP_RC" -gt 1 ]; then
  governance_hook_integrity_fail 'DS anchor marker matcher failed'
fi
HAS_3COL_OR_MARKER=${HAS_3COL_OR_MARKER:-0}

# Pass: 有任一 canonical read OR 3-column marker → silent
if [ "$HAS_CANONICAL_READ" -gt 0 ] || [ "$HAS_3COL_OR_MARKER" -gt 0 ]; then
  exit 0
fi

# Override env var(audit-logged)
if [ "${GOVERNANCE_BYPASS_DS_ANCHOR:-0}" = "1" ]; then
  if STATE_DIR="$(governance_runtime_state_dir 2>/dev/null)"; then
    mkdir -p "$STATE_DIR" 2>/dev/null
    jq -nc --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" --arg file "$FILE_PATH" --arg tool "$TOOL" \
      '{ts:$ts,event:"ds-anchor-bypass",file:$file,tool:$tool}' >> "$STATE_DIR/governance-bypass.jsonl" 2>/dev/null || true
  fi
  exit 0
fi

REL_PATH=${FILE_PATH#"$GOVERNANCE_PROJECT_DIR"/}

# BLOCKER 訊息本體(hybrid:先印修法、再 exit 2;對齊 check_substantive_edit_approval_preflight.sh)
cat >&2 <<EOF
🚨 M29 DS Anchor Preflight — visual/structural edit 偵測

📁 File: $REL_PATH
🔧 Tool: $TOOL
🧩 偵測到 DS primitive 在 new content:wrap pattern

⚠️ 過去 ~30 turns 無 Grep/Read 對 \`node_modules/@qijenchen/design-system/src/**/spec.md\` 或
   \`*.stories.tsx\` baseline 的 trace,且未見 \`@story-baseline:\` marker 或 3-column owner table。

→ 這違反 M29 anchor preflight invariant + story-rules.md「Production-grade composition fidelity」。
→ 對 fork-user 後果:憑記憶寫 simplified mock(像 2026-05-26 App.tsx SidebarTrigger 漏 / collapsible 漏 / startIcon 漏)。

修法 — 2 選 1(對齊 check_substantive_edit_approval_preflight.sh hybrid):
  (a) 先 Grep / Read DS canonical:
        - \`node_modules/@qijenchen/design-system/src/<Component>/*.spec.md\`(找 owner SSOT)
        - \`node_modules/@qijenchen/design-system/src/<Component>/*.stories.tsx\`(找完整佈局 baseline)
      然後 inline 寫 3-column owner table(\`owner spec\` / \`canonical sentence\` / \`conflicting code\`)
      或加 \`// @story-baseline: <path>#<StoryName>\` marker 在檔頭。
  (b) Bypass:\`GOVERNANCE_BYPASS_DS_ANCHOR=1\` env var(audit-logged in governance-bypass.jsonl)
      僅當你**真的**已 Read canonical 但 transcript scan miss 時用,not 規則繞道。

對應 canonical:
  - \`packages/design-system/ds-canonical/rules/meta-patterns.md\` M29
  - \`packages/design-system/ds-canonical/rules/self-verify.md\` Pre-edit phase
  - \`packages/design-system/ds-canonical/references/ssot-index.md\` Step 0.1 high-risk interface owner mapping
EOF

# P0 BLOCKER(2026-07-07 治理進化方向 2:對齊 user 2026-05-27「SSOT canonical 必 P0 禁 soft」
# doctrine;bypass env GOVERNANCE_BYPASS_DS_ANCHOR=1 已備且 audit-logged,升級不增誤殺)。
exit 2
