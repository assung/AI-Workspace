<!-- @benchmark-cited: D5 retrofit 2026-05-18 — body claims marked per-claim @benchmark-unverified inline; 已驗證 claim 於原句 inline 附 @benchmark-cited URL(本檔為 token spec,無 YAML frontmatter benchmark list)。 -->

# Color 設計原則

> **Foundational SSOT rationale**(2026-04-24 approved,cap 1000 — 2026-05-22 raised 800→1000 per /knowledge-prune deep audit + `AGENTS.md`「行數預算」的 foundational SSOT 例外 ≤ 800-1200 range):
> Token 系統 SSOT,涵蓋 primitive / semantic 兩層色彩架構、disabled 兩策略、Hover/Active 公式推導、新增語意色相 4-step 流程、neutral interaction 雙 family、nested theme。跨 30+ 元件消費,改一 token 影響全 DS。218 行語義色定義是純 token structural canonical 無法 reference out;不可拆不失原則。

## 架構流派定位

業界四大世界級色彩 token 流派各有取捨。我們選擇 **Atlassian 流派**（semantic state token），並有意識地拒絕其他三個。理解這個選擇對日後維護至關重要。

| 流派 | 代表系統 | 互動狀態怎麼處理 | 為何不選 |
|------|---------|---------------|---------|
| **Numbered Role Scale** | Radix Colors | 12 step scale，每個 step 號碼本身就是 role（step-9=solid bg、step-10=solid hover），light/dark scale 各自獨立定義值 | 工程量極大——需要重新設計每個色相 × 12 step × 2 mode = 192 個值，且全部 consumer 改 step 號 |
| **Semantic State Token**（**我們**） | Atlassian DS、GitHub Primer | 互動狀態用 semantic token (`--{hue}-hover` / `--{hue}-active`)，每個 mode 預先計算值 | ✓ 選這個 |
| **State Layer Overlay** | Material Design 3([state layers](https://m3.material.io/foundations/interaction/states/state-layers)) | 互動狀態用透明 overlay（state layer），不改變底色 | 只拒絕**彩色 / 色相色的底**用疊層:改用疊層會跟 Button 用 solid shade change 的視覺語言不一致——同設計系統內互動回饋會分裂成兩種風格。中性色階半透明、低段可相加,疊一層等於往下一階,畫面不分裂;本 DS 只在「底」(`--canvas` / `--surface` / `--surface-raised`)上用疊層(`bg-interaction-hover` / `-active`),其餘中性填色(`--secondary`…)照換色,範圍見下方「Hover 換色配對總則」(2026-09-25 user 選「採用，底色不換、疊一層 (Recommended)」;這一條刻意偏離 Atlassian 的表面換色,[atlassian.design/foundations/elevation](https://atlassian.design/foundations/elevation)) |
| **Consumer-side Mode Handling** | Tailwind CSS | 由 consumer 自己處理 dark mode 變體 (`hover:bg-blue-600 dark:hover:bg-blue-400`) | Token 系統的價值就是封裝 mode 知識，把它推給 consumer 等於放棄抽象化 |

### 為什麼選 Atlassian 流派

1. **跟 Button 視覺語言一致**——Button 用 solid shade change（從 step-6 到 step-5/-7），其他飽和色 bg 互動也應該用 solid shade，而不是 overlay
2. **務實的工程量**——不需要重構整套 primitives
3. **封裝 mode 知識**——把 dark mode 翻轉的 swap 邏輯關進 semantic 層，consumer 不需知道
4. **跟 `--primary-hover/active` 同模式**——`--blue-hover/active` 是同一個概念延伸到所有作為 bg 的色相

### Tag 為什麼是「primitive 靜態 + semantic 互動」混合存取

這**不是 code smell，是有意的職責分離**：

| 概念 | 是否需要 mode 知識 | 該住哪一層 |
|------|------------------|----------|
| **靜態色值**（subtle bg、text、solid bg） | ❌ Primitives 公式翻轉已自動處理 | **Primitive**——直接 `--color-blue-1`、`--color-blue-7`、`--color-blue-6` |
| **實心色的互動狀態**(step-6 家族的 hover、active) | ✅ 需要保證「hover 永遠較亮、active 永遠較暗」 | **Semantic**——`--blue-hover`、`--blue-active` 內含 dark mode swap |
| **淡底的滑過**(step-1 → step-2) | ❌ 色階號碼 = 離所在底色多遠,兩個主題同向(淺色更深、深色更亮;本檔「Dark mode subtle」) | **Primitive**——`--color-{hue}-1` → `--color-{hue}-2`(月曆事件方塊,`tokens/categorical-color.ts` `CAT_EVENT`) |

> 2026-09-26 範圍更正(user 同意,條件「確保這符合我們一致的設計語言且不違背世界級的設計」):原表把「互動狀態」一律寫成「hover 永遠較亮」,實際只對實心色成立 —— 淡底與中性灰的滑過在淺色本來就是變深(本檔「Hover 換色配對總則」:往上一階)。淡底滑過改成第 1→2 階後,深色第 2–4 階同步改成半透明淡底,兩個主題的第 2 階都是「離底更遠一格」,不需要 mode 知識,依本檔「只有真的需要切換主題的東西才開 semantic token」直接用 primitive,不另開 12 個 `--{hue}-subtle-hover`。

兩個概念**本來就不該綁在同一層**。Tailwind 也這樣分離：`bg-blue-500`（靜態，scale step）vs `hover:bg-blue-600 dark:hover:bg-blue-400`（互動，需要 consumer 處理 mode）。差別只在於 Atlassian 流派把 mode swap 封裝進 token 裡，consumer 不需要寫 dark variant。

---

## 系統架構

色彩分兩層定義：

| 層 | 檔案 | 用途 | 範例 |
|---|---|---|---|
| **Primitive** | `primitives.css` | 原始色票，Tag / Avatar 直接消費 | `--color-blue-6`、`--color-blue-1` |
| **Semantic** | `semantic.css` | 語義 token，用於表達意圖（操作、狀態） | `--primary`、`--error`、`--info` |

```
Primitive              Semantic
──────────             ──────────
--color-blue-6      →  --primary（互動入口）
                    →  --info（資訊狀態）
--color-deep-orange-6 → --error（錯誤狀態）
--color-green-6     →  --success（成功狀態）
--color-yellow-6    →  --warning（警告狀態）
```

Semantic token 直接指向 primitive（無中間層）。

**消費規則**：

| 場景 | 使用層級 | 原因 |
|---|---|---|
| Tag、Avatar 的色彩 variant | **Primitive**（`--color-blue-1`、`--color-blue-6`、`--color-blue-7`） | 色名是顏色本身，不代表語義 |
| Tag、Avatar 的文字色（subtle 模式） | **Primitive step-7**（`--color-blue-7`、`--color-red-7`） | 小面積色塊文字需要更高對比，primitives 的相對色階公式在 dark mode 自動把 step-7 解析為高對比方向 |
| Button、Checkbox、Switch、Focus ring | **Semantic**（`--primary`） | 代表「使用者可以執行的操作」 |
| Badge 層級（high/medium） | **Semantic**（`--info`、`--info-subtle`、`--info-text`） | 代表「資訊狀態」，不是操作 |
| 錯誤訊息、驗證錯誤 | **Semantic**（`--error`） | 代表「系統出了問題」 |

**注意（categorical `red` vs semantic `--error` vs primitive `deep-orange` 三者獨立）**：
- `--error` = `--color-deep-orange-6`（primitive `deep-orange`，hue 38）—— semantic 狀態色,用於錯誤訊息。
- Tag / Avatar / Calendar 的 categorical `red` variant = `--color-red-*`（品牌紅家族 hue 25,與 `--brand` `#DF3232` 同族）。
- **三者無映射關係**：categorical `red`（hue 25）≠ `deep-orange`（primitive hue 38）≠ `--error`（semantic = deep-orange）。categorical 色相 1:1 對 `--color-{hue}-*`,零 offset（SSOT `tokens/categorical-color.ts`)。2026-06-04 修正原「red variant 接 deep-orange」offset。

Tailwind utility 透過 `@theme inline` 橋接 semantic token，元件寫 `bg-primary` 或 `bg-error` 即可。Tag / Avatar 使用 CSS 變數任意值（`bg-[var(--color-blue-6)]`）。

## Surface 分層（非常重要）

| Token / Utility     | 用途 | 說明 |
|---------------------|------|------|
| `bg-canvas`         | 頁面最底層背景 | HTML body 背景色 |
| `bg-surface`        | 非遮蓋型容器 | card、sidebar、table，dark mode 半透明 |
| `bg-surface-raised` | 遮蓋型浮層 | modal、popover、dropdown，必須不透明 |

`bg-surface-raised` 必須不透明，避免底層內容透出。

## 文字 / Icon 層級

| Utility            | 用途 |
|--------------------|------|
| `text-foreground`  | 主要文字（一般資訊）|
| `text-fg-secondary`| 次要資訊、helper text |
| `text-fg-muted`    | placeholder、caption、弱化 icon(**non-disabled only**)|
| `text-fg-disabled` | disabled 文字 + **disabled 元件內所有文字 / placeholder / icon**(state 勝 emphasis,M24)|

文字色一律使用 neutral alpha token，疊加在任何背景都能維持對比。
弱化 icon hover 後變 `text-fg-secondary`。

### 已定案(禁再問):`--fg-muted` 在淺色主題未達 WCAG AA —— 維持現狀

| 主題 | 實際值 | 白/深底上的對比 | AA(4.5:1)|
|---|---|---|---|
| 淺色 | `#8C8C8C`(黑 `--_na7: 45%` 疊白)| **3.36:1** | ✗ 未達 |
| 深色 | 白 `--_na7: 65%` 疊 `#0a0a0a` | 8.42:1 | ✓ |

**這不是疏漏,是明示的已知取捨。** 2026-09-21 全庫 axe 掃描 1040 個 story:critical = 0、
serious = 5051,其中 **color-contrast 佔 5046**,壓倒性來自這一個 token(placeholder、caption、
弱化說明文字)。當時量過的選項:`--_na7` 調到 55% → `#737373` = 4.74:1(剛過 AA)、
60% → `#666666` = 5.74:1。

> **外部對照的信心等級**:Atlassian `color.text.subtlest` = `#6B6E76`(算出來 5.10:1)
> 與「白底最淺可過 AA 的灰 `#767676` = 4.54:1」兩筆,**只有搜尋摘要來源,沒有一手官方檔案佐證**
> —— Atlassian / Polaris / Material 3 的 token 頁都是 JS 渲染,WebFetch 取不到內容(2026-09-21 實測)。
> 依 M26 標記為 **search-only confidence**;要當硬依據前須實地確認。
> 本表 `3.36 / 4.74 / 5.74 / 8.42` 四個數字則是用 WCAG 公式對**本 repo 實際 token 值**算出來的,可重算驗證。

**user 已經拍板兩次「維持現狀」,這是 standing decision,不得再主動提案或再問一次。**
user 2026-09-21 verbatim:「這個問題你很早之前就問過我了,而且上次我就說維持現狀。
這次也是,等我要改再等我主動」。**只有 user 主動提起才重啟這題**;
agent 不得因為 a11y 閘、稽核報告或新一輪掃描又把它列成待決事項。

代價已講明並被接受:螢幕閱讀器使用者不受影響,但**低視力使用者讀 placeholder / caption 會吃力**。
(第一次提案的理由與數據保留在上表,供 user 未來主動翻案時直接取用,不需重新研究。)

落地方式:a11y 閘(`scripts/audit-a11y.mjs`,夜間 `a11y-and-size.yml`)改為**只擋新增的回歸**,
這 5046 筆寫進 `infra/governance/baseline/a11y-baseline.json` 當已知帳。
要翻案只要把 `primitives.css` 的淺色 `--_na7` 從 45% 調到 55%,再跑一次 `--baseline-write`。

## Disabled 狀態

disabled 元件內的所有子元素必須呈現 disabled 狀態:

| 元素類型 | Disabled 處理 |
|---|---|
| 文字 / placeholder / Icon stroke | `text-fg-disabled`(state 勝 emphasis,M24)|
| 圖片 / Avatar | `opacity-disabled`——圖片無法套用語義色,用透明度弱化 |
| Checkbox / Radio | 元件自身的 disabled 樣式 |
| 背景色 | `bg-disabled`(如適用) |

**判斷標準**:disabled 元件內不應有任何元素呈現可互動 affordance。

**State precedence(M24,2026-05-04 升 SSOT)**:disabled 是 state,muted 是 emphasis decoration。disabled element 內 placeholder 用 muted = state 弱於 decoration → 違反語意層級。實作:`field-wrapper.tsx bareInputStyles` 加 `group-data-[field-mode=disabled]/field:placeholder:text-fg-disabled`,Select 等 ReadonlyDisplay 看 `resolvedMode === 'disabled'` 決定。詳 M24 + `.claude/memory/feedback_disabled_state_overlay_scroll_chain.md`。

### 兩種 disabled 策略:何時用哪個

系統有**兩種** disabled 視覺處理方式,判準是「**顏色是否是 semantic state 的主視覺載體**」:

| 策略 | 何時用 | 消費者 | 做法 |
|---|---|---|---|
| **灰階 token swap** | State 由形狀 / 位置 / icon / 文字 等**非顏色載體**承載,顏色只是美學 | Button、Checkbox、Input、Slider、Tag | 每個元素換到 disabled 對應的灰階 token(`bg-disabled` / `text-fg-disabled` / `bg-border` 等) |
| **`opacity-disabled`** | State **主要靠顏色區分**(殘餘線索如 thumb 位移 / 小 icon 在灰階低對比下太弱),灰階化會使 state 辨識大幅下降 | **Switch** | Root 層套 `opacity-disabled`,保留原有顏色身分,透過透明度均勻降級 |

**具體判準(寫新元件時問自己)**:
1. 在 disabled 狀態下,使用者需要辨識的 state 資訊是什麼?
2. 這些資訊**沒有顏色**仍然能看出來嗎?
3. 能 → 灰階 swap;不能 → opacity

**範例**:
- Checkbox 的 checked:checkmark **形狀**是 state 載體 → 灰階 swap OK
- Slider 的 value:thumb **位置** + range **長度**是 state 載體 → 灰階 swap OK
- Radio 的 selected:內圓點 **形狀**是 state 載體 → 灰階 swap OK
- Switch 的 on/off:track 在 on/off 之間**形狀相同**,只有**顏色**差別 → 必須 opacity

### Disabled 視覺階層公式(多元素元件參考)

多元素互動元件(Slider、Progress、複合 Input 等)在 disabled 狀態常需要 2–3 階灰階深度來分層:

```
底層背景 (n-2)  <  中層填充 / 輪廓 (n-5)        <  文字 (n-6)
bg-disabled       bg-border / border-border       text-fg-disabled
```

每階至少差 1 個 primitive step,使用者掃視時才能分清層次。Slider 的 disabled 就是這個公式:track(底,n-2)< range 填充 = thumb 邊框(n-5,**同色**——「Range 色 = Thumb border 色」invariant,thumb 邊框是 range 的視覺延續,不論 state 永遠同色,詳 slider.tsx 註解)< label 文字(n-6)。

> 2026-09-25 改:底層由 `bg-muted` 改為 `bg-disabled`(同值 neutral-2,畫面零變化)—— 這層只在元件停用時出現,依下方「Static Subtle Background」段邊界句「component disabled bg 不走 muted」;Slider 軌道同日跟著改(待辦總帳 C2)。
>
> 2026-06-12 修:本段原寫 4 階公式、輪廓層用 `border-fg-disabled`(n-6)、文字層標 n-7+——三者皆與 code 不符(`border-fg-disabled` 全 code 零使用且違反下方規則 3「border-* 一律從 border family 選」;`--fg-disabled` 實為 n-6;slider.tsx 的 range/thumb 邊框同色是刻意設計,曾踩 thumb 融入 track 的同色融色 bug)。對齊 code 真實。

### ⚠️ fg token 不可當 bg 用(跨 family 借用是 smell)

Semantic token 按**載體類型**分成四個 family,**family 之間的 token 不能互借**:

| Family | 前綴 | 語意 | 範例 |
|---|---|---|---|
| **Foreground**(前景) | `--fg-*` / `--foreground` | 文字 / icon stroke 的前景色 | `--foreground`, `--fg-secondary`, `--fg-muted`, `--fg-disabled` |
| **Background**(背景) | `--bg-*` / `--surface` / `--muted` / 色相 subtle | 填充色 | `--surface`, `--muted`, `--bg-disabled`, `--primary-subtle` |
| **Border**(邊框 / 分隔)| `--border`, `--border-hover`, `--divider` | 視覺分隔線、容器邊框 | `--border`, `--border-hover` |
| **Ring**(聚焦環)| `--ring` | `focus-visible` 的聚焦環 | `--ring` |

**跨 family 借用是 smell**,即使「剛好是我想要的顏色」。曾經踩過的例子:

> **Case**:Slider disabled 的 Range(填充段)一開始寫成 `bg-fg-disabled`。理由:`--fg-disabled`(neutral-6)剛好是我想要的「比 track 深但比文字淺」的灰度。但 `--fg-disabled` 語意是「**disabled 文字的前景色**」,拿來當 bg 等於借 fg token 當 bg 用。
>
> **問題**:(1)**語意矛盾**——consumer 讀 `bg-fg-disabled` 會困惑這是 bg 還是 fg;(2)**耦合未來變動**——微調 `--fg-disabled`(如 n-6→n-7 提高 disabled 文字可讀)會被迫連動 range,但 range 非文字、無文字可讀性約束;(3)**缺單一來源 bg token**——應存在「disabled 中層填充」bg token(沒有就新增 semantic alias,不是借 fg)
>
> **修正**:改用 `bg-border`(neutral-5)。`--border` 屬於 Border family,語意是「視覺分隔線 / 容器邊框 / 階層分隔的視覺元件」——跟 range 的「填充視覺指示器」角色接近,且 family 對得上(非文字的視覺填充類)。

**規則**:

1. **新元件寫新樣式前,先確認 class 的 family 語意跟實際用途對齊**——`bg-*` 一律從 bg/surface family 選,`text-*` 一律從 fg family 選,`border-*` 一律從 border family 選
2. **沒有合適 token 時,新增 semantic alias,不要借** family——例如若 bg family 沒有「中層填充」token,在 semantic.css 開 `--fill-muted` 或類似名稱,不要借 `--fg-disabled`
3. **Code review 檢查**:看到 `bg-fg-*` / `bg-foreground` / `text-surface` / `border-fg-*` 這類命名組合,立刻質疑是否 family 借用

**唯一合法例外**:`--foreground` 偶爾用在 `bg-foreground`(暗色填充)表達「inverse surface」(例如 Tooltip 深底)——但這是 inverse namespace 的設計意圖,有專門的 `--inverse-*` token family 處理,不是隨便借。一般元件不該 `bg-foreground`。

## Icon 色彩原則

Icon 色彩 canonical 的 SSOT 住 `patterns/element-anatomy/item-anatomy.spec.md`「Icon 色彩原則」——核心規則:icon 代表內容/類別 → 與 label 同色;icon 純指示方向 → `fg-muted`;disabled 統一 `fg-disabled`。本檔不重述(Rule-of-3 pointer)。

## 語義色

### Action — Primary

`--primary` 只用於互動入口，代表「使用者可以執行的操作」。

| 用途 | 範例 |
|------|------|
| 主要按鈕 | `bg-primary` |
| 文字連結 | `text-primary` |
| 焦點框 | `--ring`(全域 `:focus-visible` 外描邊,元件不寫 class) |

```tsx
<Button variant="primary">確認</Button>
<a className="text-primary hover:text-primary-hover">查看詳情</a>
```

**連結 hover = 換色(`text-primary-hover`),不用底線** —— `text-primary hover:underline` 偏離 canonical。真元件 Breadcrumb / Button / RadioGroup 已遵循。**例外:`LinkInput` 是「外部連結值」顯示,刻意保留 hover 底線作為「可點開連結」affordance(見 `link-input.spec.md`),非 violator**。story 導覽連結由 `check_story_invariants.sh` R10 機械防 drift(P1 warn,豁免 `// @link-style-allow:`)。

### Status

狀態色表達系統回饋，代表「系統在告訴你什麼」，不用於互動操作。

| Token | 色相 | 用途 |
|-------|------|------|
| `--info` | blue | 資訊提示、進行中（in-progress）、active 指示、step indicator |
| `--error` | deep-orange | 錯誤 / 危險 |
| `--success` | green | 成功 |
| `--warning` | yellow | 警告 |

雖然 `--info` 與 `--primary` 目前同色（blue），**語義截然不同，不可混用**：

> 只要是「呈現狀態」就用 `--info`，只要是「互動入口」就用 `--primary`。
> 尤其在同一個 UI 脈絡中可能出現多種 status 色時（如任務列表、step indicator），一律使用 status 色系，絕不混入 `--primary`，否則使用者無法建立一致的色彩解讀框架。

```tsx
// ✅ 正確
<Progress className="bg-info" value={60} />
<Tag className="bg-info-subtle text-info-text">進行中</Tag>
<p className="text-error">此操作無法復原</p>

// ❌ 錯誤——progress bar 不是互動操作
<Progress className="bg-primary" value={60} />
```

**機械強制**:此規則對 status 元件(ProgressBar / CircularProgress / Steps / Calendar today)由 `scripts/status-color-invariant.mjs` 鎖住(執行面 = 配對測試 `scripts/test-status-color-invariant.mjs` 直呼它,登記在 `infra/governance/providers/harness-source-inventory.json` 的 gate-meta 家族、由夜間 `governance-harnesses.yml` 帶跑;舊句寫的 `scripts/release-preflight.mjs` 已於 2026-08-04 退役,PR lane 目前不直呼 —— 2026-09-27 對帳改寫),回潮 `--primary` 即 fail。2026-06-05 user 拍板把這 4 個元件的 progress/step/in-progress 填色從 `--primary` 全遷 `--info`(同色 blue-6 零視覺差,語義正確 + brand-swap 安全)。

每個語義色的 bridge 同時產出 `bg-xxx`、`text-xxx`、`border-xxx` 三組 utility，視場景選用。

- warning 的文字色取決於底色：

  | 底色 | 文字色 | 原因 |
  |------|--------|------|
  | `bg-warning`（yellow-6，滿版） | `text-on-emphasis-dark`（`black-a85`，深色） | 黃色亮度高，白字對比不足，必須用深色（通用亮底深字 token，非 warning 專屬；定義見下「`--on-emphasis` / `--on-emphasis-dark` 配對」段） |
  | `bg-warning-subtle`（淡黃） | `text-warning-text`（semantic，= `--color-yellow-7` step-7） | subtle 底色夠淺，深一階的黃色文字可辨識（見「文字色 Step 原則」）；Notice / Alert code 消費的即是此 semantic utility，不硬寫 primitive 色名 |

### Indicator — Notification

| Token | Utility | 色相 | 用途 |
|-------|---------|------|------|
| `--notification` | `bg-notification` | deep-orange | 未讀計數 badge、通知紅點 |

`--notification` 目前與 `--error` 使用同色（deep-orange-6），但語義獨立——`--error` 表示「系統出了問題」，`--notification` 表示「有待處理的項目」。兩者保持分離的 token，未來可單獨調整顏色。

```tsx
<span className="bg-notification text-white">3</span>   // badge 計數
```

### Highlight — 文字反白與搜尋配對

| Token | Utility | 值 | 用途 |
|-------|---------|------|------|
| `--text-selection` | `bg-text-selection` | blue-5 @ 30% 半透明 | 文字反白(`::selection`)底色;全域樣式住 `styles/base.css`,只動底色不動字色 |
| `--search-match` | `bg-search-match` | amber-3 | 頁內搜尋(Ctrl+F 類)**所有配對**的行內底色 |
| `--search-match-current` | `bg-search-match-current` | amber-5(dark:amber 基準色 45% 半透明,2026-09-26 起) | 配對中**目前這一筆**(find 游標所在) |

設計依據(2026-08-28 拍板):

- **反白必半透明**:對齊 VS Code theme-color 對 selection 類 token 的鐵律「The color must not be opaque so as not to hide underlying decorations」(https://code.visualstudio.com/api/references/theme-color);反白後文字須維持對比 ≥ 4.5:1(https://developer.mozilla.org/en-US/docs/Web/CSS/::selection)
- **搜尋雙檔制**是編輯器/瀏覽器普世慣例:VS Code `editor.findMatchBackground`(「Color of the current search match」)與 `editor.findMatchHighlightBackground`(「Color of the other search matches」)兩 token 分立;琥珀/黃族底色 = 瀏覽器原生 find 慣例
- **對階**:amber-3 / -5 對齊 Radix scale 語意 step 3 =「UI element background」/ step 5 =「Active / Selected UI element background」(https://www.radix-ui.com/colors/docs/palette-composition/understanding-the-scale);行內 highlight 鐵約束 = 文字保持原色可讀 → 底色停留亮階(≤ step 5)
- **為何字尾是 `-current` 不是 `-active`**:`-active` 在本系統 = 按壓語意且映射第 7 階(`--amber-active` = amber-7,見「互動狀態推導」),同字不同映射會破壞一致性;`current` 取自 VS Code 官方描述原詞
- **Dark**:`--text-selection` / `--search-match` 由 primitive 階梯公式自動換值免 override(2026-09-26 起深色 amber-3 是半透明淡底,卡片上 `#5F4A28`、白字 8.41);`--search-match-current` **需覆寫**——dark amber-5 配白字對比 3.03 過不了 4.5;原本用 amber-4(5.89),深色 step-2..4 改成淡底後 amber-4 與 amber-3 區辨只剩 1.21 → 改 `color-mix(in oklch, var(--color-amber-6) 45%, transparent)`:卡片上 `#81622D`、白字 5.65 ✓、與全部配對區辨 1.49(light 1.30)。light 量測不變:反白 11.41 / amber-3 12.21 / amber-5 9.82

```tsx
<mark className="bg-search-match text-inherit">報表</mark>          // 一般配對
<mark className="bg-search-match-current text-inherit">報表</mark>  // 目前這一筆
```

禁止:

- ❌ `<mark>` 用 UA 預設黃 — 必套 `bg-search-match`(或 `-current`)+ `text-inherit`
- ❌ 搜尋配對語意裸用 `--color-amber-3/5` — 必經 semantic token(未來調色只動一處)
- ❌ `--search-match-current` 借給按壓 / 持續選中場景 — 那是 `--neutral-active` / `--neutral-selected` 家族的域;`--text-selection` 亦禁借給資料列選取

### Drop target — 「可以放到這裡」的區域配對

| Token | Utility | 值 | 用途 |
|-------|---------|------|------|
| `--drop-target` | `bg-drop-target` | `--primary` @ 15% 半透明(兩模式同一公式) | 合法放置 / 停靠區域的底色 |
| `--drop-target-border` | `border-drop-target-border` | = `--primary-hover`(light blue-5 / dark blue-7) | 同一區域的邊框色 |

**`@theme inline` bridge 別名**:`semantic.css` 另定義 `--color-drop-target` / `--color-drop-target-border`
(= 同名 semantic token 的 alias),這是 Tailwind v4 產出 `bg-drop-target` / `border-drop-target-border` utility 的橋接
(token-system.spec.md「跨 family `@theme inline` bridge」),**不是第二組語意 token**;改值一律改上面那兩顆。

設計依據(2026-09-03 拍板):

- **底色必半透明**:區域覆蓋在別人的內容之上,沿用 Highlight 段同一條鐵律——VS Code theme-color「The color must not be opaque so as not to hide underlying decorations」(https://code.visualstudio.com/api/references/theme-color)。這也是它與 `--primary-subtle` 的分工:`-subtle` 是**元件自己的**淡底(底下沒有別人的內容:Button toggle 持續按下、DataTable range cell);`--drop-target` 是**蓋在別人內容上的暫態區域**。
  > 2026-09-25 更正:原句寫「`-subtle` 不透明」,與下方「Dark mode subtle」段矛盾 —— 淺色的 step-1 是不透明色票,**深色的 step-1 是 alpha 公式**(`primitives.css` 深色區塊 `--color-{hue}-1: oklch(from var(--color-{hue}-6) l c h / calc(0.12 / l))`),本身就半透明。兩者的分工看的是「底是誰的」(元件自己的 vs 蓋在別人內容上),不是透不透明。
  > 已知後果(實測,2026-09-25):深色主題下 `-subtle` 底會透出父層的滑過底色 —— DataTable 區間格在被滑過的列上由 `#1C304A` 變 `#243851`;淺色因為 step-1 不透明,同一情境維持 `#E3F1FF` 不變。兩個主題在這一格表現不一致。修法(列被滑過時把區間格釘住)已備妥、**未套用**:屬「試算表模式」那組,user 2026-09-26 仍在提問(待辦總帳〇節「被質疑、先不做」、C12⑦)。
- **為什麼是 15%(先對內、再對外)**:先取 **DS 自家 alpha 階梯上的既有階** —— `primitives.css` 的 `--_na5`(light)/ `--_na4`(dark)就是 15%,也是 `--black-a15` / `--white-a15` 用的那一階,是少數**兩個模式都存在**的階;不自創新階(`opacity.css` 禁新增)。再確認它落在世界級區間內:Material 3 `dragged` state layer 0.16(拖曳是所有狀態中最高階,https://github.com/material-components/material-web/blob/main/tokens/versions/v0_192/_md-sys-state.scss)、VS Code light `editorGroup.dropBackground` 0.18(https://github.com/microsoft/vscode/blob/main/src/vs/workbench/common/theme.ts)、Atlassian `color.background.selected.hovered` #CCE0FF ≈ 0.20 —— 15% 是這個區間的下緣,對「暫態、只出現一兩秒、面積不小」的區域最不吵。
  > 註:同為色相覆蓋層的 `--text-selection` 用 30%(不在階梯上),因為反白必須在文字上一眼可辨;drop target 是整片區域提示,不需要那麼重。階梯是「優先取用」不是「唯一合法」,偏離要像這樣寫明理由。
- **一個公式兩個模式**:`--primary` 在 dark 由 primitive 階梯自動變亮,故不需 dark override,也不新開 opacity 階(`opacity.css` 禁新增)。
- **邊框取 `--primary-hover`**:瞬時態一律歸 hover 階(同 FileUpload 拖入區 2026-07-06 的收斂);值與該元件原本硬指的 `--primary-hover` 相同 → 改消費本 token **零視覺差**,兩處從此同一 SSOT。

**兩種情境,同一組 token,不同組合**(2026-09-03 user 提問「FileUpload 的邏輯不一樣吧」→ 全掃確認正確):

| | 常駐拖入區(`FileUpload` dropzone) | 暫態停靠區(`AgentFabDock` 右緣帶) |
|---|---|---|
| 靜止時 | **看得見**:dashed `--border` 邊框 + surface 底(它是使用者要瞄準的元件) | **不存在**:只有拖曳中才出現 |
| 進入合法區 | 邊框換成 `--drop-target-border`;**不填色** | 填 `--drop-target` + 三邊 dashed `--drop-target-border`(貼邊那側不畫,見下) |
| 被拖的東西 | 是 OS 拖曳影像,DS 管不到 → 回饋只能長在區域上 | 是 DS 自己的鈕,**當場變成落點形狀貼在落點高度**(所見即所得)→ 區域只需回答「範圍在哪」 |

所以**不統一成同一個組合**:常駐區已經看得見,再填色是多餘噪音(`file-upload.spec.md`「state 信號靠邊框,非底色」);暫態區是憑空出現的,需要「整區」訊號才讀得出範圍(Windows Snap「translucent overlay」、macOS「highlighted area」、Atlassian「droppable area 換底色」)。統一的是**顏色語言**(同一組 token)與**dashed = 可放下的暫時目標**這個語彙,不是每個像素的組合。

- **貼邊那側不畫邊框、不留圓角**:區域貼齊視窗邊時只畫露出的三邊,與 Sheet / Sidebar / AppShell 側欄 / 貼邊鈕(環只畫露出三邊)同一語言。

**與鄰居的分界**(避免同一件事有兩個 token):

| 視覺 | Token | 誰在用 |
|---|---|---|
| 可放下的**區域底**(蓋在別人內容上) | `--drop-target` | `AgentFabDock` 停靠帶、TreeView / nested row 的 inside-drop 整列(`lib/drag-visual.ts`) |
| 該區域的**邊框** | `--drop-target-border` | `AgentFabDock` 停靠帶、`FileUpload` drag-over |
| **插入位置線**(「放在這兩者之間」) | `--primary` 2px 實線(`lib/drag-visual.ts`) | DataTable row / column 重排、TreeView before/after |
| 元件**自己的**選中 / 命中淡底(底下沒有別人的內容) | `--primary-subtle` | Button toggle 按下、DataTable range cell(持續選取,非拖放) |

> 2026-09-03 收斂:TreeView / nested row 的 inside-drop 整列**已改用 `--drop-target`** —— 它蓋在該列的文字之上,正是「覆蓋層必半透明」要管的情形(VS Code 對應 token 就叫 `list.dropBackground`),而且「可以放進這一列」與「可以停靠在這條帶」是同一件事,不該有兩個 token。視覺差極小(light 13/255、dark 8/255)。DataTable 的範圍選取維持 `--primary-subtle`:那是**持續選取**,不是拖放目標。

禁止:

- ❌ 元件自刻 drop / snap 區域顏色(硬寫 `border-primary-hover`、`bg-primary/10`)— 一律消費本組
- ❌ `--drop-target` 借給持續選中 / 元件自己的淡底 — 那是 `--neutral-selected` 家族與 `--primary-subtle` 的域
- ❌ 為了「更明顯」把底色改成不透明 — 違反上面的覆蓋層鐵律

### Identity — 品牌

| Token | 用途 |
|-------|------|
| `--brand` | 品牌色，固定色 #DF3232，兩主題相同 |

### Primitive 色票與 Tag / Avatar 的消費

Tag、Avatar 等需要多色區分的場景（專案標籤、團隊分類等）直接消費 primitive token。消費端自行決定色彩用途。

每個色相的 primitive 包含完整的 step 序列，Tag / Avatar 主要消費以下 step：

| Step | 用途 | 範例 |
|------|------|------|
| step-1 | subtle 背景（淡色填充） | `--color-blue-1` |
| step-5 | dismiss hover（solid 模式） | `--color-blue-5` |
| step-6 | solid 背景（全色填充） | `--color-blue-6` |
| step-7 | subtle 文字、dismiss active（solid 模式） | `--color-blue-7` |

可用 categorical 色相（12 個，SSOT `tokens/categorical-color.ts` `CATEGORICAL_HUES`）：blue、green、deep-orange、yellow、red、orange、amber、lime、turquoise、indigo、purple、magenta。Tag / Avatar / Calendar event 三者共用此組,每個色相 variant 名 1:1 對 `--color-{hue}-*`（零 offset）。

**注意**：categorical `red` = `--color-red-*`（品牌紅 hue 25),與 primitive `deep-orange`（hue 38）及 semantic `--error`（= deep-orange）**完全無關**（見本檔頂部「消費規則」段注意事項）。

**與 semantic 色的差別**：semantic 色（primary/info/error/success/warning）有固定語義，primitive 色沒有。Tag / Avatar 使用 primitive 是因為「blue」代表顏色本身，不代表「主要操作」或「資訊狀態」。

### `--on-emphasis` / `--on-emphasis-dark` 配對:飽和 / 填色底的對比文字

填色底上的文字色**依底色明暗成對**提供(世界級共識:Material `on-primary` family、Radix `--accent-contrast`、Polaris `text-{x}-on-bg-fill` —— 都是「成對 on-color token」,不是單一固定白):

- `--on-emphasis = oklch(1 0 0)`(純白,dark mode 不反轉)—— 用於**夠深的飽和色底**(白字達 WCAG 門檻):primitive 6 階深色 / `--primary` / `--error` 等,及 categorical blue/deep-orange/red/indigo/purple/magenta(turquoise 2026-07-16 移入深字組)。
- `--on-emphasis-dark = var(--black-a85)`(深字,dark mode 不反轉)—— 用於**太亮的色底**(白字對比不足):categorical **yellow / amber / orange / lime / turquoise**(turquoise 2026-07-16 dark 色相修正後加入)。

**合規門檻(2026-06-04 user 拍板「以最低為原則」)= WCAG large/bold 3:1**(solid chip / avatar 的字視為大粗字)。底色 step-6 白字達 3:1 → 用 `--on-emphasis`;不達 → 用 `--on-emphasis-dark`。

**★ green documented exception**:green-6 白字實測對比 2.47(連 3:1 都不過),但 user 拍板維持白字(沿用世界級慣見的「綠底白字」按鈕觀感)→ 列為知情違反,待日後評估是否調整 green-6 本身。

**`--warning-foreground` 2026-06-04 移除(改名 + 不留 alias,user「以乾淨為主」)**:原 `--warning-foreground`(= black-a85)被 categorical yellow/amber 借用 = 誤名(它跟 warning 無關,本質是「亮底深字」通用概念)→ 統一改名 `--on-emphasis-dark`,**不保留 warning 專屬 token**(grep 確認無任何元件消費 `text-warning-foreground`)。warning solid surface 若需黃底深字,一律消費通用 `--on-emphasis-dark`(與其他亮色 hue 同),不再有 warning 專屬前景。

**為什麼獨立於 `--foreground`**:`--foreground` = neutral-9 文字色(淺色 neutral 底的主文字);on-emphasis 配對是「飽和 / 填色底」專用,跟 neutral 表面前景語義不同(數值巧合相同也不可合併:light mode `--foreground` 是深色,混用會 break 飽和底白字)。

**消費者**(目前):Avatar / Tag solid color variants、Steps filled indicator(icon 色)、Calendar today、Tooltip 等。對比由 `scripts/categorical-color-invariants.mjs` I4 機械驗(oklch→相對亮度→contrast,green exempt)。

**不該消費的情境**:
- ❌ 淺色 subtle 底(step-1)用 on-emphasis 配對 — 請用 `--foreground` / `--color-{hue}-7` family。
- ❌ 把 on-emphasis 配對當 bg 用 — 它們是文字 token。

### `--inverse-*` namespace：inverse surface 上的內容色

`--inverse-*` 是一組 namespace，用來表達「繪製在 inverse surface（= solid `--color-neutral-9`，在 dark mode 自動反轉）上的內容」。Tag / Avatar 的 neutral solid variant 使用 neutral-9 作為底色，因此需要一組與 `--foreground` 家族對應、但方向相反的 token。

| Token | 對應的正常態 token | 用途 |
|-------|------------------|------|
| `--inverse-fg` | `--foreground` | inverse surface 上的文字色（Tag/Avatar neutral solid 的 label） |
| `--inverse-neutral-hover` | `--neutral-hover` | inverse surface 上**透明子元素**滑過時換上的配對（如 dismiss hover） |
| `--inverse-neutral-active` | `--neutral-active` | inverse surface 上**透明子元素**按下時換上的配對（如 dismiss active） |

**命名原則**：
- base 文字 token 命名為 `--inverse-fg`（對齊 `--foreground`），而不是 `--neutral-inverse`。原因是本 token 系統沒有 `--neutral` 這個 semantic base（只有 primitives `--color-neutral-1` ~ `--color-neutral-9`），若命名為 `--neutral-inverse-*` 會讓讀者誤以為存在 `--neutral` base，造成誤導。
- 互動 token 命名為 `--inverse-neutral-hover` / `--inverse-neutral-active`，明確指出鏡射的是 `--neutral-hover` / `--neutral-active`。`fg` 自帶語意所以單獨用，但 `hover` / `active` 太籠統需要 `neutral-` 限定詞表明角色。
- **它們是換色,不是疊層**(2026-09-25 更正用詞;原寫「hover overlay / 互動 overlay」):inverse 底上的透明子元素(例:dismiss 鈕)靜止時是透明,滑過時**把自己的底色換成** inverse 階梯上的配對 —— 跟一般底上的透明元素換成 `--neutral-hover` 是同一套機制(見「Hover 換色配對總則」)。它不是蓋在 inverse 底色上的一層半透明遮罩;本檔開頭「架構流派定位」拒絕的正是那種疊層(State Layer)。
- 以 `--inverse-*` 為 namespace 則意義清晰：「inverse surface 上的 foreground / neutral-hover / neutral-active」。

**數值規則（嚴格對稱）**：`--inverse-neutral-*` 在某 mode 的值 = `--neutral-*` 在「另一 mode」的值。即 inverse 是 neutral 的 mode 鏡射。

| Token | Light | Dark |
|-------|-------|------|
| `--neutral-hover` | black @ 2% | white @ 4% |
| `--neutral-active` | black @ 4% | white @ 8% |
| `--inverse-neutral-hover` | white @ 4% (= dark neutral-1) | black @ 2% (= light neutral-1) |
| `--inverse-neutral-active` | white @ 8% (= dark neutral-2) | black @ 4% (= light neutral-2) |

好處：完全對稱、重用既有 tuned values、自動繼承感知補償（dark mode 4% 補償白色透明在深底較弱的視覺感受），未來改 neutral 強度時 inverse 自動同步。

**未來擴展**：當需要在 inverse surface 上表達文字層級時，可平行新增以下 token，對應 `--fg-*` 家族：

| 未來 token | 對應的正常態 token |
|-----------|------------------|
| `--inverse-fg-secondary` | `--fg-secondary` |
| `--inverse-fg-muted` | `--fg-muted` |
| `--inverse-fg-disabled` | `--fg-disabled` |

目前僅 `--inverse-fg` 有實際消費需求，其他層級在有明確使用情境時再加入，避免過度設計。

### 文字色 Step 原則

色彩用於文字時，step 的選擇取決於文字的**角色**——是「資訊呈現」還是「互動入口」？這兩種角色的視覺需求完全不同。

| 角色 | 例子 | Token | 為什麼這個 step |
|------|------|-------|---------------|
| **資訊呈現**（不強調互動，以表達資訊為主的有色文字） | Tag label、Avatar fallback、Badge medium 計數、status indicator | primitive step-7（`--color-{hue}-7`）<br>或 semantic `--{status}-text`（`--info-text`、`--error-text`） | **辨識度優先**——小面積色塊文字疊在 step-1 subtle 底色上，需要更高對比才能舒適閱讀。step-7 在 light mode 是「比 step-6 暗」，在 dark mode 透過 primitives 公式翻轉自動變成「比 step-6 亮」，**兩個 mode 都是離 step-1 subtle 背景最遠的高對比方向**。 |
| **互動入口**（吸引點擊，鼓勵操作） | Button label、Link、可點擊的 status text | semantic base（`--primary`、`--error`、`--info` 等）= step-6 | **鮮豔度優先**——step-6 是色相的飽和最高點，吸引注意力引導使用者操作。互動元素本身有 hover/active 回饋，不靠文字色階暗示。 |
| **互動 hover / active** | Button hover、Tag dismiss icon hover | semantic hover/active（`--primary-hover` 等）= step-5 / step-7 + dark mode swap | **回饋使用者操作**——hover lift / active press 方向跨 mode 一致 |

#### `--{hue}-text` 的角色

**`--{hue}-text` 專門用於「不強調互動、以表達資訊為主的有色相文字」**。它的存在是為了區分兩種完全不同的有色文字：

- **資訊呈現**用 `--{hue}-text` / `--color-{hue}-7` → 小面積色塊文字，最大對比，靜態閱讀
- **互動入口**用 `--primary` 等 semantic base = step-6 → 鮮豔，吸引點擊

**典型 `--{hue}-text` 消費者**：
| 元件 | 用法 | 為什麼是「資訊呈現」 |
|------|------|------------------|
| Tag subtle | label 文字 | Tag 是分類標籤，不可點擊（dismiss 是 inline action 不算 Tag 本體） |
| Avatar subtle | fallback 字 | 文字 fallback 是身份標識，不是按鈕 |
| Badge medium | 通知計數 | 計數是資訊指示器，本身不可點擊 |
| Status text | 「進行中」「已完成」等 | 狀態描述，不引導動作 |

**不該用 `--{hue}-text` 的場景**：
- ❌ Button label（用 `text-white` on primary bg）
- ❌ Link（用 `text-primary` = step-6，鮮豔度優先）—— **唯一例外**:放在有色訊息句子裡的連結(例:錯誤描述裡的「View log」)沿用那句訊息的 `-text` 色 + 平常就有底線,**滑過不換色**(user 2026-09-26 選「乙 紅字 + 底線，滑過不變」;範例與理由見 `../../components/FileItem/file-item.spec.md`「Description ReactNode 可含 clickable 元素」;世界級同款 Polaris Banner 內 Link 的 monochrome)。範圍只限「整句已經是有色訊息」;一般內文連結照上一行用 `text-primary`
- ❌ 任何 hover/active 互動回饋(上一條例外的連結因此滑過不換色,不得拿 `--{hue}-hover` 補 —— 那是 step-6 填色的配對)

#### 為什麼 step-7 在兩個 mode 都對

Primitives 的相對色階公式在 dark mode 把 step-5 / step-7 公式互換：
- Light mode：step-7 = `l * 0.82`（較暗）→ 對白色 subtle 是暗色高對比 ✓
- Dark mode：step-7 = `l + (1-l) * 0.20`（較亮）→ 對深色 subtle 是亮色高對比 ✓

**step-7 永遠是「離 subtle 背景最遠的方向」**，與 mode 無關。這就是為什麼資訊文字可以直接用 primitive，不需要 semantic 層 swap。

Badge 使用語義色的 text token（`--info-text`、`--error-text`），不直接消費 primitive。

**step-7 vs semantic active 的區別**：兩者在 light mode 都指向 step-7，但 dark mode 行為不同。semantic active（如 `--primary-active`）在 dark mode 反轉為 step-5（壓暗模擬按壓感），而 primitive step-7 在 dark mode 仍維持高對比方向。簡言之：active 服務於互動回饋，step-7 服務於閱讀對比，兩者目的不同，dark mode 方向相反。

**例外：step-6 滿版底色上的「亮色 hue」文字用 `--on-emphasis-dark`（`black-a85`,深色)**——yellow / amber / orange / lime / turquoise 亮度極高,白字（`--on-emphasis`）連 WCAG 3:1 都不過,必須深色文字（見上「`--on-emphasis` 配對」段)。此例外只在底色是 step-6 時觸發,step-1 subtle 底色上仍用 step-7。（green-6 白字亦不過 3:1,但列 documented exception 維持白字。)**2026-09-29 user 重新確認維持 step-7**(原話:「要我拍板的第一題就照舊規格」):淡底上 yellow / lime / amber / green / orange 的 step-7 文字對比實測 2.46–3.82(1×1 canvas 讀 token 值、WCAG 公式),已知未達 AA,維持現狀不改 token;a11y 基線(`infra/governance/baseline/a11y-baseline.json`)記為已知。

### Subtle 背景（淡色填充）

所有語義色都有 `-subtle` 變體。Tag / Avatar 直接使用 primitive step-1（`--color-{hue}-1`）：

```tsx
// Semantic subtle
<div className="bg-primary-subtle" />
<div className="bg-error-subtle" />
<div className="bg-success-subtle" />
<div className="bg-warning-subtle" />

// Tag / Avatar 直接用 primitive step-1
<div style={{ backgroundColor: 'var(--color-blue-1)' }} />
<div style={{ backgroundColor: 'var(--color-purple-1)' }} />
```

#### Dark mode subtle

**色階原則:號碼 = 離所在底色多遠(與底色的對比)** —— 淺色號碼越大越深,深色號碼越大越亮,兩個主題同一個意思。世界級同派:Adobe Spectrum「As the color token name increases in number (e.g., blue-700, blue-800, blue-900), the color value's contrast with the background also increases. Because of this, colors progressively get darker in light theme and lighter in dark themes.」([color-fundamentals](https://spectrum.adobe.com/page/color-fundamentals/));Radix Colors 深色 1 → 12 由暗到亮(3.0.0 發布檔 `red-dark.css`:`--red-1: #191111` … `--red-12: #ffd1d9`,https://cdn.jsdelivr.net/npm/@radix-ui/colors@3.0.0/red-dark.css);Ant Design 深色色板 1 → 10 由暗到亮(https://ant.design/docs/spec/dark,「Pick your background color #141414」下方色板 color-1 `#111d2c` … color-10 `#b7e3fa`);Primer 中性色階「The light and dark scale directions are inverted, with the light scale starting with white and the dark scale starting with black.」(https://primer.style/foundations/color/base-scales)。另一派:號碼是絕對深淺、深色主題另挑號碼 —— Material 3 參考色調只有一份、0 = 黑 … 100 = 白(https://github.com/material-components/material-web/blob/main/tokens/versions/v0_192/_md-ref-palette.scss#L68-L80)、Carbon「The light themes are based on White and Gray 10 backgrounds, and the dark themes use Gray 100 and Gray 90 backgrounds.」(https://carbondesignsystem.com/elements/color/overview/)、Tailwind「with 50 being the lightest, and 950 being the darkest」(https://tailwindcss.com/docs/colors)—— 本 DS 屬前一派。(2026-09-26 user:「色階本來就是以其與背景的對比程度在升級的吧？換言之在深色模式，越大的色階通常就是越亮越白，這樣對比才是越來越高吧？」研究確認後寫入。Radix / Ant / Primer / Material / Carbon / Tailwind 的一手來源 2026-09-27 逐一抓取核對;Atlassian 色板頁為前端渲染抓不到原文,不點名。)

Light mode 的 step-1..4 是不透明色票(淺色的底只有白一種,事先混好等於在真的底上混)。Dark mode 的 **step-1..4 = 淡底區,同一條 alpha 公式**(step-1 自 2026-07-04 Q10,step-2..4 自 2026-09-26):

```css
/* primitives.css dark mode:K = 0.06 × (n+1) → step-1..4 = 0.12 / 0.18 / 0.24 / 0.30 */
--color-{hue}-{n}: oklch(from var(--color-{hue}-6) l c h / calc(K / l));
```

- **為什麼半透明**:深色有頁面 / 卡片 / 浮層 / 滑過中的格四種底,只有半透明能在每一種底上都保持「號碼越大離底越遠」;不透明的淡階放在頁面上比底亮、放在卡片上反而比底暗(2026-09-26 前 step-2..4 往純黑退 `l × 0.28 / 0.44 / 0.62`,12 色的 step-2 全比 step-1 暗、10 色比卡片底還暗 → 月曆事件深色滑過變近黑)。
- **除以 l**:亮度越高的色相 alpha 越低,感知亮度自動統一;K 的比例 1 : 1.5 : 2 : 2.5 ≈ Radix Colors 3.0.0 深色 alpha **第 3–6 階**(a3 : a4 : a5 : a6,不是 a1–a4)的比例 —— red 45 : 68 : 86 : 104 = 1 : 1.51 : 1.91 : 2.31、blue 58 : 87 : 107 : 127、green 30 : 45 : 60 : 75、amber 34 : 50 : 65 : 81(sRGB 8-bit alpha,https://cdn.jsdelivr.net/npm/@radix-ui/colors@3.0.0/red-dark-alpha.css 等四檔);31 個色相的中位數 1 : 1.48 : 1.89 : 2.37(2026-09-27 依同一版發布檔算;GitHub repo 無 v3.0.0 tag,故引 npm 發布檔)。
- **新色相門檻**:深色 base-6 的 `l`,掃描下最嚴的色相(紫一帶)約 0.52(2026-09-26 掃 11,880 組假想色相,低於此值紫藍、紅一帶在滑過中的格上會出現 step-4 > step-5);門檻隨色度 / 色相變(現行 `--color-red-6` 深色 l = 0.51 仍過),實際以 `scripts/categorical-color-invariants.mjs` I5「色階順序」為準,不拿單一數字當閘。
- **step-5..10 不變**:step-5 是深色的按壓色(實心,`l × 0.82`),step-7..10 往白推(文字方向)。
- **機械防線**:`scripts/categorical-color-invariants.mjs`「色階順序」—— 12 色 × 10 階 × 淺白 / 淺滑過格 / 深頁面 / 卡片 / 浮層 / 滑過格,淺色號碼越大越暗、深色號碼越大越亮,且深色每一階都比底亮。
  > 已知後果(實測 2026-09-26):第 7 階字在深色滑過中的格(第 2 階淡底疊 `#272727`)上,7 個色相對比 < 4.5(紅 3.07、靛 3.20、紫 3.22、洋紅 3.68、藍 3.75、深橘 3.77、青 4.36),全部 ≥ 3.0;user 2026-09-26 對此說「這個先忽略」→ 擱置,記在待辦總帳,不再提問。
- 淡底只能當淡底:半透明會透出底下的東西,不能拿來當需要蓋住下層的顏色(本檔「Drop target」段)。

## 互動狀態推導（Hover / Active）

### 公式

Hover / active **直接引用色盤 step**，不使用獨立公式：

| | Hover（較亮） | Active（較暗） |
|---|---|---|
| Light | step **-5** | step **-7** |
| Dark | step **-7** | step **-5** |

相對色階公式保證 step -5 永遠比 base 亮、step -7 永遠比 base 暗，
所有色相適用同一規則，無例外。

高亮度色相（yellow 等）的 hover gap 較小（ΔL ≈ 0.03），
這是物理事實——亮色的淺色方向空間窄。
cursor 變化 + 細微色移疊加仍提供足夠互動回饋。

```tsx
<button className="bg-primary hover:bg-primary-hover active:bg-primary-active" />
```

### Semantic token 直接指向 primitive

| Token | 指向 primitive |
|-------|----------------|
| --primary / --primary-hover / --primary-active / --primary-subtle | → blue-6 / blue-5 / blue-7 / blue-1 |
| --info / --info-hover / --info-active / --info-subtle / --info-text | → blue-6 / blue-5 / blue-7 / blue-1 / blue-7 |
| --error / --error-hover / --error-active / --error-subtle / --error-text | → deep-orange-6 / deep-orange-5 / deep-orange-7 / deep-orange-1 / deep-orange-7 |
| --success / --success-hover / --success-active / --success-subtle / --success-text | → green-6 / green-5 / green-7 / green-1 / green-7 |
| --warning / --warning-hover / --warning-active / --warning-subtle / --warning-text | → yellow-6 / yellow-5 / yellow-7 / yellow-1 / yellow-7 |

每個色相使用色盤的 4 個 step：-1（subtle）、-5（hover）、-6（base）、-7（active / text）。

Dark mode 覆寫：hover/active 方向反轉（hover → step-7，active → step-5），subtle 使用 alpha 公式。text 不需覆寫——primitives 的相對色階公式已處理 dark mode 方向。

### `--{hue}-hover/active` — 非語意色相的互動 token

除了 semantic 色相（primary、info、error、success、warning）有完整 5 件套（base/hover/active/subtle/text）外，**作為 bg 使用的非語意色相**還有獨立的 hover/active 互動 token：

| Token | 指向 primitive | dark mode swap |
|-------|--------------|--------------|
| `--blue-hover` / `--blue-active` | blue-5 / blue-7 | blue-7 / blue-5 |
| `--red-hover` / `--red-active` | red-5 / red-7 | red-7 / red-5 |
| `--deep-orange-hover` / `--deep-orange-active` | deep-orange-5 / deep-orange-7 | deep-orange-7 / deep-orange-5 |
| `--orange-hover` / `--orange-active` | orange-5 / orange-7 | orange-7 / orange-5 |
| `--amber-hover` / `--amber-active` | amber-5 / amber-7 | amber-7 / amber-5 |
| `--lime-hover` / `--lime-active` | lime-5 / lime-7 | lime-7 / lime-5 |
| `--green-hover` / `--green-active` | green-5 / green-7 | green-7 / green-5 |
| `--yellow-hover` / `--yellow-active` | yellow-5 / yellow-7 | yellow-7 / yellow-5 |
| `--turquoise-hover` / `--turquoise-active` | turquoise-5 / turquoise-7 | turquoise-7 / turquoise-5 |
| `--purple-hover` / `--purple-active` | purple-5 / purple-7 | purple-7 / purple-5 |
| `--magenta-hover` / `--magenta-active` | magenta-5 / magenta-7 | magenta-7 / magenta-5 |
| `--indigo-hover` / `--indigo-active` | indigo-5 / indigo-7 | indigo-7 / indigo-5 |

#### 為什麼存在這組 token

**Tag/Avatar 的 solid 色相 dismiss 互動需要**：
- 跟 Button 同樣的 solid color shade change（hover 較亮、active 較暗）
- 跨 mode 一致的方向（dark mode 必須 swap step 號）
- 但 Tag 的「藍」≠ semantic primary（解耦：改 primary 不應影響 Tag）

直接用 primitive `--color-blue-5/-7` 不行——dark mode 公式互換會方向顛倒。所以擴展 semantic 互動 token 模式到全部 12 個 categorical 色相(SSOT `tokens/categorical-color.ts` `CATEGORICAL_HUES`)。

#### 嚴格限制

**只有 hover/active 兩個 token**——**沒有** `--blue` base、`--blue-subtle`、`--blue-text`：

| 用途 | 該用什麼 |
|------|---------|
| Tag/Avatar 的 base bg（solid） | primitive `--color-blue-6` |
| Tag/Avatar 的 subtle bg | primitive `--color-blue-1` |
| Tag/Avatar 的 text on subtle | primitive `--color-blue-7` |
| Tag/Avatar 的 dismiss hover bg | semantic `--blue-hover` |
| Tag/Avatar 的 dismiss active bg | semantic `--blue-active` |

**為什麼故意不加 base/subtle/text？** 那些不需要 mode 翻轉知識（primitives 已處理），加 semantic alias 只會污染命名空間、讓 semantic 層重新引入色相維度(backslide 到廢除的 categorical token layer)。只有 hover/active 真的需要 semantic 層處理 mode swap。

#### 新增非語意色相 hue 互動 token 的步驟

當需要在 Tag/Avatar 加入新色相 variant（例：lime）：

1. **確認 primitive 已存在**：`--color-lime-6` 等（primitives.css 應該已定義）
2. **在 semantic.css 加 hover/active**（light + dark）：
   ```css
   /* :root, [data-theme] */
   --lime-hover:  var(--color-lime-5);
   --lime-active: var(--color-lime-7);

   /* [data-theme="dark"] */
   --lime-hover:  var(--color-lime-7);
   --lime-active: var(--color-lime-5);
   ```
3. **更新 Tag/Avatar 元件**：variant cva 加 lime 條目，SOLID_DISMISS_HOVER 加 lime hover/active
4. **不要加** `--lime`、`--lime-subtle`、`--lime-text`（這些用 primitive 直接消費）

### 新增語意色相的標準流程

每次新增 semantic 色相（例：新增 `--accent` 指向 turquoise）必須**完整執行**這 4 步，不可省略——確保所有 semantic 色相結構一致。

#### Step 1: Primitive（如該色相不存在）

在 `primitives.css` 定義 base-6 值（只需指定 L、C、H），相對公式自動推導 1-10 階。如已存在則跳過。

```css
--color-turquoise-6: oklch(0.64 0.09 196);  /* light 真值(primitives.css:183);dark 另於 dark 區塊定義 */
/* 1-5 / 7-10 自動由公式推導 */
```

#### Step 2: Semantic 五件套（必填）

在 `semantic.css` 的 `:root, [data-theme]` 區塊新增 5 個 token，**不可缺任何一個**：

```css
--accent:        var(--color-turquoise-6);   /* base */
--accent-hover:  var(--color-turquoise-5);   /* hover */
--accent-active: var(--color-turquoise-7);   /* active */
--accent-subtle: var(--color-turquoise-1);   /* subtle bg */
--accent-text:   var(--color-turquoise-7);   /* text on subtle bg */
```

**對應規則**（不可亂改）：
| Semantic role | Primitive step | 為什麼 |
|---|---|---|
| base | -6 | 主色 |
| hover | -5 | 輕微變亮 |
| active | -7 | 輕微變暗（pressed feel） |
| subtle | -1 | 弱化背景（dark mode 自動 alpha） |
| text | -7 | 高對比文字（dark mode 自動反轉方向） |

#### Step 3: Dark mode 反轉（必填）

在 `[data-theme="dark"]` 區塊新增 hover/active 方向反轉：

```css
[data-theme="dark"] {
  --accent-hover:  var(--color-turquoise-7);   /* dark: 仍是較亮 */
  --accent-active: var(--color-turquoise-5);   /* dark: 仍是較暗 */
  /* subtle、text 不需覆寫 — primitives 已處理 */
}
```

**為什麼只反轉 hover/active？** Primitives 在 dark mode 已經：
- 把 step-1 改為 alpha 公式（subtle 自動正確）
- 把 step-5/-7 公式互換（step-7 在 dark mode 仍是高對比方向，所以 text 自動正確）

但 semantic token 直接 reference step number，所以 hover→step-5 在 dark mode 會變成 darker（錯方向）。必須在 semantic 層手動 swap。

#### Step 4: Tailwind Bridge（必填）

在 `semantic.css` 的 `@theme inline` 區塊加入：

```css
--color-accent:        var(--accent);
--color-accent-hover:  var(--accent-hover);
--color-accent-active: var(--accent-active);
--color-accent-subtle: var(--accent-subtle);
--color-accent-text:   var(--accent-text);
```

讓 `bg-accent`、`text-accent-text`、`hover:bg-accent-hover` 等 Tailwind utility 可用。

---

### 檢查清單

新增完一個語意色相，逐項對照：

- [ ] Primitive base-6 已定義（或已存在）
- [ ] Semantic 五件套全部寫齊（base / hover / active / subtle / text）
- [ ] Dark mode `hover` / `active` 方向反轉已加
- [ ] Dark mode `subtle` / `text` 沒亂加（primitives 已處理）
- [ ] Tailwind bridge 五件套全部加齊
- [ ] 命名遵循 `--{name}` / `--{name}-{role}` 模式（不混色相名）
- [ ] 用 `npm run build:lib` 檢查零型別錯誤（根目錄的 `npx tsc --noEmit` 一個檔都不檢查：根 `tsconfig.json` 是 `files: []`，見 AGENTS.md 失敗記憶索引）

## Neutral Interaction

中性互動背景分成**兩個獨立的 family**，對應兩種本質不同的狀態。

### active vs selected

**語意獨立,不可互用**。`--neutral-active` 和 `--neutral-selected` 目前**數值相同**(都是 neutral-2),但語意承載不同的「態」:

| Token | 語意 | 生命週期 | 典型場景 |
|---|---|---|---|
| `--neutral-active` | `:active` 瞬間 click 回饋 | **Transient**（按下去那一瞬間，放開就消失） | Button `:active`、list row 點擊回饋、inline action 按下瞬間 |
| `--neutral-selected` | 持續 toggle on / 長時間選中狀態 | **Persistent**（一直維持直到使用者切換） | Button text pressed、DropdownMenu 單選項目、SelectMenu 單選項目、Tab active、selected menu item |

**判斷法**：「這個狀態在使用者放開滑鼠後還存在嗎？」
- 不存在 → `active`（瞬間回饋）
- 存在 → `selected`（持續狀態）

### 為什麼同值仍分兩個 token

這是 token 層存在的核心價值：**把「值」和「用途」解耦**。

1. **讀 code 的語意清晰**：`bg-neutral-selected` 比 `bg-neutral-active` 更精準表達「這個 element 處於選中狀態」，不需要讀者在腦裡轉換語意
2. **未來演化的安全界線**：若未來要把 click 回饋加強（例：`--neutral-active` 改成 neutral-3），selected 狀態視覺不會被意外牽動
3. **對齊流派原則**：本系統選 Atlassian 流派（Semantic State Token），把互動狀態封裝進 semantic 層——active 和 selected 本來就是兩個語意 <!-- @benchmark-unverified: canonical DS source URL 未驗證(M22(d) 顯式撤回 marker) -->

此原則對齊 Carbon Design System 的 `$layer-*` 族命名（`$layer-active` vs `$layer-selected`），是世界級系統處理「同值不同語意」的標準做法。 <!-- @benchmark-unverified: canonical DS source URL 未驗證(M22(d) 顯式撤回 marker) -->

### Default state family

用於 non-selected element 的互動回饋：

| Utility | Token | 用途 |
|---|---|---|
| `bg-neutral-hover` | neutral-1 | hover 回饋 |
| `bg-neutral-active` | neutral-2 | `:active` 瞬間 click 回饋 |

```tsx
<div className="hover:bg-neutral-hover active:bg-neutral-active">list row</div>
```

### Hover 換色配對總則(2026-09-25)

**範圍:同一個型態之內的滑過與按住,用什麼顏色。** 型態切換(例:未按下 → 已按下)是換到另一個型態,各自有自己的平常色與滑過色(下方階梯表分兩列),不在本條。**要不要有滑過回饋**不在本檔:全 DS 唯一住所是 `ds-canonical/references/hit-area-canonical.md`「滑過原則」—— 底色的滑過回饋只給「點了會有反應」的元素(一-5,user 2026-09-25 #33,原話在該檔),例外清單(資料表格列、圖表的滑過指示)在同節三-2;例外用的顏色一樣照本表「透明 → `--neutral-hover`」那一對。

依元素**平常的底色是什麼**分三種,一句話管完:

| 平常底色 | 滑過 / 按住時 | 理由 |
|---|---|---|
| 透明(列、選單項、文字鈕) | 把底色換成 `--neutral-hover` / `--neutral-active` | 透明底的配對就是這一對 |
| **「底」**:`--canvas` / `--surface` / `--surface-raised`(頁面、卡片、浮層容器這類層色) | **底色不換,在上面疊一層**:`hover:bg-interaction-hover` / `active:bg-interaction-active`(= 把 `--neutral-hover` / `--neutral-active` 畫成 background-image,在底色之上、內容之下,範圍與底色相同;開啟中同滑過,`data-[state=open]:bg-interaction-hover`) | 底是「它在哪一層」的顏色,互動不該把它換成別的東西;深色的 `--surface` 本身是白 8% 半透明,換成 `--neutral-hover`(白 4%)會**變暗**(實測 FileItem 卡片 `#1D1D1D`→`#141414`),按住換成 `--neutral-active`(白 8%)則完全沒反應;疊一層兩個主題、任何容器裡方向都對,與透明列滑過同色。預期值(R14 實測):淺 `#FFFFFF`→滑過 `#FAFAFA`→按住 `#F5F5F5`;深(`--surface` 在頁面上)`#1D1D1D`→`#262626`→`#2E2E2E`。user 2026-09-25 選「採用，底色不換、疊一層 (Recommended)」(題目限定「同一型態下,平常底色是「底」(surface 類)的東西」) |
| 元件自己的填色:`--secondary`、強調與狀態色、`--surface-strong`、`--neutral-selected`(已按下型態)… | 換成**它自己的配對** —— 同一條色階的下一階(`--secondary` → `--secondary-hover` / `--secondary-active`,2026-09-25 新增;淺 `#F0F0F0`→`#E8E8E8`→`#D9D9D9`,深約 `#272727`→`#2F2F2F`→`#474747`,頁面底上計算值) | 填色是元件本身的顏色,照本檔開頭「架構流派定位」的換色流派 |

**借用別的底色的配對一律禁止**(例:有底色的元素換成透明底專用的 `--neutral-hover`)。疊層 utility 是 background-image,已在 `lib/utils.ts` 登記為 tailwind-merge `bg-image` 群組(不登記的話 `cn('bg-surface', 'bg-interaction-hover')` 會把底色刪掉);背景圖不做過渡,`motion/motion.spec.md`「hover 回饋不做過渡」天然成立。

**已按下型態落在「底」上也是疊層**(2026-09-29,待辦總帳 N7):白底 `secondary` 切換鈕(`pressedTone="neutral"`)的靜止底是 `--surface`,已按下三階用 `bg-interaction-selected` / `-selected-hover` / `-selected-active`(= 把 `--neutral-selected` 階梯畫成 background-image)—— 第 2 列的「底不換、疊一層」延伸到已按下;換底的話深色 `--surface`(白 8%)與 `--neutral-selected`(neutral-2 = 白 8%)疊在頁面底上同為 `#1E1E1E`,已按下看不見。淺色疊層結果與換底相同(`#F5F5F5` → `#F0F0F0` → `#E8E8E8`),深色 `#303030` → `#373737` → `#3D3D3D`(頁面底上計算值)。透明底的 tertiary / text 仍換底(`--neutral-selected` 家族是它們自己的填色)。

**巢狀滑過(全 DS 唯一住所;各元件 spec 只寫「怎麼蓋」並指回這裡)**:可點的宿主(卡片、列、分頁)裡還有自己的按鈕時,指到按鈕上 —— 宿主保留自己的滑過色,**按鈕自己的滑過色疊在卡片的滑過色上,沿同一把灰階再往上一階**(淺色更深、深色更亮)。按鈕多半是透明底,它換上的 `--neutral-hover` 本身是半透明,自然疊在宿主那一層上;預期值(R14 §7.3 計算):宿主為「底」時淺 `#FAFAFA`→按鈕 `#F5F5F5`、深 `#262626`→`#2F2F2F`。依據:user 2026-09-25 在「滑到可點卡片內的按鈕上時」一題選「卡片保留、按鈕再亮一層 (Recommended)」(選項由 AI 提供);同日原話「要點了會有反應的才加，並確保加上去之後不會有任何視覺奇怪的地方，且按鈕的互動樣式也是自然疊加上去吧？用再亮一層這樣的措辭是否不夠精準？」(待辦總帳 B12 記為已決)—— 所以規則寫「往上一階」,不寫「再亮」(淺色其實是變深)。套到側欄列、Tabs、DataTable 列與表頭是 AI 依此推導(各元件 spec 標明);與「懸停回饋 = 命中區」的關係見 `ds-canonical/references/hit-area-canonical.md`「巢狀時要逐個控件讀」段:最上面那一層(按鈕自己的)才是這一下會點到的目標。

- 錨例 1(2026-09-25,Calendar 非當月格):靜止 `bg-muted`,滑過卻換成透明底的配對 `--neutral-hover` → 兩個主題都反向(淺 `#F5F5F5`→`#FAFAFA` 變淺、深 `#2F2F2F`→`#262626` 變暗)。修法(026d5788,user 選「可以，拿掉底色 (Recommended)」,選項由 AI 提供)= 格子改回透明,跟當月格同一對。
- 錨例 2(2026-09-07,已按下的切換鈕):已按下的靜止底是 neutral-2,滑過值 `--neutral-selected-hover` 卻指到 neutral-1 —— 等於借了透明底 `--neutral-hover` 的值,按下與未按下在滑過時像素完全相同;改成 neutral-3(自己的下一階)才分得出來(下方階梯表)。
- **能不能當可互動元素的靜止底**:`--secondary` 可以 —— 「Static Subtle Background」段表格 `bg-secondary` 列定義它「存在且微淡可辨 — 元素是正常狀態,但需要退後一級」;`--muted` 不可以 —— 同表 `bg-muted` 列定義它「靜態非互動 surface — 退化 / placeholder / locked 視覺」。(2026-09-25 拿掉原本的行號,本檔一改就漂)
- 疊層只用在「底」:彩色 / 色相色的底、元件自己的填色都換色,不疊(理由見本檔開頭「架構流派定位」)。底色本身換不掉的圖片 / 媒體,改元素自己的不透明度(例:Carousel 圓點,`carousel.spec.md`「視覺規格(photo overlay convention)」)。
- 「底」用疊層是**刻意偏離** Atlassian:[atlassian.design/foundations/elevation](https://atlassian.design/foundations/elevation) 原文 "Elevations use surface color changes to communicate hovered and pressed states"(表面換成 `elevation.surface.hovered` 這類配對 token)。換色派的其他家也沒有「表面疊、其他換」的先例,只有 Material 3 全面疊層([state layers](https://m3.material.io/foundations/interaction/states/state-layers))。畫面效果有前例:Ant 表格列把「表面 + 一層」先算成實心值再換上去([table style](https://github.com/ant-design/ant-design/blob/master/components/table/style/index.ts),`colorFillAlterSolid`)、Adobe Spectrum 2 表格列同理([TableView.tsx](https://github.com/adobe/react-spectrum/blob/main/packages/%40react-spectrum/s2/src/TableView.tsx),`colorMix`)。
- 填色需要的配對還不存在 → 依命名 `--{底}-hover` / `--{底}-active` 新增,值取同一條色階的下一階(2026-09-25 依此新增 `--secondary-hover` / `--secondary-active`);同值不同名照樣分開建(下方「禁止事項」;例 `--secondary-active` 與 `--border` 同為 neutral-5)。按壓怎麼走由各家族自己定(飽和色見「互動狀態推導」;中性見下方階梯表)。

**現有配對一覽**(值見 `semantic.css`;兩個主題各自成立):

| 靜止底 | hover 配對 | 按壓配對 |
|---|---|---|
| 透明(第 0 階) | `--neutral-hover`(neutral-1) | `--neutral-active`(neutral-2) |
| 「底」`--canvas` / `--surface` / `--surface-raised` | 不換色 —— 疊 `bg-interaction-hover`(畫 `--neutral-hover`);FileItem 大卡片(有 `onClick` 時,B12) | 疊 `bg-interaction-active`(畫 `--neutral-active`)—— 目前無使用者(保留;列 / 卡按下不深一階,待辦總帳 N4(2)) |
| `--secondary`(neutral-3) | `--secondary-hover`(neutral-4)—— FileItem 小膠囊(有 `onClick` 時,B12) | `--secondary-active`(neutral-5)—— 目前無使用者(保留;同上) |
| `--neutral-selected`(neutral-2) | `--neutral-selected-hover`(neutral-3) | `--neutral-selected-active`(neutral-4) |
| `--border`(neutral-5) | `--border-hover`(neutral-6) | 無 |
| `--scrollbar-thumb`(= `--border`) | `--scrollbar-thumb-hover`(= `--border-hover`) | 無 —— ScrollArea 拇指、DataTable 原生捲軸(Firefox) |
| `--surface-strong`(neutral-6-opaque) | `--surface-strong-hover`(neutral-7-opaque;淺 `#BFBFBF`→`#8C8C8C` 變深、深 `#737373`→`#A6A6A6` 變亮) | 無 —— PeoplePicker 頭像移除鈕 |
| inverse 底上的透明子元素 | `--inverse-neutral-hover` | `--inverse-neutral-active`(「`--inverse-*` namespace」段) |
| `--primary` / `--info` / `--error` / `--success` / `--warning`(step-6) | `--{名}-hover` | `--{名}-active`(「互動狀態推導」段) |
| 12 色相實心底 `--color-{hue}-6` | `--{hue}-hover` | `--{hue}-active`(「`--{hue}-hover/active`」段) |
| 12 色相淡底 `--color-{hue}-1` | `--color-{hue}-2`(同色離底更遠一格;淺色變深、深色變亮 —— 「Dark mode subtle」段的色階原則,2026-09-26)—— 月曆事件方塊 | 無 |

**`@theme inline` bridge 別名**:`semantic.css` 另定義 `--color-secondary-hover` / `--color-secondary-active`(= 同名 semantic token 的 alias),只為產出 `bg-secondary-hover` / `bg-secondary-active` utility(token-system.spec.md「跨 family `@theme inline` bridge」),**不是第二組語意 token**;改值一律改 `--secondary-hover` / `--secondary-active`。

機械防線:`scripts/hover-own-pair-invariant.mjs`(class 層:同一個元素的滑過 / 按住值必須是自己靜止底的配對;「底」只准疊 `bg-interaction-*`、換成 `--neutral-*` 紅,疊層疊在「底」以外也紅;判到 0 組不印 ✓;已知待拍板的命中登記在 `scripts/hover-own-pair-baseline.json`)+ `scripts/interaction-ladder-invariant.mjs`(token 層:每條 `-hover` 階梯兩兩相異,中性階梯的 hover = 下一階)。

### Selected state family

**互動階梯(2026-09-07 起單調遞增,處處不撞)**:

| | rest | hover | 按壓 |
|---|---|---|---|
| 未按下 | 透明 | `neutral-1`(淺 2% / 深 4%) | `neutral-2`(4% / 8%) |
| **已按下** | `neutral-2`(4% / 8%) | `neutral-3`(6% / 12%) | `neutral-4`(9% / 15%) |

用於持續 toggle on / 選中 element 的互動回饋。**三件（疊加行為 owner = `item-anatomy.spec.md`「選中 × 互動疊加」格)**:

> **2026-09-07 從四件變三件**:`-focus` 退役。原本它表示「鍵盤焦點停在選中列 → 底色深一階」,user 拍板改為**畫框**。同時修正一件先前的錯誤宣稱 —— 舊文寫「四件成套」,但實際上 `-focus` 與 `-active` 都是 neutral-3、`-hover` 與 `--neutral-hover` 都是 neutral-1,**四個名字只有三個相異值**,選中×焦點與選中×按壓在畫面上根本分不出來。退役後名字與值一一對應,宣稱與真實一致。


| Utility | Token | 用途 |
|---|---|---|
| `bg-neutral-selected` | neutral-2 | 持續 selected rest；**選中列被滑鼠 hover 時亦釘住此值不變** |
| `bg-neutral-selected-hover` | neutral-3 | **可取消切換鈕專屬**（**列元件禁用本 token**;選中列滑過釘住,owner `item-anatomy.spec.md`「選中 × 互動疊加」）。**2026-09-07 由 neutral-1 改為 neutral-3(變淺 → 變深)**:neutral-1 正好等於 `--neutral-hover` —— 實測兩主題皆同(淺 2%、深 4%),加上 `variant='text'` 兩態文字色都是 foreground,結果**切換鈕按下與未按下在懸停時像素完全相同**,「這顆開著沒」的訊號在 hover 當下消失。值是 AI 於 2026-09-07 改的(當時 user 是問句);2026-09-25 user 選「甲：保留，維持 2→3→4 (Recommended)」(選項由 AI 提供)。舊文說原值在表達 Fluent 的「hover 預告釋放」,查無一手依據,撤回;舊文「與 Carbon / Atlassian 一致」只對一半,改為:同方向(選中後滑過更強調)的一手前例有 Atlassian 選中鈕 `color.background.selected` → `.hovered` → `.pressed`([all-tokens](https://atlassian.design/components/tokens/all-tokens))與 Carbon 表格選中列 `layer-selected` → `layer-selected-hover`([@carbon/styles 1.116.0 `css/styles.css`](https://cdn.jsdelivr.net/npm/@carbon/styles@1.116.0/css/styles.css) `.cds--data-table--selected:hover`);Carbon 選中的圖示鈕則是滑過不變(同檔 `.cds--btn--icon-only.cds--btn--selected`) |
| ~~`bg-neutral-selected-focus`~~ | — | **2026-09-07 退役**。原用途是「鍵盤焦點停在選中列 → 底色深一階」；user 拍板改為**畫框**（`focus-ring-inset`），底色通道不再承載第二個意義。owner = `patterns/element-anatomy/item-anatomy.spec.md`「選中 × 互動疊加」格 |
| `bg-neutral-selected-active` | neutral-4 | selected 上 `:active` 深一階 click 回饋（**按壓專屬，禁借給 hover／反白**——2026-07-05 D4 曾借用，2026-08-11 糾正）。2026-09-07 由 neutral-3 上調:`-hover` 佔走 neutral-3 後不上調就會變成 hover 與按壓同值 |

```tsx
// toggle button pressed 狀態
<button
  data-state="on"
  className="data-[state=on]:bg-neutral-selected data-[state=on]:hover:bg-neutral-selected-hover data-[state=on]:active:bg-neutral-selected-active"
>
  釘選
</button>

// 列表單選項目
<div className={cn(selected && 'bg-neutral-selected')}>選項 A</div>
```

### 禁止事項

- ❌ 不得用 `bg-neutral-active` 表達持續選中狀態——會造成 class name 語意與視覺行為不符
- ❌ 不得用 `bg-neutral-selected` 作為 `:active` 瞬間回饋——selected 是 persistent，不是 transient
- ❌ 不得因為目前同值就合併為一個 token——語意獨立就該獨立存在

## Static Subtle Background — `bg-muted` vs `bg-secondary` 使用原則(SSOT)

> **2026-05-20 v3 consolidation**(per user directive「全盤查 spec 是否曾寫過具體舉一反三 + 是否有矛盾」):原 L647-678 重複 3 處場景列表 + 「status indicator drift」已移除,本段為**單一 SSOT**。

兩者都是靜態中性背景,但傳達的**元素狀態**不同。**核心問句**:「這個元素是『還沒準備好 / 不可操作 / placeholder』嗎?」

| Token | 答 | 語意 | 典型場景(real consumer grep verified 2026-05-20) |
|---|---|---|---|
| `bg-muted`(neutral-2) | **是** | **靜態非互動 surface** — 退化 / placeholder / locked 視覺 | Skeleton(`skeleton.tsx:10`)/ DataTable 表頭面板(`data-table.tsx:375 HEADER_PANEL`)與虛擬捲動骨架列的 bar(`data-table.tsx:571`,`var(--muted)`)/ Alert neutral(`alert.tsx:30`)/ DataTable filter-panel inner group container(`data-table-filter-group.tsx:212`,2026-07-14 拆檔自 filter-panel)/ Calendar 星期列(`calendar.tsx:556`)/ Coachmark 媒體區佔位(`coachmark.tsx:202`)/ ProfileCard 狀態列(`profile-card.tsx:284`)/ FileViewer 縮圖鈕底(`file-viewer.tsx:639`;縮圖鈕可點,muted 該移到佔位層 —— 待辦總帳 A9③,程式待改)/ scrollbar track(`semantic.css:433`)/ anatomy `<th>`(`stories-helpers/anatomy/anatomy-utils.tsx:27`)。2026-09-27 重掃(`rg bg-muted` 非 story tsx + css,補 5 個漏列、行號全部對齊):舊清單的「tab 容器 / code block」目前沒有真實消費者,已移除 |
| `bg-secondary`(neutral-3) | **否,只是視覺退後一級** | **存在且微淡可辨** — 元素是正常狀態,但需要退後一級 | Tag neutral(`tag.tsx:44`)/ OverflowIndicator「+N」圓(`overflow-indicator.tsx:145`;可 Tab 聚焦、滑過開名單 = 可互動元素,2026-09-26 由 muted 改)與標籤形(`overflow-indicator.tsx:108`,借 `tagVariants` 的中性底,同樣可 Tab 聚焦、滑過開名單)/ Slider rest track(`slider.tsx:111`)/ FileItem compact 靜態小膠囊(`file-item.tsx:442`;有 `onClick` 時滑過換 `--secondary-hover`,B12)/ AgentPanel 訊息氣泡(`agent-panel.tsx:995`)與決策卡選項卡(`agent-panel.tsx:1480`,可點;滑過底色 2026-09-26 user 質疑後拿掉,待辦總帳 R21 研究中)/ Badge low(`badge.tsx:37`)/ CircularProgress track(`circular-progress.tsx:150`,`stroke="var(--secondary)"`)/ Steps fillBg(`steps.tsx:763,776`,`var(--secondary)`)/ ProgressBar track(`progress-bar.tsx:97`)。**站在這個底上而且可點的(小膠囊、選項卡、+N)滑過時換自己的配對 `--secondary-hover`,不借透明底的 `--neutral-hover`**(「Hover 換色配對總則」;2026-09-27 依待辦總帳 N12 補齊可點的使用者並對齊行號)|

**判斷法**:「這個元素是『還沒準備好 / 不可操作』嗎?」
- 是 → `bg-muted`(退化、placeholder 語意)
- 不是,只是視覺上需要退後 → `bg-secondary`(微淡但正常存在)

**為什麼不能反過來**:Skeleton 用 `bg-secondary` 會太深,搶走真正內容出現時的視覺落差;Tag neutral 用 `bg-muted` 會太淡,小面積元素辨識度不足。深淺差一階(neutral-2 vs neutral-3)在小元素上的感知差異比大面積更明顯。

**跟 `bg-neutral-hover` / `bg-neutral-active` 的區別 —— 常駐色 vs 狀態色**(2026-09-27 改寫;原句「即使沒有互動,它永遠是這個顏色」在 2026-09-25「Hover 換色配對總則」立了 `--secondary-hover` 之後已不準):muted / secondary 是**常駐色** —— 元素靜止時的結構層級,沒有互動也是這個顏色;`bg-neutral-hover` / `bg-neutral-active` 是**狀態色** —— 只在指標停上、按住的那一刻出現,放開就消失,而且只給**靜止底是透明**的元素用。兩者的關係:站在常駐色 `bg-secondary` 上的可互動元素(可點的小膠囊、+N、選項卡)滑過時**換成自己的配對** `--secondary-hover` / `--secondary-active`,不借透明底的 `--neutral-hover`(「Hover 換色配對總則」);`bg-muted` 不能當可互動元素的靜止底(上方「能不能當可互動元素的靜止底」條),所以它沒有、也不該有滑過配對。

**邊界 — component disabled bg 不走 muted**:Button / Input / Checkbox 等元件 disabled state 走 `--bg-disabled` semantic,不是 `--muted`(同值 neutral-2 但不同 owner — `--bg-disabled` 是 component-state token,`--muted` 是 surface-non-interactive token,per「為什麼同值仍分兩個 token」段 rule)。**Readonly state 同理但用自己的 token `--bg-readonly`**(2026-06-10):readonly ≠ disabled(可聚焦/選取/提交,僅不可改值,per Carbon「navigable but not operable」),不借 `--bg-disabled` 名;也不走 `--muted`(readonly 是互動元件 state,非 Skeleton 類靜態 surface)。三者同值 neutral-2、owner 獨立,可分離演進。

```tsx
<Skeleton className="h-4 w-32" />            {/* bg-muted — placeholder 語意 */}
<div className="bg-muted">table header</div>  {/* bg-muted — 靜態 surface 退化 */}
<Tag color="neutral">Status</Tag>             {/* bg-secondary — 正常存在但退後 */}
<Badge variant="low">5</Badge>                {/* bg-secondary — 小元素需更明顯底色 */}
```

## 邊框 / 分隔

| Utility | Token | 用途 |
|---------|-------|------|
| `border-border` | neutral-5 alpha 15% | 元件標準邊框（input / Field family / standalone control)|
| `border-border-hover` | neutral-6 alpha 25% | input、checkbox、radio 的 hover 邊框——**未 focus 的欄位 hover 走中性、不搶藍**(2026-07-07 源碼實查:MUI text.primary / Polaris input-border-hover / Fluent NeutralStroke1Hover / Carbon・shadcn 不變 = 多數派;Ant colorPrimaryHover 藍 hover 為少數派不採,藍色保留給 focus / 選中)|
| `border-divider` | neutral-4 alpha 9% | 分隔線（比 border 更淡)/ **table 外框 + row divider 同色**(T-junction connectivity)|
| `border-[var(--border-opaque)]` | neutral-5 opaque | alpha-immune 變體;cell bg 非白(disabled 灰底 / nested surface)時用 |

選中狀態的邊框或文字使用 base token（2026-07-06 拍板：持續選中站 base、hover 階專屬瞬時態——Ant / Atlassian / Material 三家「瞬時弱、持續強」實錘；SSOT = semantic.css「選中狀態」段）：

```tsx
<div className="border-primary text-primary" />
```

### T-junction connectivity 原則(2026-05-04 升 SSOT)

**問題**:Table row divider(horizontal)在 row 兩端 meet table outer border(vertical)。若 outer border 跟 divider **不同色** → 交匯處視覺斷層,user 感「不連續」。

**為什麼不能加重 divider**:divider 是密集分隔 N rows,加重 → 過搶眼,reading flow 被打斷。

**解法**:**淡化 outer border 至 divider 同色**(從 `border-border` 降到 `border-divider`)。交匯處 seamless,divider 視覺重量不變。

**實作**:DataTable outer 用 `border-divider`(對齊 row 內 dividers)。對齊 Ant Design `colorBorderSecondary` idiom — Ant table 外框 + row divider 同 token。 <!-- @benchmark-unverified: canonical DS source URL 未驗證(M22(d) 顯式撤回 marker) -->

**何時 outer = `--border` vs `--divider`**:
- 元件**無 inner divider**(input / Field / Card / Dialog)→ 用 `--border`(獨立邊框,標準視覺重量)
- 元件**有 inner divider**(Table / List with dividers)→ outer 用 `--divider`(同色,T-junction seamless)
- 元件 cell bg **非白底**(FCG disabled cell)→ 用 `--border-opaque`(alpha-immune 變體)

## Utility Tokens

| Token | 用途 |
|-------|------|
| `--overlay` | dialog backdrop 遮罩 |
| `--tooltip` | tooltip 深色底（不透明）|
| `--chart-1` ~ `--chart-5` | 5 色類別標記（Chart 元件 data viz 用；固定到 primitive 而非 semantic — 避免 brand swap 污染 data viz 色義；兩主題都 step-6、淺色的 yellow 用 step-7 提對比(2026-09-26 深色由 step-5 改 step-6:深色 step-5 是 `l × 0.82`,比 step-6 **暗**,舊註解「較淡、提升可讀度」是反的 —— 實測卡片底上藍 2.92、紫 2.20、深橘 2.75,低於圖形 3:1(WCAG 1.4.11);step-6 為 4.51 / 3.45 / 4.39,綠 7.56、黃 11.68。黃在淺色用 step-7 是為了白底對比,深色 step-6 已夠亮。這組數字只住這裡,`semantic.css` 與 `chart.spec.md` 只指回來)）。**Numbered naming = industry canonical**(Material Data Viz palette / Polaris ChartPalette / Carbon Charts colors-N / IBM data-viz / D3 schemeCategory10)— categorical color 本質無 inherent priority,只能 by-index;**1→5 順序 ≠ priority**,只是 consumer 取色 idx convention。色相選擇 rationale:blue(冷靜入門)→ purple(分類二)→ green(成長 / 正面)→ yellow(警戒對比)→ deep-orange(暖色平衡)。Brand swap 不影響 data viz(`--chart-*` 直連 primitive,跳過 `--primary` 等 semantic 中間層)。<!-- @benchmark-cited: Material Data Viz https://m3.material.io/styles/color/the-color-system/color-roles + Polaris https://polaris.shopify.com/tokens/color + Carbon https://carbondesignsystem.com/data-visualization/color-palettes/ + D3 https://d3js.org/d3-scale-chromatic/categorical --> |
| `opacity-disabled` | disabled 元件整體透明度（0.45），用於無法改寫內部色彩的第三方元件 |

`opacity-disabled` 適用場景：包裝第三方元件（如圖表、地圖）的 disabled 狀態，無法逐一替換內部顏色時，直接對容器套用透明度：

```tsx
<div className={disabled ? 'opacity-disabled pointer-events-none' : undefined}>
  <ThirdPartyChart />
</div>
```

自己寫的元件優先用具體的 disabled 色彩（如 `text-fg-disabled`、`bg-[var(--bg-disabled)]`）。`opacity-disabled` 僅作為逃生艙，適用於無法逐一替換內部顏色的場景（第三方元件、複雜多層結構如 Switch）。

## shadcn Compat Aliases(已清除,2026-04-18)

shadcn compat aliases(`bg-background` / `bg-card` / `bg-popover` / `bg-destructive` / `bg-accent` / `border-input` / `*-foreground` 等)2026-04-18 全數移除。新 code 一律用 direct token(`bg-canvas` / `bg-surface` / `bg-surface-raised` / `bg-error` / `bg-neutral-hover` / `border-border`)。`bg-secondary` + `bg-muted` 已升正式語義 token(見 Static Subtle)。

## Nested Theme

任何容器都可以透過 `data-theme="dark"` 或 `data-theme="light"` 切換子元素的色彩語境。最常見的場景是 **Tooltip**——底色是深色，子元素需要 dark token 才可讀。

### 運作原理

CSS 變數在定義元素上解析。`:root` 的 `--foreground: var(--color-neutral-9)` 在 `:root` 就解析成 light 值，子孫繼承的是結果，不是 `var()` 表達式。

為了讓 nested theme 正確重新解析，`semantic.css` 的所有語義 token 定義在 `:root, [data-theme]`。任何帶 `data-theme` 的元素都會重新解析所有語義 token，子元素自動跟隨。

### CSS 結構

```
① :root               — 固定值（--brand，不隨 theme 變）
② :root, [data-theme] — 所有語義 token（default = light 值）
③ [data-theme="dark"] — 只覆寫跟 light 不同的值
```

判斷標準：「這個 token 在 dark 要不要變？」要 → ③ 覆寫。不要 → 只寫在 ②。

### 使用方式

```tsx
// Tooltip：子元素永遠 dark token
<TooltipContent>
  <div data-theme="dark" className="contents">{children}</div>
</TooltipContent>

// 任何容器都可以局部切換 theme
<div data-theme="dark">
  <Tag>dark mode tag</Tag>
</div>
```

容器自身的樣式（如 tooltip 的 `bg-tooltip`）不受子 div 的 `data-theme` 影響——`data-theme` 在子 div 上，只影響子元素。

## 常見誤解

各誤解的完整推理已在本檔對應段落,此處彙整索引:

- 「`--primary` 跟 `--info` 同色所以可互換」— 語義截然不同,status 元件混入 `--primary` 即 fail(見「Status」段 + `status-color-invariant.mjs`)。
- 「`--fg-disabled` 剛好是我要的灰,拿來當 bg」— 跨 family 借用是 smell(見「fg token 不可當 bg 用」段 Slider case)。
- 「`bg-muted` / `bg-secondary` 都是淡灰隨便選」— 前者 = 退化 / placeholder,後者 = 正常存在但退後一級(見「Static Subtle Background」段)。
- 「`--neutral-active` / `--neutral-selected` 同值可合併」— transient vs persistent 語意獨立(見「active vs selected」段)。
- 「categorical `red` = `--error`」— hue 25 vs deep-orange,完全無關(見「消費規則」注意事項)。

## 禁止事項

```tsx
// ❌ 原始色 / 硬碼 → ✅ semantic / primitive
<div className="bg-blue-500" />  <div className="bg-canvas" />
<div className="bg-[#1677FF]" /> <div className="bg-primary hover:bg-primary-hover" />
<div className="bg-[var(--color-blue-6)]" /> // ❌ semantic 場景用 primitive(Tag/Avatar 例外)
// ❌ 深色硬寫 text-white → ✅ <div data-theme="dark"><Tag /></div>
```

## 結構性保留 token canonical
SSOT → `ds-canonical/references/structural-token-retention.md`(canonical owner,不指產生檢視;6 類保留 + sub-agent triple-verify 流程)

---

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `agent-panel-fab.spec.md`
- `agent-panel.spec.md`
- `button.spec.md`
- `calendar.spec.md`
- `chart.spec.md`
- `data-table.spec.md`
- `date-grid.spec.md`
- `file-item.spec.md`
- `file-upload.spec.md`
- `notice.spec.md`
- `opacity.spec.md`
- `progress-bar.spec.md`
- `separator.spec.md`
- `skeleton.spec.md`
- `slider.spec.md`
- `token-system.spec.md`
