---
component: MenuItem
family: 1
variants: {}
sizes:
  sm: {}
  md: {}
  lg: {}
traits:
  - hasInteractiveStates
  - isInternal
benchmark:
  - Radix Menu primitive: github.com/radix-ui/primitives/tree/main/packages/react/menu
  - Ant Design Menu: github.com/ant-design/ant-design/tree/master/components/menu
  - Polaris ActionList: github.com/Shopify/polaris/tree/main/polaris-react/src/components/ActionList
---

# MenuItem 設計原則

## 定位

MenuItem 是所有 menu 類元件的**共用視覺佈局層**——處理 prefix 對齊、尺寸、狀態。SelectMenu、DropdownMenu、未來的 ContextMenu 等都消費它。它只負責 layout（padding、gap、prefix alignment、typography），互動行為由各 menu 的 Radix primitive 外層控制。

**Layout Family**：本元件是 `patterns/element-anatomy/item-anatomy.spec.md` 所擁有的 **Family 1（Menu item layout）** 消費者。結構繼承其「Menu item layout」章節的 scanning-mode 規格。

---

## 結構

```
prefix                                      content               suffix
[checkbox?] [icon? | avatar? | content?]  [label + description?]  [tag?]
```

- **Prefix**：checkbox（多選，由父層注入）+ startIcon 或 avatar 或 startContent（三者互斥）
- **Content**：label + 可選 description
- **Suffix**：tag（ml-auto 靠右）

**`startContent`（2026-07-10 加，WM TypeIcon 彩色徽章需求）**：LucideIcon / Avatar 表達不了的自訂 leading 視覺（類型徽章 = 彩底方塊 + glyph、status 組合點等）。**渲染在同一個 prefix 對齊容器內——佔位與排列邏輯跟 startIcon 一模一樣**（gap / 24px 閾值對齊 / shrink 全繼承 `itemPrefixAlignVariants` SSOT，零平行 layout），consumer 唯一責任是節點尺寸對齊 `ICON_SIZE[size]`（sm/md=16px、lg=20px）。與 `endContent` 對稱（同為自訂 ReactNode slot）。disabled 時容器套 `opacity-disabled`（對齊 `tag` / `endContent` 自訂節點同款處理;**與 `avatar` 不變暗的分界**:Avatar 有自己的 self-dim 體系〔`fieldCtx.disabled` 觸發,同一顆 `opacity-disabled` token,avatar.spec.md「Disabled」段〕,MenuItem 非 Field context 故不觸發;startContent 是任意 consumer 節點、無任何 DS context 可自 dim → 容器套 opacity 是唯一可靠機制。放頭像請用 `avatar` prop 非 startContent）。

prefix icon 跟 label 同色（foreground），不是 fg-muted。詳見 item-anatomy.spec.md 的 Icon 色彩原則。

---

## Prefix 對齊——24px 閾值

所有 prefix 元素（checkbox、icon、avatar）共享同一個對齊容器。容器高度決定對齊行為：

| prefix 最大高度 | 容器高度(原則) | 對齊目標 |
|---|---|---|
| ≤ 24px | 一行 label 高(inline) | 第一行 label 的垂直中心 |
| > 24px | label + gap + 一行 description 的文字塊高(block) | 文字塊的垂直中心 |

**SSOT**:對齊公式(CSS calc 細節)封裝於 `patterns/element-anatomy/item-anatomy.tsx` 的 `itemPrefixAlignVariants`(2026-04-23 重構),spec 不重述公式。MenuItem 消費此 primitive,不自建對齊邏輯;改 gap token(`--item-gap-label-desc-scanning[-lg]`;bare token 已不存在,4 變體見 `layoutSpace.css`)或 font-size token 一處 → MenuItem 自動同步。

**24px 是物理限制**——16px icon 在 24px 圓內仍可辨識(內部 icon 下限 12px),但在更小的容器中 icon 會低於可讀閾值。

**無 description 時 prefix 上限 24px**——沒有文字塊可對齊,強制 inline。

多行文字超過參考高度時，外層 `items-start` 讓 prefix Y 不隨文字下移。

---

## startIcon vs avatar vs startContent(怎麼選)

**一句話判準:看內容「是什麼」,不是看喜好** —— 線性圖示 → `startIcon`;人/實體頭像 → `avatar`;其他任何自訂視覺 → `startContent`。每槽綁不同的自動行為,型別即理由:

| | `startIcon` | `avatar` | `startContent` |
|---|---|---|---|
| 型別 | `LucideIcon` | `AvatarData` | `ReactNode` |
| 角色 | **描述**性質（形容詞） | **代表**身份（名詞） | 圖示/頭像表達不了的視覺(類型徽章、狀態組合點) |
| 尺寸 | 16/20px（**元件自動控**） | 由 description 決定：無 desc → 20/24/24px，有 desc → 32/32/40px(**元件自動推導**) | consumer 自理,對齊 `ICON_SIZE[size]` |
| disabled | 自動 `fg-disabled` 換色 | 不變暗（自有 fieldCtx self-dim 體系） | 容器自動 `opacity-disabled` |
| 對齊 | 永遠 inline（≤ 24px） | 無 desc → inline；有 desc → block | inline(同 startIcon 容器) |

**為什麼三槽而不是一個 ReactNode 口**:合成一口(Atlassian `iconBefore: ReactNode` 式)會失去前兩槽的自動行為 —— 每個 consumer 都得自己記尺寸、自己處理 disabled、自己接 hoverCard = 漂移溫床。世界級同構:MUI List 正是三分 —— [`ListItemIcon`](https://mui.com/material-ui/api/list-item-icon/) 與 [`ListItemAvatar`](https://mui.com/material-ui/api/list-item-avatar/) 是**兩個獨立 wrapper 元件**、任意節點則直接放 —— 我們用 props 表達同一套分工。

### avatar 尺寸推導

inline（無 description）= 對應 size 的 Tag 高度：

| sm | md | lg |
|---|---|---|
| 20px | 24px | 24px |

block（有 description）= `floor₈(1lh + 2px + desc_1lh)`：

| sm | md | lg |
|---|---|---|
| 32px | 32px | 40px |

---

## Size

單行高度對齊 field-height token，與 Button、Input 等互動元件等高。

| Size | 高度 | Label | Description | Icon | Checkbox |
|---|---|---|---|---|---|
| sm | `h-field-sm` | `text-body leading-compact` | `text-caption` | 16px | 16px (sm) |
| md | `h-field-md` | `text-body leading-compact` | `text-caption` | 16px | 16px (md) |
| lg | `h-field-lg` | `text-body-lg leading-compact` | `text-body leading-compact` | 20px | 20px (lg) |

所有文字使用 `leading-compact` (1.3)——選單選項是短文字，不需要閱讀行距。

description 降一級：sm/md 的 label 14px → description 12px；lg 的 label 16px → description 14px。

---

## Suffix 對齊(實作限制)

依 `item-anatomy.spec.md` 的對齊規則,suffix 應該套用 24px 閾值公式(跟 prefix 同公式但獨立判斷)。但 **MenuItem 的實作把 suffix 寫死成 `h-[1lh]` inline 對齊**——只支援 ≤24px 的小 suffix(Tag、ChevronRight、Badge、計數)。

### 為什麼 hardcode

選單選項的 suffix 99% 是小元素,不會超過 24px。為了避免每個 consumer 都要思考 suffix 對齊規則,MenuItem 直接套用最常見的 inline 對齊。

### 限制

如果你要塞大塊 suffix(thumbnail 40px、stacked badge、multi-line text),**MenuItem 會把它對齊到 label 第一行而不是文字塊中心**,視覺上會跟它修飾的對象失聯。

### 解法

需要大塊 suffix 的場景應該:

1. **重新評估這個東西是不是 menu item**——如果 suffix 是大塊內容,可能需要 ListItem(列表行)而非 menu item
2. **包一個 wrapper 元件**——consumer 自己組合 prefix + content + 大塊 suffix,套用 item-anatomy.spec.md 的完整 4-slot 規則
3. 不要 hack `endContent` 塞大東西進去——layout 會壞

---

## Clamp 政策(Label / Description 行數)

| Prop | 預設 | 理由 |
|---|---|---|
| `labelMaxLines` | `1` | 選項是供快速掃視的短文字，必須在一行內辨識完 |
| `descMaxLines` | `1` | 與 label 對稱，維持掃視節奏；description 是補充說明，不是閱讀內容 |

**為什麼 description 也預設 1 行?**

Menu 的設計目的是「**快速掃視多個選項挑一個**」。垂直空間是寶貴的——選單通常要塞 5–20 個選項。如果 description 沒有 clamp,一個過長的 description 會把 item 撐高,破壞 row rhythm,使用者眼睛要重新校準。

整個選單應該只有「**兩種 row 高度**」:
- 無 description → `field-height`(單行 label)
- 有 description → `field-height` + 2px + 一行 desc 高度

不能讓 row 高度變成「label 1 行 + desc 1~N 行」這種不可預測的範圍。

**Per-instance override**:consumer 若有合理理由(例如 settings 選單想顯示 2 行說明),可以顯式 `<MenuItem descMaxLines={2} ...>` 覆寫。要顯示完整不截,傳 `descMaxLines="none"`(不能傳 `undefined`,React props 的 destructure default 在 undefined 時會接管,fallback 到預設 `1`)。

---

## 狀態

| 狀態 | 背景 | 文字 | 觸發方式 |
|---|---|---|---|
| default | transparent | foreground | — |
| hover | `--neutral-hover` | foreground | 滑鼠 hover |
| selected（單選） | `--neutral-selected` | foreground | bg 高亮（不用 ✓ 勾號，避免影響 prefix 對齊） |
| **selected × hover（疊加）** | `--neutral-selected`（**selected 勝,釘住不變**） | foreground | owner = `item-anatomy.spec.md`「選中 × 互動疊加」格(2026-08-11 全家族統一)。2026-07-04 Q2:bg 是唯一選中指示器,hover 不得洗掉;code = selected 時關 hover bg(menu-item.tsx)。對齊 Ant Menu `:not(-item-selected)` / VS Code list `:hover:not(.selected)` |
| **鍵盤焦點／游標（未選中）** | transparent（**不上底色**）+ **畫框**（`focus-ring-inset`,2px 內描邊） | foreground | owner = `ds-canonical/references/focus-canonical.md` 規則二。**user 2026-09-09 拍板**「基本上都是畫框…都不需要上底色」;2026-09-09 之前這格是 `bg-neutral-hover`（與 hover 同色、不畫框,AI 推導自 Material／Radix／cmdk 慣例,已撤回）。本節點拿真焦點的常駐用法,滑鼠若停在游標列上,hover 底色照上方 hover 列另外出現（底色 + 框都在）;巢在 cmdk／Radix 內時反白只有一個主人,鍵盤搬走反白後滑鼠停留列**沒有** hover 底色（owner = focus-canonical 規則一「兩類元件」,2026-09-09 下午）|
| **selected × 鍵盤焦點（疊加）** | `--neutral-selected` + **畫框**（框疊在選中底色上,`focus-ring-inset` 2px 內描邊） | foreground | 同上 owner。**2026-09-07 user 拍板「A5畫框」**:底色已被選中佔走,再深一階等於把兩個意義塞進同一個通道;原 `--neutral-selected-focus` 已退役。**舊文勘誤(2026-08-11)**:先前寫 DropdownMenu「僅鍵盤 cursor 深化」用 `-active`——實作上 Radix 反白滑鼠也觸發(規範與實作不符),且 `-active` 是按壓專屬 token;現已全家統一:滑鼠釘住、鍵盤 `-focus` 深化,無消費者差異 |
| selected（多選） | transparent | foreground | checkbox 勾選 |
| disabled | transparent | `--fg-disabled` | disabled prop |

### 選中指示器

| 模式 | 選中指示器 |
|---|---|
| 單選 | `bg-neutral-selected` 背景高亮 |
| 多選 | Checkbox 勾選 |

單選和 DropdownMenu RadioItem 統一用 `bg-neutral-selected`。不用 ✓ 勾號——勾號在 prefix 會影響群組內對齊。

disabled 時：文字（label / description）與 `startIcon` 套 `fg-disabled`；`checkbox` 套用自身 `disabled` 樣式（非 `fg-disabled`）；`tag` / `endContent` / `startContent` 容器套 `opacity-disabled`（自訂節點自帶配色、不能硬換字色,降透明是唯一通用機制;MUI 佐證:disabled MenuItem 整列 root 直接套 `opacity: disabledOpacity` 連 avatar 都 dim — 我們比它細粒度）；`avatar` 在 MenuItem 內不變暗（Avatar 僅在 disabled Field wrapper context 內自 dim，MenuItem 非 Field wrapper）。

### 浮層關閉行為

| 模式 | 選了之後 | 原因 |
|---|---|---|
| 單選 | **關閉浮層** | 選完就結束 |
| 多選 | **不關閉** | 需要繼續勾選 |
| DropdownMenu CheckboxItem | **不關閉** | 同多選邏輯 |
| DropdownMenu 一般 Item | **關閉** | 執行動作後結束 |

### Prefix icon 色彩

Menu item 的 prefix icon 跟 label 同色（foreground），不是 fg-muted。Prefix icon 是 label 的視覺延伸。

詳見 `item-anatomy.spec.md` 的 Icon 色彩原則。

---

## Group

群組由 `MenuGroup` 包裹,`py-2`(8px)上下內距。群組緊鄰群組無額外 margin——相鄰群組由 `[&+&]:border-t border-divider` 自動分隔(上下 py-2 合計 16px 視覺間距;Pattern A,SSOT 見 `item-anatomy.spec.md`「Group auto-separation」)。

### Group Header

`header` prop 讓 item 變為群組標題：
- `font-medium` (500)
- `text-fg-muted` (neutral-7)
- 不可選、不可 hover
- 尺寸與一般 item 相同

### Message row(訊息列,2026-09-08 user 拍板)

`message` prop(`menu-item.tsx:114,200-219`)讓 item 變為選單裡「不是選項」的提示列——沒有結果 / 沒有選項 / 載入中:
- **用途**:搜尋無結果、打開就沒選項、清單為空時的載入中。owner:`../SelectMenu/select-menu.spec.md`「Empty state」「Loading」
- **樣式,與 header 的差異**:同樣 `text-fg-muted`、非互動(`role="presentation"` + `pointer-events-none`)、與一般 item **完全相同的列幾何**(`ROW_PADDING_BY_SIZE`,列高 = `--field-height-{size}`);差別是**一般字重**(medium 是群組標題的辨識訊號)、內容**水平置中**(`items-center justify-center`)、可帶**前綴槽**(`startContent` / `startIcon`,節點尺寸 `ICON_SIZE[size]`,例如載入列的 `CircularProgress`)
- **必住 `MenuGroup`**:訊息列不自帶邊界留白,由群組的 `py-2` 提供(`item-anatomy.spec.md`「Group auto-separation」)——md 一列訊息 = 8 + 32 + 8 = 48px,與 1 筆選項等高;沒有任何最小高度
- **非互動**:不可選、不可 hover、不進 cmdk / Radix 導覽;SR 播報由外層 live region 或載入列自帶的 `role="status"` 負責(`../Command/command.spec.md`「邊界案例」Loading / Empty)
- **消費者**:`CommandEmpty`(字串 children 自動包成訊息列)/ `CommandLoading`(前綴轉圈 + label,`role="status"`),`../Command/command.tsx:155-188`;SelectMenu / Select / Combobox / PeoplePicker / AgentPanel 歷史清單 / CommandDialog 經 Command 消費
- **禁**:不放裝飾圖示(前綴槽只放狀態指示,如轉圈)、不用 `Empty` 元件(Empty 是頁面 / 區塊層級空狀態)、不手刻 `items-center justify-center` / 最小高度(hook `check_pattern_invariants.sh` C.7)

---

## Footer（列式）

`MenuFooter` 提供固定底部區域（`border-t` + `py-2`，**左右內距 0**）。

**它屬於「列式 footer」**——判準與配方的 owner 在 `../../patterns/overlay-surface/overlay-surface.spec.md`
「底部區域:按鈕列 vs 列式」：底部內容**需要鋪滿容器兩側**（整條可點、整條有滑過底色）時用它，左右 gutter 由列自己帶
（`--item-px`）；底部放的是**按鈕**時改用 `SurfaceFooter`,而且那顆 `SurfaceFooter` 要覆寫成同一行 `px-[var(--item-px,var(--field-px))]` —— 選單沒有 header,footer 的左緣要對齊的是列(判準 owner:`../../patterns/overlay-surface/overlay-surface.spec.md`「要對齊誰」)。同配方的另一個住所是 `components/Sidebar/sidebar.tsx`
的 `SidebarFooter`（放帳號入口那一列），兩者都正確，要改配方兩邊要一起改。

**2026-09-17 起不再用於「全選」**：SelectMenu 的多選全選已依 user 拍板改成 `SurfaceFooter` + 兩態按鈕
（底部放的是按鈕不是列），見 `../SelectMenu/select-menu.spec.md`。

典型用途：需要永遠置底、且**整條要鋪滿**的常駐列（Sidebar 帳號入口是同配方的代表）。

---

## 禁止事項

- ❌ `startIcon` / `avatar` / `startContent` 三者不可同時使用（同一 prefix 位置）
- ❌ 無 `description` 時不可使用 > 24px 的 avatar
- ❌ disabled item 不可有 hover 效果
- ❌ disabled item 內的子元件不可保持 enabled 外觀——文字 / `startIcon` 套 `fg-disabled`、`checkbox` 用自身 `disabled` 樣式、`tag` / `endContent` / `startContent` 套 `opacity-disabled`（`avatar` 在 MenuItem 內維持原樣，因 Avatar 僅在 disabled Field wrapper context 內自 dim）
- ❌ header / message item 不可被選中
- ❌ 不在 item 內放獨立互動元素（如 Button）——item 本身就是互動單位

---

## 何時用 / 何時不用

**MenuItem 是 internal primitive**——不進 root barrel front-door、不裸用；一般透過 `SelectMenu` / `DropdownMenu` 等外層 menu 元件消費；consumer 自建 nav row 等場景可經 per-component subpath 包裝並自行確認後使用（`.claude/rules/ui-development.md`「Root barrel front-door 排除」SSOT，internal ≠ 禁用）。

| 場景 | 正確做法 |
|------|---------|
| 建立操作選單（複製 / 刪除 / 分享）| 用 `DropdownMenu` + `DropdownMenuItem`（內部消費 MenuItem）|
| 建立選值下拉（選項 + 搜尋）| 用 `SelectMenu`（內部消費 MenuItem）|
| 建立右鍵選單 | 用未來的 `ContextMenu`（待開發）|
| 直接在 JSX 中用 `<MenuItem>` | ❌ **禁止**——會失去 menu 外層的 Radix 無障礙 / 鍵盤 / 焦點管理。唯一例外:本元件與 Avatar / Separator / item-anatomy 的**自身 stories** 靜態視覺預覽;該預覽**不得**假裝成選單——容器用 `role="group"`、每個 MenuItem 傳 `role="presentation"`(2026-09-24 訂正,原本容器掛 `role="listbox"` 只為消 axe `aria-required-parent`,但那個容器沒有選取狀態、沒有方向鍵、沒有焦點管理 = 對輔助科技的空頭承諾,SSOT `ds-canonical/references/keyboard-model-canonical.md`「鐵律」)。產品 code 無豁免 |

### 消費者

- `../SelectMenu/select-menu.tsx` — 下拉選單浮層
- `../DropdownMenu/dropdown-menu.tsx` — 操作選單
- `../Command/command.tsx` — CommandItem / CommandGroup 標題(`header`)/ CommandEmpty 與 CommandLoading 訊息列(`message`)
- 未來：ContextMenu、CommandPalette

### 近親分界

| | MenuItem(Family 1) | SelectionItem | List item(Family 2) |
|---|---|---|---|
| 場景 | 浮層選單 row,掃視挑一個 | form 內 Checkbox / Radio 的 label 佈局 | 內容列表 row,閱讀 |
| Clamp 預設 | label / desc 各 1 行 | `'none'` 完整閱讀(SSOT 對照表見 `../Checkbox/checkbox.spec.md`「為什麼不像 MenuItem 強制截斷?」) | 依元件(如 FileItem) |
| SSOT | `item-anatomy.spec.md`「Menu item layout」 | `../SelectionControl/selection-item.spec.md` | `item-anatomy.spec.md`「List item layout」 |

### 常見誤解

- 直接 `<MenuItem>` 進 JSX → ❌(失去外層 Radix / cmdk a11y,見上表)
- 單選選中要加 ✓ 勾號 → ❌,DS 用 `bg-neutral-selected` 高亮(勾號影響 prefix 對齊,見「選中指示器」)
- suffix 可塞大塊內容 → ❌,實作寫死 inline 對齊只支援 ≤24px(見「Suffix 對齊(實作限制)」)

---

## 為何無獨立 StateBehavior story

MenuItem 的狀態色(default / hover / selected / disabled)是**結構性的**——透過 variant(single / multi)× state 的二維矩陣呈現比時序互動更清楚。已在 `ColorMatrix` 用 TOKEN_MAP 完整矩陣覆蓋(單選 multi / 多選 single 各自的 4 state × bg / text / icon / desc token 對照)。

獨立 StateBehavior story 會複製 ColorMatrix 內容——MenuItem 的 state 本身就是色彩表達,無額外「時序 / 動畫」可獨立呈現(不像 Accordion 有 expand/collapse 行為)。Inspector 已互動式展示 selected / disabled 單一 variant 的切換。

對應 anatomy story:保留 `Overview` + `Inspector` + `ColorMatrix`(含完整狀態色矩陣)+ `SizeMatrix` + `Accessibility`。

---

## 邊界案例

- **Disabled**:`disabled` prop 由 MenuItem primitive own;視覺 `text-fg-disabled`(neutral-6,M24 state>emphasis)、無 hover bg、`aria-disabled="true"`(巢狀 `role="presentation"` 用法時抑制、由外層 primitive 宣告,見「A11y 預設」)、Enter / click 不觸發 onSelect、鍵盤導覽自動 skip(由 consumer SelectMenu / DropdownMenu / cmdk 處理)。已在「選擇 / 狀態視覺規則」段 codify。
- **Loading**:MenuItem 為單一 row primitive 非 async surface,本身不擁有 loading prop。Async option list 的 loading 由 consumer(SelectMenu / Combobox / DropdownMenu)在 list body 替換為 `<Empty icon={<CircularProgress/>}/>`(SelectMenu SSOT)。
- **Empty(label-only / icon-only)**:label 為必傳;若無 prefix icon / avatar / checkbox,layout 自動收斂為 `[label] [suffix?]`;若無 suffix(shortcut / endAction / chevron),收斂為純 `[label]`。
- **極長 label / description**:預設各 clamp 1 行 truncate(見「Clamp 政策」),row 高度恆為兩種之一不被撐高。
- **Dark mode**:走 semantic token 自動 adapt。
- **Density**:`size` 由 consumer menu(`Menu` block-tier `compact` / `reading`)決定 row height + padding,MenuItem 自身不持 density state。

---

## 相關

- `../../patterns/element-anatomy/item-anatomy.spec.md` — MenuItem 的 row primitive 繼承規則（prefix / label / suffix 對齊）
- `../Avatar/avatar.spec.md` — Prefix 的 Avatar 尺寸
- `../Checkbox/checkbox.spec.md` — CheckboxItem 的視覺規則（DropdownMenu 使用）
- `../SelectMenu/select-menu.spec.md` — 主要消費者之一
- `../DropdownMenu/dropdown-menu.spec.md` — 另一個主要消費者

## A11y 預設

**ARIA / Pattern**:對齊 [W3C ARIA Authoring Practices Guide](https://www.w3.org/WAI/ARIA/apg/patterns/) 對應 pattern。直接使用時 MenuItem 預設渲染 `role="option"` + `aria-selected` / `aria-disabled`;consumer 把 MenuItem 巢狀在 Radix / cmdk 互動節點內時傳 `role="presentation"`,MenuItem 同步抑制 `aria-selected` / `aria-disabled`(presentation 節點不得掛 ARIA state;ARIA 單一 owner = 外層 primitive),僅保留 `data-selected` / `data-disabled` 供樣式。

**Keyboard 行為**(由外層選單元件提供,MenuItem 本身不實作任何 key handler,只渲染 row 視覺):

- Tab — focus container
- ↑/↓ — 導覽 items
- Enter — activate
- Esc — 關閉(若在 menu context)

以上鍵盤導覽由外層選單元件(SelectMenu 走 cmdk / DropdownMenu 走 Radix)own;MenuItem 為 internal layout primitive,不重複實作鍵盤行為。

**Focus**:鍵盤游標一律**畫框**、不上底色(owner = `ds-canonical/references/focus-canonical.md` 規則二,user 2026-09-09 拍板):cva base 為 `focus-visible:focus-ring-inset`(列撐滿容器 → 內描邊),只有 consumer 給本節點真焦點時才會 match;巢在 cmdk / Radix 內時,游標的框由外層 CommandItem / DropdownMenu 依反白來歷(`hooks/use-input-modality.ts` `useCursorMover`:滑鼠移過搬的反白 → 底色;鍵盤搬的 → 框;兩者不同時出現,外層項目不寫 `hover:`)畫在游標列上。2026-09-09 之前本段寫「以 `bg-neutral-hover` 背景高亮而非畫 outline ring」並附 MUI 對照 —— 那是 AI 推導的慣例,不是 user 決定,已撤回。focus management 由外層元件 own。

**驗證**:Storybook a11y addon panel 應 0 critical violation;鍵盤完整可操作(無需滑鼠)。WCAG AA contrast ≥ 4.5:1(text)/ 3:1(UI)。

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `dropdown-menu.spec.md`
- `item-anatomy.spec.md`
- `select-menu.spec.md`
- `selection-item.spec.md`
- `sidebar.spec.md`
