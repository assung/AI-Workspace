---
component: Sidebar
family: 1
variants:
  default:
    when: "標準導覽 row — 參與 single-selection,fg-secondary → hover foreground / active neutral-selected"
    world-class: ["Linear sidebar nav item", "Notion sidebar item", "VS Code Activity Bar primary item"]
  meta:
    when: "Section 底部命令 row(「Show more」「載入更多」「+ 新增專案」);font-normal + fg-muted,不參與 selection"
    world-class: ["Linear 'Show N more'", "Notion 'Show N more'", "Slack 'Show more'", "Gmail Labels 'More'"]
sizes:
  sm:
    px: 28
    when: "次導覽 / 設定頁分類 / 緊湊空間;對齊 field-height-sm"
    world-class: ["VS Code Settings sidebar(28)", "Atlassian secondary nav compact"]
  md:
    px: 32
    when: "預設 — 應用程式主導覽 row;對齊 TreeView / MenuItem 同 size 視覺無縫"
    world-class: ["Linear sidebar default", "Notion sidebar default", "Figma left panel"]
  lg:
    px: 36
    when: "重要主導覽(高 touch 區、horizontal headroom 大)、icon-prominent workspace switcher"
    world-class: ["Slack workspace sidebar large", "Discord server list large"]
traits:
  - hasVariants
  - hasSizes
  - hasInteractiveStates
  - isStructural
benchmark:
  - Ant Design Layout (Sider): github.com/ant-design/ant-design/tree/master/components/layout
  - MUI Drawer: github.com/mui/material-ui/tree/master/packages/mui-material/src/Drawer
  - Polaris Navigation: github.com/Shopify/polaris/tree/main/polaris-react/src/components/Navigation
---

# Sidebar 設計原則

> **Foundational SSOT rationale**(2026-04-24 approved,cap 800):
> Sidebar 有獨立 `sidebarMenuButtonVariants` cva(對齊 MenuItem 但獨立實作,同步風險見 item-anatomy.spec「SidebarMenuButton 獨立實作風險」)+ 20+ Sidebar-specific features SSOT(Chrome header/footer 高度 / Collapsible / Icon 模式 / SidebarTrigger 位置 / 放不下時 / 持久化 / 快捷鍵 / Group 收合 / Single selection / Inline actions / Keyboard shortcuts),scope > 單一 MenuItem consumer。Full cva consume 提案經二次評估 declined(2026-04-24,詳 `.claude/planning/row-primitive-consolidation.md.rejected.20260424.md`)— ROW_PADDING_BY_SIZE token SSOT 已是 practical best。

## 定位

**應用程式的主導覽外殼**——頁面固定的側邊導覽容器，支援展開 / 收合、放得下並排 / 放不下暫藏或左側浮層(在 AppShell 裡照 `../AppShell/app-shell.spec.md`「版面規則」)、扁平選單與階層樹兩種內容。

**實作基礎**：基於 Radix Collapsible + Radix Slot（shadcn Sidebar 模式改寫）+ 橋接 DS token。

**Layout Family**：本元件是 `patterns/element-anatomy/item-anatomy.spec.md` 所擁有的 **Family 1（Menu item layout）** 消費者。結構繼承其「Menu item layout」章節的 scanning-mode 規格。

**不是**：NavigationMenu（水平導覽）、Tabs（同層切換）、Command Palette（跨頁搜尋）、Sheet / Drawer（暫時性面板）。Sidebar 是**持續存在**的主骨架。

---

## 何時用

- **多頁 app 的主導覽**：Slack、Linear、Notion、Figma 的左側 workspace + channel / project 清單
- **需要在所有頁面持續存在的次導覽**：settings 頁的分類、文件的章節跳轉
- **workspace 切換 + 功能分組並存**：頂部 workspace switcher + 下方常用功能 + 底部 settings
- **需要展開 / 收合但不消失**：放不下時收成細列（icon bar），放得下展開完整 label

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| 頁面頂部水平導覽（單頁品牌、行銷站、電商）| 自訂 Nav / NavigationMenu | Sidebar 專於垂直結構、持續存在 |
| 同層切換內容（總覽 / 成員 / 設定）| `Tabs` | Tabs 切換的是平行視圖，不是跨頁導覽 |
| 暫時性的側邊面板（filter、detail pane）| `Sheet` | Sheet 可以被關閉消失，Sidebar 持續存在 |
| 跨頁搜尋 / 快速跳轉 | `Command`（Cmd+K palette）| Sidebar 是持久清單，Command 是即時查詢 |
| 少於 3 個頂層項目的 app | 頂部 tab bar 或直接頁面 | Sidebar 的視覺成本對小 app 過高 |

---

## 結構

```
SidebarProvider              ← 全域 context（open 狀態、cookie、快捷鍵）
  Sidebar                    ← 主容器（collapsible + side + viewportInsetTop）
    SidebarHeader            ← 頂部：logo、workspace switcher
    SidebarContent           ← 中間可捲動區
      SidebarGroup           ← 分組容器（可多個，純視覺分段）
        SidebarGroupLabel    ← 分組標題（icon 模式自動隱藏）
        SidebarGroupContent  ← 放以下其中一種：
          │
          ├─ SidebarMenu           扁平選單（1 層、有限可列舉）
          │    SidebarMenuItem
          │      SidebarMenuButton   ← icon 模式下 consumer 應確保每個 item 有 icon（否則 collapsed rail 出現空槽；非元件強制）
          │      SidebarMenuBadge    ← 右側 badge
          │      SidebarMenuAction   ← hover 浮出的 action
          │
          └─ TreeView              階層樹（user data、任意深度）
    SidebarFooter            ← 底部：user menu、settings 觸發器
  SidebarTrigger             ← 展開 / 收合按鈕（放 sidebar 外，詳「SidebarTrigger 位置」段）
```

**不使用 shadcn 原版的 `SidebarMenuSub` / `SidebarMenuSubItem`**——見下方內容形態規則。

---

## Size（sm / md / lg）— 透過 SidebarProvider 一次設定

`SidebarProvider` 接受 `size` prop（預設 `"md"`），透過 context 傳給所有 row 元件（`SidebarMenuButton` / `SidebarGroupLabel` / `SidebarMenuSkeleton`）。這對齊 `DropdownMenu` 的 `SizeContext` 架構——**consumer 設一次，整個 sidebar 的 row 都跟著變**。

```tsx
<SidebarProvider size="lg">
  <Sidebar>
    <SidebarContent>
      <SidebarGroup>
        <SidebarGroupContent>
          <SidebarMenu>
            {/* 這裡所有 button 自動繼承 size="lg",不用一個一個傳 */}
            <SidebarMenuItem>
              <SidebarMenuButton startIcon={Inbox}>Inbox</SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>
    </SidebarContent>
  </Sidebar>
</SidebarProvider>
```

**個別覆寫**（少見）：若某個 button 特別需要不同 size，可在 `SidebarMenuButton` 傳 `size` prop 覆寫 context 值。

**Row geometry 對齊 item-layout**：sm/md/lg 三個 size 的 row height / text size / icon size 跟 `TreeView` / `MenuItem` 完全一致——跨元件視覺無縫。

**Row size 跟 density 的差別**：
- **Size variant**（sm/md/lg）是 **consumer 的風格選擇**，決定 sidebar 整體 row 大小
- **Density**（md/lg）是**全域 UI 設定**,影響所有 `--field-height-*` tokens 的實際值
- 兩者**獨立**:size="md" 在 density="md" 下是 32px row、在 density="lg" 下自動變 36px row

**Chrome header 不跟 size 變**：`SidebarHeader` 固定用 `var(--chrome-header-height)`,只跟 **density** 連動,不跟 `size` prop 變——因為 header 是結構槽位,不是 row。**SidebarFooter 修正(2026-06-12 doc-to-code)**:footer 實作自 2026-04-14 起為 content-based(`flex flex-col py-2`,sidebar.tsx SidebarFooter,行為同 SidebarGroup),**非** fixed-h——單行高度由下方內容紀律保證,非結構鎖。

**SidebarFooter 屬「列式 footer」(2026-09-17 codify)**:配方(`border-t` + `py-2` + **左右內距 0**)與判準的 owner 在
`../../patterns/overlay-surface/overlay-surface.spec.md`「底部區域:按鈕列 vs 列式」—— 底部內容需要**鋪滿容器兩側**時用這個配方,
左右 gutter 由列自己帶;底部放**按鈕**則用 `SurfaceFooter`。同配方的另一個住所是 `components/Menu/menu-item.tsx` 的 `MenuFooter`。
**本元件實作正確、不需更動**,此段只是把它掛進共同的判準 owner,避免兩處各自演化。

**SidebarFooter user 區必單行(2026-06-12 明文,fork drift 防線;2026-07-30 帳號選單修正)**:名字單行(`text-body-lg` truncate)。footer user 行 = **帳號入口**,點開**帳號選單(`DropdownMenu`)**;職稱/email/工號等身份資訊歸帳號選單頂部 `DropdownMenuLabel` 第二行(`text-caption`)。**自己的 avatar 不掛 ProfileCard hoverCard**(ProfileCard 是看「別人」的人員卡;rule owner = `../AppShell/app-shell.spec.md`「帳號入口(Account entry)放置 SSOT」的「入口開什麼」段,本處不重述)。(UserFooter canonical,sidebar.stories.tsx)。shadcn nav-user 的「name + email `text-xs` 兩行」是 demo 慣例非本 DS canonical(`text-xs` 同時違反下方 chrome typography 一律 `text-body-lg` 條);registry antiPattern `sidebar-footer-two-line` 機械攔。

**SidebarHeader brand 必單行(2026-06-12 明文,fork drift anchor)**:Avatar 24 + 名稱單行,**無副標 slot**——Fixed-h chrome 結構上不可成長;plan/org 等第二行資訊歸 workspace switcher dropdown row,對齊 Slack/Notion/Linear 現行版單行。shadcn TeamSwitcher demo 的「Acme Inc + Enterprise」兩行是 demo 慣例非本 DS canonical(fork repo AI 曾以訓練先驗在 spec 沉默處回填此副標)。Registry antiPattern `sidebar-header-subtitle-second-line` 機械攔(flex-col 直接子層簽名)。

---

## 內容形態選擇（核心設計決策）

Sidebar 有兩種正交的內容形態，consumer 嚴格擇一或混用：

| 形態 | 元件 | 深度 | 數量 | Icon 模式 |
|------|------|------|------|----------|
| **扁平導覽** | `SidebarMenu` | **嚴格 1 層** | **有限可列舉** | ✅ 顯示 icon(hover tooltip 為 opt-in,需 per-button 傳 `tooltip` prop) |
| **階層樹** | `TreeView` | 任意 | 任意 | ❌ 整區隱藏 |

### 判斷規則

> **SidebarMenu 只接受「1 層 + designer 能在設計時列舉所有項目」**。
> 任何不符合的情況——深度 > 1、數量不可列舉、使用者可 runtime 新增——一律 TreeView。

### 為什麼只有 1 層

Linear、Slack、VS Code、Figma、Gmail——**沒有任何頂級產品在 sidebar 主選單用語意階層**。凡有階層都是 TreeView（user data）或 SidebarGroup（純視覺分段）。Notion 的 sidebar 有巢狀,但那是**頁面(user data)的樹**、不是選單階層:Notion 說明頁逐字 "you can nest pages inside other pages with no limit" / "You can open up each toggle in your sidebar to reveal pages nested inside other pages"(https://www.notion.com/help/navigate-with-the-sidebar)—— 正是「階層 = TreeView(user data)」那一邊的例子,不是反例(2026-09-29 更正:先前把 Notion 列在「沒有階層」那一組是憑印象)。shadcn 的 `SidebarMenuSub` 是 demo 便利 API，本 design system 完全不 export，避免誤用。

### 「Projects > A / B」這類

User-generated data **一律 TreeView**，不論數量——即使現在只有 3 個 project，未來會長。唯一例外是 designer 在設計時就固定死的 5 個 module 後台，這種情境極少。

### Settings 這類有子頁的頁面

三條正確路徑，**全部不用 SidebarMenuSub**：

#### 路徑 A：In-page secondary nav（推薦，最世界級）

Sidebar 只放一顆 `Settings`，點進去後在 **Settings 頁面內部**用左側 rail 或 Tabs 呈現子頁。子頁屬於 Settings 頁面的內部狀態，不佔 sidebar 位置。

代表：Linear（modal + 左 rail）、GitHub（repo settings 頁內 rail）、Notion（modal + tabs）。

#### 路徑 B：SidebarGroup 扁平化

子頁等重要、都需一鍵直達時，用 SidebarGroupLabel 當純視覺分段標題，**子項全部是獨立頂層 SidebarMenuItem**（各自有 icon、各自在 icon 模式顯示）。

僅在子項確實高頻使用時才用，少見。

#### 路徑 C：User menu modal

Settings 不在 sidebar，從 footer 的 avatar / user menu 觸發 modal 或快捷鍵（`Cmd+,`）。適合低頻操作。

代表：Linear、Slack、Discord。

#### A 和 C 並用

大型產品通常**同時有 A 和 C**，依設定性質分流（Linear 的實際做法）：

- **路徑 A**：功能性設定（workspace settings、project settings、team members、integrations）—— sidebar 有入口，點進去是完整頁面 + 內部 secondary nav
- **路徑 C**：個人偏好（theme、language、keyboard shortcuts、personal notifications）—— 從 user menu 叫出 modal，不佔 sidebar

判斷：**需要協作、會分享連結給別人看的設定 → A**；**只影響自己、低頻的偏好 → C**。

### 混用

Gmail / Linear 的標準版型：上方 SidebarGroup 放扁平主導覽（SidebarMenu），下方 SidebarGroup 放 user data（TreeView）。icon 模式下，扁平區顯示 icon（hover tooltip 需 per-button 傳 `tooltip` prop），TreeView 整段隱藏。

---

## Variant（視覺形態）

目前只有一種：**`sidebar`**（貼齊 viewport 邊緣、與主內容共用邊界）。

**已移除 / 未實作的 variant**：
- **`floating`**（脫離邊緣的浮動面板）：**刻意不做**。沒有可靠的「收合後預覽」互動（hover flyout 是 NN/g 反模式），單純換個圓角陰影的 floating 跟 `sidebar` 在功能上無差，徒增維護成本。如果未來需要卡片感，改用 `inset`
- **`inset`**（主內容浮起卡片）：規劃中，未實作

---

## Chrome header / footer 高度：density-responsive shared token

`SidebarHeader` 的高度 = `var(--chrome-header-height)`，**不是寫死**，也**不是完全 content-based**(SidebarFooter 為 content-based,見上方 2026-06-12 修正)。這個 token：

> **跨家族 SSOT pointer**:本元件 SidebarHeader 屬 **Chrome header(Fixed-h)家族**;border / padding / dismiss size / withTabs(tabs 進 header 時 border auto-suppress + tabs size 對應 + flush stack)的跨家族視覺契約 SSOT 詳 `patterns/header-canonical/header-canonical.spec.md`。本節僅 codify Sidebar 特有的高度 + token rationale。

- md density: `3rem`（48px）
- lg density: `3.5rem`（56px）
- **跨元件共享**：sidebar header、主內容 page header 都用同一個 token(sidebar footer 為 content-based,見上方 2026-06-12 修正)
- **隨 density 同步變**

### 為什麼是這個設計（不是 h-12 寫死 或 py-3 純 padding）

| 方案 | 外部對齊 | 內部 padding 比例 | 世界級？ |
|---|---|---|---|
| A. 寫死 `h-12`（48px） | ✅ 跨元件同高 | ❌ lg density 下 button 撐高,chrome 固定 → padding 被擠壓到不足,比例破壞 | ❌ 破功 |
| B. 純 padding `py-3` | ❌ 不同 header 因 content 高度不同，無法對齊 | ✅ 內部 padding 固定 | ❌ 對齊破功 |
| C. **Density-responsive token**（本方案） | ✅ 跨元件同高（共享 token） | ✅ token 隨 density 放大，padding 比例維持 | ✅ |

**關鍵洞察**：chrome 的 content（button、icon）本身就是 density-responsive 的（綁 `--field-height-*`），chrome 容器如果不跟著 density 變，必然會擠壓。所以 chrome **必須跟 density 連動**，但**透過專屬 token，不直接綁 item size**。

### 比例驗證

| Density | Header | Button md | 上下 padding |
|---|---|---|---|
| md | 48px | 32px | 8px |
| lg | 56px | 36px | 10px |

比例維持一致，跨 density 視覺一致。

### 不隨 item size variant 變

`SidebarMenuButton` 的 `size="sm/md/lg"` 是 **row 層級的選擇**（consumer 決定內容列的尺寸），跟 chrome 無關。Header 只跟 **density**（全域設定）綁定。

### Chrome 內容的約束

放在 SidebarHeader（固定高度 `--chrome-header-height`）裡的元件必須能容納在這個高度內（**SidebarFooter 為 content-based，高度隨內容 flex、不受此固定高度約束**）：

- Avatar: `size={24}` —— **chrome header avatar canonical（density-fixed / row-size-fixed）**。consumer 用 **raw `<Avatar size={24}>`**（chrome header 不是 row context → 不該用 `<ItemAvatar>`）。對應 CSS local token `--chrome-header-avatar-size: 1.5rem`（`header-canonical.css`），sidebar 收合對齊公式消費此 token。詳 `header-canonical.spec.md`「4.5 Chrome header avatar SSOT」段 + `item-anatomy.spec.md`「Scope 例外:Chrome header 不是 row context」段。
- Button: `size="sm"` 或 `size="md"`
- 單排 title 文字 + icon button

**不要**放超出高度的內容（多行 title、大按鈕等）——如果需要，代表誤用 header，改用獨立的 `SidebarContent` 區塊。

### 跟 Modal header 的差別

Modal header 用 **padding-based**（`py-3` + content），因為 modal 是 ephemeral（自成一體），不需要外部對齊。兩種規則都是世界級，各自適用：

- **Chrome**（sidebar / page header）：共享固定高度 token，density-responsive → 保證跨元件對齊
- **Ephemeral**（modal / dialog）：padding-based → 保證內容適應性

### Chrome 內的 text element:統一 typography

所有住在 chrome header / footer 裡的 text element(workspace brand、page title、user name)**一律使用 `text-body-lg font-medium`**。

**原則:chrome 元素是 sibling,不用 size/weight 製造假階層**
- 不同 size → 會造成假階層,好像「A 是 B 的副標題」;chrome elements 實際上是並排的結構槽位,沒有從屬關係
- 不同 weight → 會造成「哪個比較重要」的語意混淆
- **「當前位置」的訊號由 sidebar active item(`bg-neutral-selected`)負責**,不靠 page title 的字重搶戲

### Chrome typography 選擇

本 DS 選 **`text-body-lg font-medium` 統一**：16px 保留 chrome 中的可讀性，medium 足以標示結構但不會壓過頁面內容。workspace brand、page title 與 user name 共用同 size / weight，層級改由 slot 位置與 active state 表達，不在固定高度的 chrome 裡製造假主從。

---

## Collapsible（收合模式）

| Mode | 說明 | 適合 |
|------|------|------|
| **`offcanvas`** | 整個 sidebar 滑出畫面 | 內容優先、低頻導覽（Notion、Figma） |
| **`icon`** | 收合為 icon-only 細列，頂層 icon 仍可見可點 | 扁平導覽、高頻跨頁切換（Gmail、Slack）。**前提：所有 SidebarMenuItem 必須有 icon + 可導覽** |
| **`none`** | 不可收合 | 超簡單應用或 sidebar 是頁面核心（file explorer）。**不能用在 AppShell 的 Menu 位置**（`../AppShell/app-shell.spec.md`「版面規則」§12） |

**收起後的寬(單獨使用與在 AppShell 裡同一條)**:`offcanvas` 收起 = 0、`icon` 收起 = `--sidebar-width-icon`、展開 = `--sidebar-width`(在 AppShell 裡 = AppShell 給的寬)。寬度只由 `sidebar.tsx` 一個判斷式算出,「寬 0 時裡面的選單項 `inert` + `aria-hidden`」也從同一個值導出(見下方「放不下時」)。**不得**用 `group-data-[collapsible=…]:w-…` 寫在帶 `group` 的那個元素自己身上 —— Tailwind 的 `group-data-*` 編譯成後代選擇器,比不到 group 本身,寬度靜默不變(2026-10-14 單獨使用的 Sidebar 因此收起後仍 240 寬,offcanvas 還把看得到的選單設成不可操作;2026-10-15 r1b 複驗 F1)。機械閘 `scripts/sidebar-standalone-collapse-invariant.mjs`(真按開關量收起後外框寬與選單可點;靜態掃全 DS 沒有 `group` 自己用 `group-*` 變體)。

---

## Icon 模式的行為規則

### 規則 1：icon rail 上的每顆 icon 必須可導覽

絕對不可有「點了沒反應」或「點了只是展開選單」的 icon。icon 列是收合狀態下唯一的導覽介面。

### 規則 2：純分組 header 不可用 SidebarMenuItem

只是用來分組下方 children（沒有自己的頁面）的項目，**必須用 SidebarGroup + SidebarGroupLabel**。`SidebarGroupLabel` 在 icon 模式自動隱藏，子 items 照常顯示；`SidebarMenuItem` 則會變成死 icon。

### 規則 3：TreeView 在 icon 模式整個隱藏

不做 icon 化、不做 flyout、不做 popover。Tree 無法壓縮成單排 icon，Gmail / Linear / Notion 一致隱藏。

### 規則 4：重新看階層資料的唯一路徑 = 展開 sidebar

不提供「點 icon 順便展開」的副作用——行為不可預測，熟練使用者要收合兩次。逃生艙由應用層搭配 Command Palette（Cmd+K）提供，不是 Sidebar 的責任。

---

## SidebarTrigger 位置(兩種 canonical pattern)

**核心判準**(唯一):**trigger 必須在 sidebar 任何 state(offcanvas 收掉 / icon / expanded)下都保持可見**。違反這條 = dead state(offcanvas 收掉就再也打不開)。

兩種 canonical pattern,都符合判準,選哪種看 app shell 的整體 layout:

### Pattern A:Full-height sidebar + 主內容 header

- Sidebar 從畫面頂部一路延伸到底部
- 主內容區自帶 header(page title bar)
- **Trigger 位置**:主內容 header 的最左(在 page title 之前)
- **代表**:Linear / Notion / Figma / Cursor / VS Code / Slack

### Pattern B:Global top app bar + sidebar drawer

- 頂部 bar 跨整個畫面寬度(包含 sidebar 跟 main content 的水平範圍)
- Sidebar 在 top bar **下方**,只佔頁面剩餘高度
- **Trigger 位置**:top bar 的最左(視覺位置在 sidebar 上方對齊,實際屬於 top bar 的一部分;top bar 永遠存在,所以 offcanvas 收掉 sidebar 後 trigger 仍然在)
- **代表**:**Gmail / Google Calendar / Google Drive / Material Design apps** / 多數企業 dashboard

### 判斷:trigger 在哪 = top bar 在哪

```
Pattern A(無 global top bar):
┌────────┬─────────────────┐
│        │ ☰  Page Title   │  ← trigger 在主內容 header 最左
│Sidebar │                 │
│        │  (content)      │
└────────┴─────────────────┘

Pattern B(有 global top bar):
┌──────────────────────────┐
│ ☰  Logo  Search    Nav   │  ← trigger 在 global top bar 最左
├────────┬─────────────────┤
│        │                 │
│Sidebar │  (content)      │
│        │                 │
└────────┴─────────────────┘
```

**搭配鍵盤快捷**:`⌘B` / `Ctrl+B` 是 industry-standard,已內建,不該改。

**禁止**:

- ❌ Trigger 放在 sidebar **內部** sidebar 元件之內(SidebarHeader 內)——offcanvas 收掉就消失,dead state
- ❌ 放在 header **最右**——違反 F-pattern 閱讀動線
- ❌ 使用浮動按鈕 / FAB——mobile app pattern,跟桌面 sidebar 語意不合
- ❌ 同一 app 內混用兩種 pattern——使用者肌肉記憶失效

**判斷你的 app 該用哪個**:

- 有 global top bar(logo / search / 全域 nav 在頂部)→ **Pattern B**,trigger 在 top bar 最左
- 沒有 global top bar(每個頁面自己 header)→ **Pattern A**,trigger 在主內容 header 最左
- 介於兩者之間 → 看主導需求,但 **不要混用**

---

## Sidebar 全域 prefix 對齊(`uniformPrefix`,預設關閉)

`<SidebarProvider>` 預設 `uniformPrefix={false}`——大宗情境(全 icon 主導覽 / 全 avatar user 列表 / 純 TreeView)各自獨立節奏即可,**不需要這個 prop**。

### 什麼時候 opt-in `uniformPrefix={true}`

**唯一明確的場景:sidebar 內有大量 brand logo 和一般 icon 混用,使用者期待 label 齊左**。

具體 use case:

- **Linear / Raycast / Notion 風格的 integrations 清單**:主導覽是 lucide icon(Home / Inbox / Team,16px),底下接著一串 integrations(GitHub / Slack / Figma / Jira,24px brand logo)。兩種 prefix 都是「導覽目的地」,語意等價,只是 visual hint 不同——使用者期待 label 齊左掃視
- **App launcher / workspace switcher**:每個 workspace 有自己的 brand logo,夾雜系統性的 icon-based 項目
- **CMS / connected apps**:每個來源(Notion / Google Docs / Confluence)有自己的 logo,跟 icon-based 的「我的草稿」「最近開啟」等並列

**不是這個 use case 就不要開**:

- ❌ 全 icon 主導覽 + 全 avatar 的 user footer → 語意不同層級,應該分 SidebarGroup,不該強迫對齊
- ❌ 純美感「我覺得對齊比較整齊」沒有真實混用情境 → 預設行為已經對(全 icon 自然就齊左)
- ❌ 偶爾一兩個 avatar 混在 icon 群裡 → 通常代表設計分組沒做好,先檢查語意,別用 `uniformPrefix` 補

### API

```tsx
// 預設:大宗情境,不需要這個 prop
<SidebarProvider>
  <Sidebar>...</Sidebar>
</SidebarProvider>

// Opt-in:有 brand logo + icon 混用的 integration sidebar
<SidebarProvider uniformPrefix>
  <Sidebar>
    <SidebarContent>
      <SidebarGroup>
        <SidebarMenu>
          {/* 主導覽:icon prefix */}
          <SidebarMenuButton id="home"  startIcon={Home}>Home</SidebarMenuButton>
          <SidebarMenuButton id="inbox" startIcon={Inbox}>Inbox</SidebarMenuButton>

          {/* Integrations:brand logo prefix(同 menu,語意等價)*/}
          <SidebarMenuButton id="github" asChild>
            <button>
              <ItemAvatar shape="square" alt="GitHub" src="/logos/github.svg" />
              <ItemLabel>GitHub</ItemLabel>
            </button>
          </SidebarMenuButton>
          <SidebarMenuButton id="slack" asChild>
            <button>
              <ItemAvatar shape="square" alt="Slack" src="/logos/slack.svg" />
              <ItemLabel>Slack</ItemLabel>
            </button>
          </SidebarMenuButton>
        </SidebarMenu>
      </SidebarGroup>
    </SidebarContent>
  </Sidebar>
</SidebarProvider>
```

`uniformPrefix` 開啟後:`Home` / `Inbox` 的 16px icon 在 24px 槽內 `justify-center`,`GitHub` / `Slack` 的 24px logo 填滿槽——四個 label x 完全對齊。

### 機制細節

- 啟用後,`SidebarProvider` wrapper 的 CSS `:has()` selector 偵測整個子樹同時存在 `data-prefix-type="icon"` 和 `"avatar"` 的後代(由 `<ItemIcon>` / `<ItemAvatar>` 自動標記)
- **混用偵測命中** → 套用固定 24px 槽
- **沒混用** → 偵測失敗,完全 no-op,行為跟預設一樣(零 runtime 成本)

所以即使你預設開啟 `uniformPrefix`,只有真正混用時才會動到排版。但**我們仍然預設關閉**,因為:explicit > implicit——consumer 沒主動要求,系統不該在背後做事,源碼讀起來才透明。

### 為什麼預設關閉(不是 always-on auto)

CSS `:has()` 不混用時零成本,理論上 always-on 也沒事。我們刻意預設關閉的理由是 **API 立場**:

1. **Explicit > implicit**:CSS auto-detect 是「藏在背後的魔法」。預設關閉表示「sidebar 的排版行為從你寫的 prop 一眼看出」,沒有隱含規則
2. **強迫 consumer 想清楚 use case**:打 `uniformPrefix` 一個字代表「我有意要做混用對齊」,reviewer / 未來維護者讀到這個 prop 就知道為什麼

### 沒有 per-menu override

`SidebarMenu` 不接 `uniformPrefix`。曾經設計過(三層級組合),但零真實 caller。如果未來需要「全域對齊但這個 menu 不對齊」這種精細控制,那時候會有具體 use case 推導出正確 API,而不是現在猜想。

詳細實作機制(`<ItemIcon>` / `<ItemAvatar>` 自動標記 `data-prefix-type`、`getUniformPrefixSlotStyle()` 算槽寬、CSS variable cascade)見 `item-anatomy.spec.md` 的「Uniform prefix slot」節。

---

## SidebarMenuButton variant

| Variant | 視覺 | 語意 | Single selection | 典型用法 |
|---|---|---|---|---|
| **`default`**(預設) | `text-fg-secondary`, `font-medium`, active → `bg-neutral-selected` | 導覽目的地(nav item) | ✅ 參與,接 `id` prop | Dashboard / Inbox / Settings / user data item |
| **`meta`** | `text-fg-muted`, `font-normal`, **永不 active** | 命令 row(非導覽) | ❌ 不參與,不傳 `id`(傳了也會被忽略) | 「查看更多」/「載入更多」/「+ 新增專案」/「Show all」 |

**為什麼需要 meta variant**:section 底部的「查看更多」如果用 default variant,會有三個問題:

1. 視覺重量跟真正的 nav item 相同 → 使用者誤以為是另一個資料項
2. 會被選中變 active → 搶走真正 nav item 的 selection 焦點
3. consumer 得手動覆寫 `className="text-fg-muted"`、手動不傳 id → 每個 consumer 都有可能漏

variant=meta 把這三件事做成結構性保證:樣式自動退、selection 自動跳過、型別層不需要特判。

**API**:

```tsx
<SidebarMenuButton
  variant="meta"
  startIcon={ChevronDown}
  onClick={loadMore}
>
  查看更多 (12)
</SidebarMenuButton>
```

**命令 row 語意**:meta item 固定放在 section 底部，以 muted 視覺表明它會展開更多資料，而不是另一個可被選中的導覽項目。

**禁止**:

- ❌ meta variant 傳 `id`——語意矛盾,meta 不該參與 selection
- ❌ default variant 手動 `className="text-fg-muted"` 模擬 meta 效果——改用 `variant="meta"`,結構對齊
- ❌ meta variant 放在 section 中間——meta 只屬於 section **底部**,位置本身是「這是尾巴」的訊號

---

## Single selection（整個 sidebar 同時只有一個 active item）

**規則(UX 語意)**:不論 MainNav / TreeView / Favorites / 任何 group,**同一時間只有一個 item 被選中**——sidebar 的核心語意是「當下在哪頁」,多個 active 就失去意義。

**結構性保證(範圍 = `SidebarMenuButton`)**:`SidebarProvider` 內建 single-selection state,`SidebarMenuButton` 接 `id` prop 自動從 context 讀 `isActive`、自動在 `onClick` 呼叫 `setActiveId`。**此結構保證僅涵蓋 `SidebarMenuButton`**:`TreeView` 用自己獨立的 `selectedIds` state、不接 `SidebarContext`,**沒有元件層級的 cross-family auto-deselect**——跨 TreeView 的單選需 consumer 用同一份 `activeId` state 手動橋接(SidebarMenu 與 TreeView 都讀寫同一個 state,見 principles『啟用狀態跨群組單一』story)。

```tsx
// Controlled(router-driven,typical production 用法)
<SidebarProvider activeId={currentPath} onActiveChange={router.push}>
  <SidebarMenuButton id="/dashboard" startIcon={LayoutDashboard}>Dashboard</SidebarMenuButton>
  <SidebarMenuButton id="/inbox"     startIcon={Inbox}>Inbox</SidebarMenuButton>
</SidebarProvider>

// Uncontrolled(demo / simple app)
<SidebarProvider defaultActiveId="dashboard">
  <SidebarMenuButton id="dashboard" ...>Dashboard</SidebarMenuButton>
</SidebarProvider>
```

**為什麼結構性強制**:過去曾寫出「忘記接 isActive / onClick 的啞 item」(stories 展示 inline action 時發生)— 外觀提供可點擊 affordance 但事件未連 state,產生誤導性互動(click 後永遠不進 active)。把 selection state 內建到 Provider、讓 button 接 `id` 就自動 wire,consumer **無法**寫出啞 item——沒傳 id 就失去 selection 能力,一眼看得出來。

**禁止**:

- ❌ SidebarMenuButton 不傳 `id`(除非確定這個 item 不參與 selection——極罕見,例如純按鈕 action)
- ❌ 手動維護每個 group 獨立的 activeId(違反 single-selection,會出現兩個 active)
- ❌ 同時用 `id`(自動)和 `isActive`(手動覆寫),除非 consumer 有明確的 override 理由(例如 router 尚未更新的 optimistic highlight)

**Router integration**:production 用法通常是 controlled mode——從 URL 算 `activeId`,`onActiveChange` 呼叫 router.push。uncontrolled mode 主要是 demo / Storybook 用。

---

## SidebarGroup 收合（`collapsible` prop）

`<SidebarGroup collapsible>` 把整個 group 升級成可點擊收合。內部用 Radix Collapsible 實作,**三件事自動發生**:

1. `SidebarGroupLabel` 本身仍是純裝飾 header(`div` `role="presentation"`),**只有尾端的 chevron** 是 trigger（`Collapsible.Trigger asChild` 包住 `ItemInlineActionButton`，帶 hover bg / `cursor-pointer`）——刻意不把整個 label 升格為 button，理由見下方 rationale
2. Label 尾端自動渲染 `ChevronDown` icon(accordion 慣例),open 時旋轉 180°;旋轉吃原地展開那一檔 `disclosureIndicatorMotion`(`--motion-duration-disclosure` 200ms、`ease-out`,與 TreeView / Accordion 箭頭同一份;群組內容本身沒有高度動畫)。角度看**這顆觸發鈕自己**的 `data-state`(`[[data-state=open]>&]`):原本寫成「任一層祖先打開」,窄螢幕側欄放在 Sheet(本身 `data-state="open"`)裡時,收合的群組箭頭也朝上(2026-10-13 實測並修正,寬螢幕畫面不變)。時長 2026-10-13 起改,原本 150ms(owner = `tokens/motion/motion.spec.md「展開箭頭跟它打開的東西同步」`)
3. `SidebarGroupContent` 被 `Collapsible.Content` 包起來,data-state 可驅動動畫

Consumer 只要加 `collapsible` 與群組識別 `value`(必填):

```tsx
<SidebarGroup collapsible value="projects" defaultOpen={false}>
  <SidebarGroupLabel>Projects</SidebarGroupLabel>
  <SidebarGroupContent><TreeView>...</TreeView></SidebarGroupContent>
</SidebarGroup>
```

**何時用**:
- ✅ 長清單需要讓使用者暫時收起(Projects / Favorites 等次要 section)
- ✅ Group 內容可選(使用者可能根本沒加任何 project)
- ❌ 主導覽 group(永遠要看見)
- ❌ 只有 1-2 個 item 的 group(收合徒增互動成本)

**`value` 必填、非受控的展開狀態住在 `SidebarProvider`**(2026-10-14 審查抓到):AppShell 的 Menu 浮層開著時,同一份 Sidebar 內容畫兩份 —— 版面上的細列(被浮層蓋住)與浮層裡的展開版(下方「放不下時」)。狀態若住在各自的元件裡,在浮層裡展開「專案」、收回、視窗放寬回並排時,版面上那一份仍是收起的,重開浮層也會重置。所以群組以 `value` 為鍵把展開狀態存在 Provider,兩份讀同一個值;受控(`open` + `onOpenChange`)時以 consumer 的值為準。`value` 型別層必填(沒有內建的替代識別;同 Radix `Accordion.Item` 的 `value` 必填),不在 `SidebarProvider` 裡時退回元件自己記。

**為什麼 prop 放在 `SidebarGroup` 而非 `SidebarGroupLabel`**:「是否可收合」是結構層決定,影響 label 尾端 chevron button(是否為 `Collapsible.Trigger`)+ content(是否被 `Collapsible.Content` 包)兩個 primitive(label 本身維持 `role="presentation"` div,不升格為 button)。放在 label 上會讓 content 不知道該不該被 `Collapsible.Content` 包,形成 prop drilling。group 層用 React context 傳遞是標準做法。

---

## Inline actions（SidebarMenuButton suffix slot）

`<SidebarMenuButton inlineActions={[...]}>` 支援 suffix 放置 inline action button,搭配 `actionsReveal="hover"` 做 TreeView 風格的 hover-reveal。

**宣告式 API**,完全對齊 `patterns/element-anatomy/inline-action.spec.md`(Inline Action SSOT):

```tsx
<SidebarMenuButton
  startIcon={Folder}
  actionsReveal="hover"
  inlineActions={[
    { icon: MoreVertical, label: '更多', onClick: handleMore },
    { icon: Plus,           label: '新增', onClick: handleAdd },
  ]}
>
  專案 Alpha
</SidebarMenuButton>
```

**Consumer 不需要**:

- 指定 icon 尺寸(host 從 row size 查 `ICON_SIZE`)
- 寫 hover background span 的絕對定位 JSX(`ItemInlineAction` 內部封裝)
- 處理 Tooltip / `aria-label` / `cursor-pointer`(宣告式 config 自動帶)
- 計算 button 的 `paddingRight`(host 用 `N×icon + (N-1)×gap + loose + gap` 公式自動算)

**規格**(完全繼承 `inline-action.spec.md`):

| 項目 | 值 |
|---|---|
| Icon 尺寸 | `ICON_SIZE[size]`(16/16/20) |
| Hover bg 尺寸 | icon + 2(18/18/22) |
| Hover bg 圓角 | `rounded-md`(全尺寸一致) |
| Icon 顏色 | `fg-muted` → `fg-secondary` on hover/active |
| 多個 action 間距 | `gap-2`(8px) |
| 出現時機 | 預設永遠顯示;`actionsReveal="hover"` → 滑過這一列、或鍵盤焦點在這一列(列或它的動作鈕)時才出現,**瞬間出現、不淡入**(2026-09-26 待辦總帳 L9「全部瞬間」延伸到滑過才出現的按鈕,user:「確定這樣才是一致設計語言就做」;SSOT = `../../tokens/motion/motion.spec.md`「hover 回饋不做過渡」)。容器消費 `ItemSuffix` 的 `hoverReveal`(`../../patterns/element-anatomy/item-anatomy.tsx`),出現規則只住那一份 |
| Icon 模式 | 整個 suffix 隱藏 |
| Host disabled 時 | 不渲染(遵守宿主 disabled 規則) |

**為什麼動作鈕是絕對定位的同層兄弟、而不是放在列裡面**:因為 `SidebarMenuButton` 的列本體就是原生 `<button>`,列內只有文字與圖示;依 `../../patterns/element-anatomy/item-anatomy.spec.md`「整列可點時,誰當那顆控件」表,這是**第一類**(預設),而 `<button>` 的 content model 明文不准有 interactive content 後代,動作鈕只能出到列外面、列再用 `paddingRight` 讓開。FileItem 的列裡有進度條與狀態鈕,走**第二類**(列不互動 + 透明覆蓋控件)。判準與規範逐字出處在該表,本檔不重述。

**指標在動作鈕上時(巢狀 hover,2026-09-25)**:列**保留**自己的 hover(`neutral-hover` 底 + `foreground` 字),動作鈕**再亮**自己那一層(懸停底色 + 圖示升一階),`inlineActions` / `inlineActionsSlot` 與 `SidebarMenuAction` 皆同;當前項照舊釘住選中色,兩顆動作鈕之間的空隙也算在內 —— **空隙點下去也歸列**(2026-09-26,待辦總帳 N53 ①,user:「這些看起來幾乎都是bug」;修法依 R20「讓亮著的地方點得到」):動作鈕的容器本身不接指標,只有裡面可以按的東西接,空隙與插槽裡不能按的裝飾都穿到底下的列鈕(列鈕的 `paddingRight` 本來就讓出這一段),滑過時亮、點下去導覽、游標是手形。依據 `../../../ds-canonical/references/hit-area-canonical.md`「看到亮起來卻點不到」。閘 = `scripts/sidebar-menu-keyboard-invariant.mjs` S9(空隙命中列、點後成為當前頁;對照點在按鈕懸停底色內命中按鈕)。依據是 user 在「滑到可點卡片內的按鈕上時」一題選的「卡片保留、按鈕再亮一層 (Recommended)」(2026-09-25;取代 AI 先前草擬、未進 repo 的全 DS 模型「只亮最裡層」)。套到側欄列是 AI 依此推導,user 沒有逐元件確認。因動作鈕是上段所說的同層兄弟,實作靠「後面兄弟被指著」的選擇器,**`SidebarMenuAction` 必須排在 `SidebarMenuButton` 後面**(內建 suffix 自動如此;`showOnHover` 的選中字色本來就要求這個順序)。`showOnHover` 動作鈕放在當前項旁時靜止是 `foreground`,滑過 / 按下**維持** `foreground` —— 它已在 `fg-muted → fg-secondary → foreground` 階梯頂端,不往回降(`inline-action.spec.md`「Icon 色彩」)。

### 鍵盤:一串 `SidebarMenu` = 一個 Tab 停靠點(2026-09-25)

依據:待辦總帳 B9(`governance/planning/2026-09-25-interaction-and-hover-remediation.md`),user 選乙,逐字:「確定建議符合我們一致的設計語言且不違背世界級的設計就照建議」(附條件;查證成立記在同一列)。取代先前 `ds-canonical/references/keyboard-model-canonical.md` 對 SidebarMenu 的「每項一個 Tab 停靠點,無方向鍵」。本表的判定與執行 = `../../lib/roving-list-keyboard.ts`(2026-09-26 與 TreeView / FileUpload / Command 四份合一,同帳〇節「按鍵規則合併」;判定表 `scripts/test-roving-list-keyboard.mjs`),本元件只提供「誰是列、誰是動作鈕」。

| 焦點在 | 按鍵 | 結果 |
|---|---|---|
| 這一串外面 | `Tab` / `Shift+Tab` 進來 | 落在上次離開時那一項;沒停過 → 當前頁(`aria-current="page"`)那一項;都沒有 → 第一個可用項 |
| 列 | `↑` `↓` / `Home` `End` | 上 / 下一項、第一 / 最後一項;不繞回,跳過 `disabled` 與看不見的列 |
| 列 | `→` | 進這一列自己的第一顆動作鈕(`inlineActions` / `inlineActionsSlot` / `SidebarMenuAction`);沒有動作鈕就不動 |
| 動作鈕 | `→` / `←` | 同列下一顆 / 上一顆;最後一顆按 `→` 停住,第一顆按 `←` 回到列 |
| 動作鈕 | `↑` `↓` / `Home` `End` | 直接換到上 / 下一項(第一 / 最後一項)的列 |
| 列或動作鈕 | `Tab` / `Shift+Tab` | 一下離開這一串;別項與本項的動作鈕都不在 Tab 路上 |

- **只在滑過時出現的動作鈕**(`actionsReveal="hover"`、`showOnHover`):鍵盤焦點在這一列(列或它的動作鈕)時照樣顯示。滑鼠點擊與滑過的行為不變。
- **方向鍵整串歸清單**(AI 推導,user 未逐字確認):列本身若也是選單觸發鈕(帳號列 `DropdownMenuTrigger asChild`),或動作鈕是選單觸發鈕(`inlineActionsSlot`),`↓` 照樣是換項、不開選單;開選單用 `Enter` / `Space`。2026-09-26 起這是「列上有小按鈕的一串」全部宿主的做法(批次細節 X6「統一成側欄做法」,同意清單 user 逐字「確保符合我們一致的設計語言且不違背世界級的設計且都有確保整個ds 是SSOT,避免漂移就照你建議做」)。
- **捲動區不是停靠點**:`SidebarContent` 的 ScrollArea 傳 `viewportTabIndex={-1}`(`../ScrollArea/scroll-area.spec.md:103`)。「混合內容」範例離開整個側欄要按的 Tab 由 19 下變 6 下(2026-09-25 scratch 探針實測,verify 階段以正式建置重量)。
- **沒有「→ 先展開收著的父項」**:SidebarMenu 嚴格 1 層、不 export `SidebarMenuSub`(見「內容形態選擇」),這一步只屬於 `TreeView`。一鍵跳出整個側欄(F6)另談(B9)。
- **ARIA 角色不變**:維持 `ul` / `li` / `button` + `aria-current`,只加 roving tabindex(不宣告 grid / tree,所以不用 `aria-selected`)。微軟側欄的做法是在 `role="navigation"` 的抽屜 https://github.com/microsoft/fluentui/blob/d27922755bebae866d9ffe86b7da44c27ec801ee/packages/react-components/react-nav/library/src/components/NavDrawer/useNavDrawer.ts#L39 裡掛方向鍵群組 https://github.com/microsoft/fluentui/blob/d27922755bebae866d9ffe86b7da44c27ec801ee/packages/react-components/react-nav/library/src/components/NavDrawerBody/useNavDrawerBody.ts#L22-L27 。
- 世界級一手(釘版):Adobe 清單預設用方向鍵進列、按 Tab 整串離開 https://github.com/adobe/react-spectrum/blob/956ecbcb8803f0d0d5d5d973bb169d70c52aea02/packages/react-aria-components/test/GridList.test.js#L1122-L1129 ;W3C「滑過才出現的元素可用方向鍵摸到」https://github.com/w3c/aria-practices/blob/3f094fde1c81b25dfa69162563bf28d093f854d4/content/patterns/grid/grid-pattern.html#L158 ;回來落在上次那一項 https://github.com/w3c/aria-practices/blob/3f094fde1c81b25dfa69162563bf28d093f854d4/content/practices/keyboard-interface/keyboard-interface-practice.html#L270-L277 ;沒停過落在當前頁 https://github.com/w3c/aria-practices/blob/3f094fde1c81b25dfa69162563bf28d093f854d4/content/patterns/treeview/examples/treeview-navigation.html#L344 。
- 誠實附註:GitHub 與 IBM Carbon 的側欄是每項一站(https://primer.style/product/components/nav-list/accessibility/ 、https://carbondesignsystem.com/components/UI-shell-left-panel/accessibility/),乙不是唯一做法,但不違背世界級。閘 = `scripts/sidebar-menu-keyboard-invariant.mjs`(真按鍵;`--selftest` 對照組)。

### 行內動作的命中區 = 懸停底色(2026-09-24 兩次修正;標題 2026-09-27 從「= 可視形狀」改正 —— 行內動作平時只看得到圖示,判準是懸停回饋形狀,`ds-canonical/references/hit-area-canonical.md`「為什麼不寫成『命中區 = 可視形狀』」)

`SidebarGroupAction` / `SidebarMenuAction` **委派 `ItemInlineActionButton`**(`patterns/element-anatomy/item-anatomy.tsx`),所以它們的幾何由那顆 primitive 的常數決定,本檔不重述數值 —— owner 是`patterns/element-anatomy/inline-action.spec.md` 的尺寸表,跨元件規則是`ds-canonical/references/hit-area-canonical.md`。

實測(1280×900,`展示 — 側邊欄動作懸停狀態`):按鈕盒 **16×16**、懸停底色 **18×18**、圖示 **16×16**;懸停底色邊緣**內** 1px 的四面探針全部打到 `menu-action` 自己,邊緣**外** 2px 的四面分別打到`menu-button` / `menu-label`(列鈕與列文字)。**命中區 = 懸停底色,外面沒有任何隱形帶。**

#### 修正一:拿掉只在窄視窗生效的隱形外擴帶

先前這裡有一圈 `after:absolute after:-inset-2 after:md:hidden`,只在 `<md` 視窗生效、每邊 8px。2026-09-24 拿掉,理由是**量出來的**。對照組的作法是把那圈帶**原樣用 CSS 打回去**(`@media (max-width:767.98px)` + `::after{content:"";position:absolute;inset:-8px}`):

實測環境:viewport **400px**(行動斷點,帶若還在就會生效),在頁面裡複製一份 `<li>` 造出相鄰第二列 ——實測兩列間距 **0.00px**(`SidebarMenu` 的 `<ul>` 沒有 `gap`),正是最擠的情況。

| 量的東西 | 現況(帶已拿掉) | 對照組(帶原樣打回去) |
|---|---|---|
| `::after` 的 `content` | `none`(根本沒有這一層) | `""` |
| 命中區 | 等於懸停底色 | **`36.5×32`** |
| 鈕外緣 +4px,**上** | `menu-button`(自己這一列的列鈕) | **`menu-action` 自己的帶** |
| 鈕外緣 +4px,**下** | `menu-button` | **第二列 `menu-action` 的帶** |
| 鈕外緣 +4px,**左** | `menu-label`(列的文字) | **`menu-action` 自己的帶** |
| 鈕外緣 +4px,**右** | `menu-button` | **`menu-action` 自己的帶** |
| 第二列列鈕上緣 +2px 那一點打到誰 | `menu-button`(第二列的,正確) | **第二列 `menu-action` 的帶** |
| 帶相對宿主 `<li>`(高 32,鈕置中) | — | 上、下各**越出 2px** |

那圈帶同時踩了兩條:**越出宿主**、**蓋住別的可點目標** —— 它蓋掉的正是自己那一列的列鈕,以及緊貼在下方那一列的列鈕。同一個形狀在 `../AgentPanel/agent-panel-fab.spec.md`「遮擋與貼邊」段的「不外推」條(:42-43;2026-09-27 拆檔前為 `agent-panel.spec.md:463-464`,「外推會生出隱形帶,搶走底下內容的點擊」)記過。拿掉之後兩個斷點的命中區才一致,不再「同一顆鈕在窄視窗偷偷變大」。

#### 修正二:它們本來就不該是手刻的

查 git 才發現這兩顆是 **shadcn 原樣帶進來的手刻品**(`b7b34721` 把 DS 搬進 npm workspace 時一起進來),之後從未跟著本 DS 的行內動作 canonical 遷移。它們自己寫死 `aspect-square w-5` + `[&>svg]:size-4`,也就是 **16 圖示裝在 20 盒裡** —— 而 `inline-action.spec.md` 的尺寸表只有 16 圖示配 18 底色、20 圖示配 22 底色兩種組合,**20 兩種都不是**。更直接的證據是:**同一個檔案 `sidebar.tsx:826` 的收合箭頭早就在消費 `ItemInlineActionButton`**,`SidebarMenuButton` 也早有 `inlineActions` / `inlineActionsSlot` 走 canonical —— 同一個元件裡兩套幾何並存。

依 M23(DS 既有 canonical 優先於外部)與 M30(wrapper 必須繼承 primitive,不得平行宣告)改為委派。

**API 破壞性變更**:`SidebarMenuAction` / `SidebarGroupAction` 從 children 改成 `icon` prop(`icon={MoreVertical}`),並移除 `asChild`(需要 Radix `asChild` 時照 `:813` 的作法從外面包 `Trigger asChild`)。**刻意不留 children 後備** —— M23(f):「『向後相容』不是把新裁示變成可選的理由」。消費端(`work-management` 的 `AppSidebar.tsx`)在升版 PR 裡一併改。

**user 核准(2026-09-25,逐字)**:「「側欄按鈕從 20 改成 18」這按照我們的ds設計規則改的，可以通過」。核准的對象是「委派 `ItemInlineActionButton`、懸停底色 20 → 18」這一項可見改動。同一顆 primitive 連帶的兩個結果—— 圖示與底色貼齊右緣後約右移 2px(`SidebarGroupAction` 另貼上緣約上移 2px)、按下時多一層較深的底色(`item-anatomy.tsx:743`)—— 屬於「按照 ds 設計規則」的同一個來源,**視為一併核准是 AI 推導**,不是 user 逐字。

**依據不是觸控尺寸建議。** 我們做的是 web component,尺寸以滑鼠指標的精度為前提(user 2026-09-24 原話逐字:「此外我們在做的是web component ，你他媽不要一直拿觸控裝置的設計原則來規範吧？滑鼠的指標是可以比手指頭精細很多的欸」)。觸控門檻類的外部準則是**已知的外部準則,本 DS 不採納為尺寸依據**;本節每一個數字都不是從那裡推出來的。

**為什麼可以小於 24**:`../../tokens/uiSize/uiSize.spec.md:169`「元件高度地板」的 24px 只管**可獨立存在**的互動元件,同一段明文把「元件內部的 Inline Action」交給宿主元件的 spec 定義 —— 現在那份定義是`patterns/element-anatomy/inline-action.spec.md`的尺寸表。

**之後要改這裡的判準**:想放大命中區,就把**可視形狀**一起放大(讓底色真的變大),不要再長一圈看不見的帶。

**Canonical 實作**:`ItemInlineAction` + `ItemSuffix`(`item-anatomy.tsx`)。未來 DropdownMenuItem / TreeItem / Field / Tag 都應逐步遷移到這個共用元件,消除「每個 host 各自複製 18 行 JSX」的技術債——見 `inline-action.spec.md`(Inline Action SSOT)。

**何時用**:
- ✅ Favorites / Bookmarks 類 user data item 的 hover-reveal 「⋯」/「×」
- ✅ Project item 的 quick action(rename / delete)
- ❌ 主導覽 item(應該聚焦導覽意圖,不放行為按鈕)
- ❌ 收合選單的觸發器(用 `<SidebarGroup collapsible>` label trigger,不要塞在 suffix)

---

## 放不下時(AppShell 的 Menu)

放在 AppShell 裡時,Menu 何時並排、何時暫藏、何時變左側浮層,全部照 `../AppShell/app-shell.spec.md`「版面規則」(用各區最小寬現算,**沒有 768 斷點**;2026-10-14 user 規格)。本元件負責各形態的長相:
- **並排**:展開的 Menu 佔版面(有細列時取代細列的位置),右緣 `ResizeHandle` 可拖寬(user 規格 U:4);寬度 = 內容類型的最小 / 初始 / 最大與寬度紀錄(「版面規則」§1、§7)。API:`<Sidebar contentType widthRange={{ min, initial, max }} defaultWidth? onWidthCommit?>`(只在 AppShell 裡有作用;Menu 最大寬產品必給,沒給時開發階段警告、最大 = 初始)。在 AppShell 裡 Menu 是版面列的一員(正常排版,不再 `position: fixed`;`viewportInsetTop` 只對單獨使用的 Sidebar 有作用)。
- **暫藏 / 關閉**:有細列(`collapsible="icon"`)就只剩細列,再窄也不消失、細列上的圖示照常可換頁;沒細列就什麼都不剩。`data-state` / `data-collapsible` 與 `useSidebar().state` 跟**畫面**走(暫藏時開關紀錄 `open` 是 true、畫面是收起);`useSidebar()` 2026-10-14 起不再有 `isMobile` / `openMobile` / `setOpenMobile` / `mobileOpenerRef`(破壞性)—— 要知道整個 Menu 此刻的顯示方式讀 `useAppShell().display.menu`;要知道**呼叫的這一份**畫在浮層裡還是版面上,讀 `useSidebarSurface()`(下方「同一份內容、畫兩份」)。
- **左側浮層**:以 Sheet 承載(z-50),從版面左緣開始、蓋住細列;寬度照紀錄(與並排共用),可拖,右側至少留 `--layout-space-viewport-inset`;點外部或 Esc **收回暫藏**、開關紀錄仍是開(「版面規則」§3、§9;拖過浮層把手之後點外部照樣收回 —— 把手預設不擋 pointerdown,`../../patterns/resize-handle/resize-handle.spec.md` API)。底色沿用 Sheet 的遮蓋型 `--surface-raised`,**不覆寫成 `bg-surface`**(深色模式半透明,底下內容透出;「版面規則」§9「底色」)。無障礙名稱 = 只給讀屏器的 `SheetTitle`「選單」,**不包 `SheetHeader`**(它內建「關閉」×,藏起來仍在 Tab 順序 —— 浮層第一個 Tab 會停在看不見的鈕上;2026-10-15 r1b 複驗 N2 / N4)。AppShell 放在比視窗小、帶 transform 的容器裡時,浮層經 `<AppShell portalContainer>` 傳送進那個容器(「版面規則」API)。
- **同一份內容、畫兩份**:浮層開著時,Sidebar 的 children 同時畫在版面上的細列(被浮層蓋住)與浮層裡(細列在浮層開著時保留,版面不跳;依據與出處見 `../AppShell/app-shell.spec.md`「版面規則」§6 末條)。DS 自己的有狀態部分兩份共用:選取(`activeId`)、可收合群組的展開(`SidebarGroup` `value`,上方「SidebarGroup 收合」)都住在 `SidebarProvider`。**只該出現在其中一份的東西,讀這一份自己的 `useSidebarSurface()`**(`"flow"` 版面上 / `"overlay"` 浮層裡;單獨使用、`collapsible="none"` 一律 `"flow"`)—— 例:`primary-header` 浮層頂排補回的品牌與帳號只在浮層那一份;讀整個 Menu 的 `useAppShell().display.menu` 會讓兩份同時成立,細列那一份也長出標頭、圖示下跳(2026-10-15 r1b 複驗 F4)。細列圖示的 Tooltip 同理只給版面上那一份(見「A11y 預設」)。**consumer 放進 Menu 的其他有狀態元件必須受控**(狀態放在 Menu 外,例:TreeView 的 `expandedIds` + `onExpandedChange`、搜尋框的 `value`),否則兩份各記各的 —— 浮層裡展開的樹節點,回到並排時又是收起的。
- **寬 0 時不可操作**:沒有細列(`collapsible="offcanvas"`)的 Menu 收掉(關閉、暫藏,或浮層開著時版面上那一份)時寬 0,裡面的選單項設 `inert` + `aria-hidden`,不留在 Tab 順序與無障礙樹(WCAG 2.4.3 / 2.4.7;2026-10-14 審查抓到 Tab 落在寬 0 的選單項)。有細列時細列看得到,照常可操作。單獨使用的 offcanvas Sidebar 收起時同一條(寬 0 與 inert 由同一個值導出,見上方「Collapsible」)。浮層開啟狀態**不持久化**。垂直方向沿用 2026-10-14 前的窄版 Sheet:從視窗頂端起,`primary-header` 時**蓋住 global top bar** → consumer 在浮層頂排補品牌 / 帳號(**只在浮層那一份**:讀 `useSidebarSurface()` + `useAppShell().layout`;rule owner = `../AppShell/app-shell.spec.md`「WorkspaceBrand 放置 SSOT」與「帳號入口(Account entry)放置 SSOT」的浮層精修子句,本處不重述)。
- `collapsible="none"` 不能用在 AppShell 的 Menu 位置(「版面規則」§12)。不在 AppShell 裡單獨使用時,Sidebar 一律並排(AI 建議,在 user 以 D:10 核准的 D:30 清單(新增項 N14);user 規格只管 AppShell)。

---

## 持久化與快捷鍵

- **Cookie**：`sidebar_state`, 7 天。SSR 環境下 `SidebarProvider` 必須接 `defaultOpen` 從 server cookie 傳入以避免 hydration flash
- **快捷鍵**：`Cmd+B` / `Ctrl+B` 切換收合（VS Code、Linear、shadcn 一致，不要發明新鍵）

---

## 尺寸規範

元件 scope 的 design token，consumer 可覆寫：

| Token | 預設值 | 用途 |
|-------|--------|------|
| `--sidebar-width` | `15rem` (240px) | 產品沒設時 Menu 的初始寬;`--sidebar-width-min`(240px)= 產品沒設時 Menu 與 Right panel 的最小寬。user 2026-05-21 原話(commit `e58576a6`):「--sidebar-width: 15rem = 240px,然後--sidebar-width-min就先設成240px吧,讓drag resize有一個最小寬度,aside應該也要一起參照」。2026-10-14 起產品設的最小 / 初始 / 最大為準,DS 不再硬夾(`../AppShell/app-shell.spec.md`「版面規則」§1)|
| `--sidebar-width-icon` | `calc(2 * var(--layout-space-loose) + var(--sidebar-menu-icon-size))` | icon 模式寬度(2026-05-21 v3 撤回 `3rem` hardcode,改 geometry formula 保證 icon center x = loose + icon/2 在展開/收合一致;**md = 2×16+16 = 48 / lg = 2×24+20 = 68**,跟 chrome-header-height 解耦)|
| `--sidebar-menu-icon-size` | `1rem` (16px) | sidebar menu icon 大小(per ICON_SIZE.sm/md=16);size=lg 罕見 case override `1.25rem` |

**用 rem**：跟隨 root font-size，支援 accessibility 等比例縮放。**不用 layoutSpace / uiSize 推導**：sidebar width 是容器維度，不是間距或元件內高度，語意不同；耦合會讓寬度跟間距連動。**15rem** = 上表 user 2026-05-21 定的 240;浮層與並排共用同一份寬度紀錄,沒有浮層專用寬(2026-10-14 前的 `--sidebar-width-mobile` 18rem 隨 768 抽屜退場)。`--sidebar-width-icon` 用 geometry formula(2026-05-21 v3)`calc(2*loose + icon-size)` 保證 collapse/expand icon center x 一致。

---

## 常見誤解

- 「SidebarMenuSub 可做第 2 層選單」——本 DS 不 export;深度 > 1 一律 TreeView(見「內容形態選擇」)
- 「Settings 子頁要佔 sidebar 位置」——走 in-page secondary nav / user menu modal(見「Settings 這類有子頁的頁面」)
- 「點 icon 可順便展開 sidebar」——行為不可預測;重新看階層資料的唯一路徑 = 展開 sidebar(見「Icon 模式的行為規則」)

---

## 禁止事項

- ❌ **使用 SidebarMenuSub / 讓 SidebarMenu 超過 1 層**——用 TreeView 或 in-page secondary nav
- ❌ **Hover flyout / popover 顯示 tree 或 sub-items**——2000 年代 cascading menu 反模式，NN/g 多年反對
- ❌ **純分組 header 用 SidebarMenuItem**——icon 模式變死 icon，用 SidebarGroup
- ❌ **點 icon 順便展開 sidebar**（expandOnClick 副作用）——行為不可預測
- ❌ **把 user data 塞 SidebarMenu**——即使只有 3 項，只要使用者可新增就是 tree
- ❌ **在 Sidebar 內放路由邏輯**——路由是 consumer 的事，用 `asChild` 包自家 Link / router
- ❌ **硬寫寬度到子元件**——子元件應完全自適應 Sidebar 寬度
- ❌ **AppShell 的 Menu 用 `collapsible="none"`**——AppShell 的面板皆可開關(`../AppShell/app-shell.spec.md`「版面規則」§12)

---

## 與其他元件的關係

- **TreeView**：放在 SidebarContent 內；icon 模式不會自動隱藏，TreeView／可收合 tree group 的承載 group 必須傳 `className="group-data-[collapsible=icon]:hidden"`；`context="sidebar"` 讓 TreeView 使用 sidebar padding token
- **Command（Cmd+K）**：icon 模式下深層頁面跳轉的逃生艙
- **Tabs**：Settings 等頁面的 in-page secondary nav
- **DropdownMenu**：SidebarHeader 的 workspace switcher、SidebarFooter 的 user menu
- **Avatar**：SidebarFooter 顯示當前使用者

---

## 判斷決策樹

```
Variant：目前僅 sidebar（floating 刻意不做 / inset 規劃中未實作，見「Variant」段）

Collapsible：內容優先低頻導覽 → offcanvas；扁平高頻切換 → icon；超簡單 → none（AppShell 的 Menu 不可）

內容：
├─ designer 1 層固定導覽       → SidebarMenu
├─ user data / 階層 / 可新增   → TreeView
├─ 兩者都有                     → SidebarMenu + TreeView 分區
└─ Settings 等有子頁的頁面      → in-page secondary nav（不塞 sidebar）
```

---

## StateBehavior(Sidebar 層級特有)

Item-level default / hover / selected / disabled **色彩**完全共用 item-anatomy row primitive(`patterns/element-anatomy/item-anatomy.spec.md`),由 `ColorMatrix` 用 4 個 state 的完整 token 對照表承載(state-driven 色彩表)。SidebarMenuButton(獨立 cva)無 `:active` press state——對齊 MenuItem / TreeItem 同族 row-button,`--neutral-active` 僅由 inline-action 子按鈕消費(item-anatomy.tsx group-active/action),menu button 本體不套用。Sidebar 的 `StateBehavior` story 則展示 **container 層級的結構狀態切換**:三種 `collapsible` 模式(offcanvas / icon / none)、Cmd+B / SidebarTrigger toggle、icon mode 下 label 隱藏 + Tooltip 代償、跨 session cookie 還原——這些是 shell 層級特有的行為,不存在於 row item primitive。

---

## A11y 預設

- **Landmark**:`<Sidebar>` 目前渲染 `<div>`(三種 collapsible 分支皆然),**不自帶** `<nav>` 元素或 `role="navigation"`、`aria-label`。consumer 若要 page-level navigation landmark,需自行用 `<nav aria-label="Main">` 包住 `<Sidebar>`(或對導覽區塊 `<SidebarGroup>` 加 `role="navigation"`)。
- **Active item**:`SidebarMenuButton` 帶 `id` + 命中 `activeId` 時自動加 `data-active="true"`,呈現選取底色（`bg-neutral-selected`)。**選中 × 互動疊加(2026-08-11,owner = `item-anatomy.spec.md` 同名格)**:滑鼠 hover 當前項**釘住不變**(先前無規則、靠編譯順序,現為顯式 class);鍵盤焦點停在任何項目都**畫框**(`focus-visible:focus-ring-inset`,2px 內描邊,選單鈕撐滿側欄寬 → 內描邊;當前項 = 框疊在選中底色上),焦點**不改底色**(底色只屬於 hover 與 `data-active`)—— owner = `ds-canonical/references/focus-canonical.md` 規則二,user 2026-09-09 拍板「都要畫框,不上底色」。歷史:2026-09-07「A5畫框」只補了當前項,未選中項當時仍用 hover 同色底(AI 推導,已撤回);原本的深一階底色 token 已退役。**當前項同時設 `aria-current="page"`**(2026-09-24 補)—— 先前只有純樣式的 `data-active`,螢幕閱讀器讀不到「你現在人在這一頁」。三份一手來源一致這樣寫:W3C APG Disclosure Navigation 範例、GitHub repo 導覽、Primer TreeView。它與 `aria-selected` 是兩件事(WAI-ARIA 1.2 `aria-current` 的 Note 明文說可並存):current = 你現在人在這一頁;selected = 這個控件裡被挑中的那一項。側欄導覽要表達的是「你現在在這一頁」,而且 ARIA 角色維持 `ul` / `li` / `button`、沒有宣告 grid / tree 這類 composite 角色,所以用 current 不用 selected —— 2026-09-25 起一串只佔一個 Tab 停靠點、方向鍵在裡面走(見「鍵盤:一串 `SidebarMenu` = 一個 Tab 停靠點」),這條不變。**純 SR 語意,零視覺變化。**`variant="meta"` 永不參與 selection（`data-active` 永遠 false）。
- **快捷鍵不衝突**:`Cmd+B` / `Ctrl+B` 與 shadcn/ui Sidebar 同一組鍵(`SIDEBAR_KEYBOARD_SHORTCUT = "b"`,<https://github.com/shadcn-ui/ui/blob/a9c1da49ec4eab488dc99c69ae20a7ffaa4897d4/apps/v4/registry/new-york-v4/ui/sidebar.tsx#L33>;判斷 `key === "b" && (metaKey || ctrlKey)` 後 `preventDefault` + toggle,<https://github.com/shadcn-ui/ui/blob/a9c1da49ec4eab488dc99c69ae20a7ffaa4897d4/apps/v4/registry/new-york-v4/ui/sidebar.tsx#L95-L109>),VS Code「Toggle Primary Side Bar Visibility」也是 `CtrlCmd+B`(<https://github.com/microsoft/vscode/blob/4d72ba07ae257c404a23781b2ee2275ada05017c/src/vs/workbench/browser/actions/layoutActions.ts#L307-L310>)。DS 內建在 `SidebarProvider` 的 `window` keydown handler,同樣 `preventDefault` + toggle,避免穿透到瀏覽器(`Cmd+B` 在 Safari 是 favorites)。**三道 guard(2026-07-05 D4 修)**:(1) `defaultPrevented`——app 層 editor 已處理同快捷鍵時不 double-fire;(2) IME 組字中不攔(判準全 DS 一支 `../../lib/ime-composition.ts` `isImeComposing`:`isComposing` 或 `keyCode === 229`,2026-09-30 補後者);(3) 可編輯 target——`<input>` / `<textarea>` / `contentEditable` 內按 `Cmd/Ctrl+B` 不 toggle。第 (3) 道是本 DS 自己的理由,不是抄來的:可編輯區裡這組鍵常是粗體等編輯指令,編輯語意優先(上面 shadcn 那段 handler 沒有這一道,任何地方都 toggle)。**目前無 opt-out prop**(無 `disableShortcut`)。
- **Collapsed accessible name(2026-07-05 D4 修)**:icon 模式 label 以 `sr-only` 視覺隱藏(非 display:none),SidebarMenuButton 對 SR 保留 accessible name(WCAG 4.1.2);Tooltip 僅 hover 提示、不供名;badge / inline actions 仍 display:none(補充資訊,供名責任在 label)。
- **Tooltip 只給細列**:`SidebarMenuButton` 的 `tooltip` 只在**版面上那一份收成細列**時會開;展開的 Menu(並排或浮層)看得到字,Tooltip `open={false}`(元素樹不換、只切 `open`,全 DS 同一條:`../../patterns/element-anatomy/truncated-text.spec.md`)。2026-10-14 前寫 `TooltipContent hidden`,藏起來的提示仍會開:Menu 浮層裡第一下 Esc 被它吃掉、要按兩下才收回,`aria-describedby` 還指向跟標籤同字的提示(念兩次;2026-10-15 r1b 複驗 N3)。
- **Menu 浮層 focus trap**:AppShell 判定 Menu 為浮層時以 Sheet 承載,Radix Dialog 自帶 focus trap + Esc dismiss(詳 sheet.spec.md;Esc / 點外部 = 收回暫藏)。開啟時焦點落點照 Sheet 預設(沒有 body 標記 → 落在浮層殼上),**殼不畫焦點框**(`ds-canonical/references/focus-canonical.md`「問題一之二」E 類,與 FileViewer 殼同一種;AI 推導,2026-10-14),選單項各自畫框。**開關鈕 `aria-expanded`** 跟畫面(展開的 Menu 看得到 = true,暫藏 / 關閉 = false)並以 `aria-controls` 指向 Menu(`../AppShell/app-shell.spec.md`「版面規則」§10)。**關閉焦點還原**:浮層 Sheet 無顯式 `<SheetTrigger>`，SidebarTrigger 會直接傳入自身作為 opener；快捷鍵路徑則在叫出浮層前記錄當下聚焦元素。Sheet 關閉時透過 `onCloseAutoFocus` 還原仍連線的 opener；若 opener 已卸載則不強搶焦。還法全 DS 一支 `../../lib/overlay-focus-return.ts` `returnFocusToOpener`(沒有觸發點 + modal;指標關閉不畫鍵盤框、焦點已被別處接走不搶;2026-09-30 自本元件自建那份收成共用)。
- **Provider cardinality**:每個 document／app shell 只掛一個 SidebarProvider。多 Provider 的 local trigger 仍各自隔離，但 document-level Cmd/Ctrl+B shortcut 沒有 active-provider arbitration，不屬支援拓撲。
- **Collapsible group**:`<SidebarGroup collapsible>` 的**尾端 chevron button**(`Collapsible.Trigger asChild` 包 `ItemInlineActionButton`)帶 `aria-expanded` + `aria-controls` 指向 GroupContent id,SR 可朗讀展開狀態(label 本身維持 `role="presentation"`,不承載 aria-expanded)。
- **Sticky header / footer focus order**:Tab 順序按 DOM 順序 — Header → Content → Footer,SidebarTrigger 在 Pattern A/B 都位於 page top-left,Tab 第一站即可達。Content 的捲動區本身不是停靠點;每一串 `SidebarMenu` 各佔一站、串內用方向鍵(見「鍵盤:一串 `SidebarMenu` = 一個 Tab 停靠點」);群組收合鈕、`SidebarGroupAction`、`TreeView` 各自一站。
- **不使用 `SidebarMenuSub`**:避免 nested menu aria-tree 複雜度,階層交給 TreeView(`role="treegrid"`,`aria-level` 住在列上;2026-09-25 由 `role="tree"` 改,待辦總帳 B9,見 `../TreeView/tree-view.spec.md`「ARIA」)。

---

## 邊界案例

- **Disabled item**:SidebarMenuButton `disabled` prop 走 native button disabled(`text-fg-disabled` + 不觸發 onClick + 不可聚焦,`↑` `↓` / `Home` `End` 自動跳過、不會成為這一串的 Tab 停靠點);**不自動設 `aria-disabled`**——cva 另備 `aria-disabled:` 樣式,consumer 自傳 `aria-disabled`(如 asChild 非 button host)時同樣式生效。
- **Loading(nav data-fetch)**:async nav tree fetch 時 consumer 應在對應 group 內渲 `<Skeleton>` line-stack(常見 3-5 條 sidebar nav skeleton 行)而非 Empty + spinner — Sidebar 是持續存在的 chrome 不是 panel，skeleton 能保留導覽列的空間與節奏，不讓內容載入時整個 shell 改形。
- **Empty(no nav items)**:罕見場景(用戶無權限 / 全空 workspace)。若整個 group 無 item,consumer 應 conditional 不渲該 group(不渲空 group label);若整個 sidebar 無 item,可能該 hide sidebar(走 layout context 不渲)。不渲空白 sidebar。
- **Dark mode / density**:Sidebar 為 chrome surface,走 chrome-header token 自動 adapt;density 預設 lock 跟隨 app density chrome token,不獨立 own。
- **Collapsed mode(icon-only)**:label / inline actions suffix 隱藏,只留 icon(hover tooltip 為 opt-in — 未傳 `tooltip` prop 的 collapsed button 無 hover 提示,collapsed 導覽 button 建議都傳 `tooltip`);TreeView 整區隱藏,重新看階層資料的唯一路徑 = 展開 sidebar(完整規則見「Icon 模式的行為規則」段)。

---

## 相關

- `../TreeView/tree-view.spec.md` — 階層樹元件（user data、任意深度）
- `../DropdownMenu/dropdown-menu.spec.md` — Header / Footer 常用的下拉選單
- `../Tabs/tabs.spec.md` — in-page secondary nav（不塞 sidebar 的子頁切換）
- `../Menu/menu-item.spec.md` — SidebarMenuButton 的 item-layout 共用規則
- `../Command/command.spec.md` — Command palette，icon 模式下的跳轉逃生艙
- `../Sheet/sheet.spec.md` — Sheet，暫時性側邊面板的替代（Menu 浮層的承載，詳「A11y 預設」）
- `../AppShell/app-shell.spec.md` — 「版面規則」：Menu 何時並排 / 暫藏 / 浮層、可拉上限、細列、寬度紀錄

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `account-menu.spec.md`
- `agent-panel.spec.md`
- `app-shell.spec.md`
- `density.spec.md`
- `header-canonical.spec.md`
- `scroll-area.spec.md`
- `sheet.spec.md`
- `tree-view.spec.md`
