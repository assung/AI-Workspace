---
component: DropdownMenu
family: 1
variants: {}
sizes: {}
traits:
  - hasInteractiveStates
  - isOverlay
benchmark:
  - Radix DropdownMenu primitive: github.com/radix-ui/primitives/tree/main/packages/react/dropdown-menu
  - Ant Design Dropdown: github.com/ant-design/ant-design/tree/master/components/dropdown
  - Polaris ActionList: github.com/Shopify/polaris/tree/main/polaris-react/src/components/ActionList
---

# DropdownMenu 設計原則

## 定位

DropdownMenu 是按鈕觸發的**動作選單**——使用者從中選擇一個動作並立即執行。
基於 Radix DropdownMenu（shadcn 包裝），item 佈局消費 MenuItem primitive。

**Layout Family**：本元件是 `patterns/element-anatomy/item-anatomy.spec.md` 所擁有的 **Family 1（Menu item layout）** 消費者。結構繼承其「Menu item layout」章節的 scanning-mode 規格。

### 與 SelectMenu 的區別

SelectMenu 是**選值**(選完後值留在 field 裡),DropdownMenu 是**執行**(選完後觸發動作,選單關閉)。判斷標準:「選完之後,畫面上是否需要保留選中狀態?」需要 → SelectMenu;不需要 → DropdownMenu。

心智模型:SelectMenu 的選單是 **field 的延伸**(使用者在「編輯欄位裡的值」,trigger 持續顯示當前值);DropdownMenu 的選單是**動作清單**(執行一次性動作後選單消失,畫面不留痕)。CheckboxItem / RadioItem 雖涉「選擇」,屬即時生效設定非選值(見「Item 類型」)。

---

## 何時用

- **次要動作集合**：卡片右上角 `⋮` 三點選單（複製、刪除、分享、匯出）
- **工具列的溢出動作**：Toolbar 放不下的次要操作集中在 more menu
- **即時生效的設定 toggle**：顯示 / 隱藏欄位、排序方式、主題切換
- **需要分群或子選單的動作清單**：export as PDF / CSV / JSON 這類多層結構

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| 選值（選項留在 field 裡）| `Select` / `SelectMenu` | DropdownMenu 點完即關閉，不保留選中狀態 |
| 主要 CTA（儲存、送出）| `Button` | 主要動作應該直接可見，不該隱藏在選單裡 |
| 切換平行視圖 | `Tabs` / `SegmentedControl` | view 切換應該持續可見，不是 one-shot |
| 少於 3 個動作 | 直接放 Button | 2 個動作用 menu 是多餘的藏匿 |
| 複雜表單 / 多步驟流程 | `Dialog` / `Sheet` | menu item 是單次點擊動作，不承載流程 |

---

## 結構

```
DropdownMenu                    ← Radix Root，管理開關狀態
  DropdownMenuTrigger           ← 觸發按鈕（通常是 Button）
  DropdownMenuContent           ← 浮層容器，提供 size context
    DropdownMenuGroup           ← 邏輯群組容器（自動分隔相鄰 Group，見下）
      DropdownMenuItem          ← 基本動作項目
      DropdownMenuCheckboxItem  ← 可勾選的切換項目（如顯示/隱藏欄位）
    DropdownMenuRadioGroup      ← 單選群組容器
      DropdownMenuRadioItem     ← 單選項目（如排序方式）
    DropdownMenuSub             ← 子選單容器
      DropdownMenuSubTrigger    ← 子選單觸發項目（自動附加 ChevronRight）
      DropdownMenuSubContent    ← 子選單浮層
    DropdownMenuLabel           ← 群組標題（不可互動）
    DropdownMenuSeparator       ← 明確分隔線（consumer 手動放置）
    DropdownMenuShortcut        ← 鍵盤快捷鍵提示 child(composition escape-hatch;canonical 用 item `shortcut` prop)
```

**快捷鍵提示 API（兩條,擇一不混用）**：
- **Canonical:`<DropdownMenuItem shortcut="⌘C">`** prop —— 渲染進 MenuItem `endContent` 正規後綴 slot(跟 badge / endIcon 同槽,gap / 對齊一致)。**標準場景一律用 prop。**
- **Escape-hatch:`<DropdownMenuShortcut>` child** —— 保留以相容 shadcn DropdownMenuShortcut idiom(source:https://ui.shadcn.com/docs/components/dropdown-menu 的 `DropdownMenuShortcut` = `ml-auto` span,npm published API)。⚠️ 本 DS 的 MenuItem 把 children 塞進 ItemContent 的 label `<span>`(非 flex row),故 child 上的 `ml-auto` **不會靠右**——⌘N 只會 inline 附加在 label 文字尾端。要真正靠右對齊列尾的後綴,一律用上方 canonical `shortcut` prop。
- 兩者**字體樣式統一**(`text-caption` + `tracking-shortcut` + `fg-muted`,與 CommandShortcut 一致),但**位置不等價**(prop 靠右對齊列尾;child inline 附加在 label 尾);**同一 item 只用一種**(見「禁止事項」)。
- 為何不砍 child 只留 prop:`DropdownMenuShortcut` 是 npm published API(對齊 shadcn,fork repo 可能用),硬砍 = breaking;故保留為 escape-hatch,prop 為 canonical preferred。

### DropdownMenuGroup 的自動分隔

`DropdownMenuGroup` 對齊 `MenuGroup` 的 group separation 設計語言——相鄰的 Group 自動透過 `border-divider` 分隔，**consumer 不需要自己加 `DropdownMenuSeparator`**。

**設計語言**（跨 Menu-like 元件統一，SSOT 見 `../../patterns/element-anatomy/item-anatomy.spec.md`「Group auto-separation」）：
- 每個 group 上下各 **8px padding**
- 相鄰 group 之間用 **border-divider** 分隔
- 兩個 group 之間視覺 gap = 8（上一 bottom）+ 8（下一 top）= **16px + border**

**MenuGroup vs DropdownMenuGroup CSS 實作對照**（視覺結果 100% 等價，差別只是 padding 住在哪層）：

| | MenuGroup | DropdownMenuGroup |
|---|---|---|
| CSS | `py-2 [&+&]:border-t [&+&]:border-divider` | `[&+&]:mt-2 [&+&]:pt-2 [&+&]:border-t [&+&]:border-divider` |
| 邊界 padding 來源 | 每個 Group 自己的 py-2（Command.List 無 py） | Content 的 py-2（Group 不套 py-2 避免 double） |
| Group 間 gap | 8 + 8 = 16 + border | 0 + 8 + 8 = 16 + border |

**為什麼不直接套 `py-2`**：`DropdownMenuContent` 已有 `py-2` 提供 Content 邊界 padding（純視覺呼吸空間；Radix roving focus 依 collection refs + `element.focus()`，不讀 CSS padding，移除 py-2 不影響鍵盤導覽 / focus offset）。若 Group 再套 `py-2` 會 double padding。改用 `mt-2 pt-2` 只加在第二個 Group 起，視覺等價但不 double。

兩種分隔機制的選擇：
- **用 `DropdownMenuGroup` 包裝同類 items** → 自動分隔（零手動，跟 MenuGroup 理念一致）
- **用 `DropdownMenuSeparator` 明確插入** → 明確控制分隔位置（如群組內部的子分組、破壞性動作前的強調分隔）

---

## Item 類型

| 類型 | 用途 | 選中行為 |
|---|---|---|
| **Item** | 執行一次性動作（複製、刪除、開啟連結） | 執行後關閉選單 |
| **CheckboxItem** | 切換開關狀態（顯示/隱藏欄位） | 勾選/取消，選單保持開啟 |
| **RadioItem** | 從互斥選項中選一（排序方式） | 選中後選單保持開啟 |
| **SubTrigger** | 展開下一層選單 | 不執行動作，展開子選單 |
| **Label** | 群組標題，提供語義分類 | 不可互動 |
| **Separator** | 視覺分隔，劃分邏輯群組 | 不可互動 |

CheckboxItem 和 RadioItem 雖然涉及「選擇」，但它們控制的是**即時生效的設定**（toggle），不是「選一個值填回 field」。

---

## Item 佈局

遵循 item-layout 設計原則：

```
[prefix]  [label]  [suffix]
```

- prefix：由 `DropdownMenuItem` 的 `startIcon` prop 傳入，經 MenuItem 內部的 prefix 對齊容器（消費 item-anatomy 的 `itemPrefixAlignVariants`，`h-[1lh]` 對齊第一行 label）渲染。icon 跟 label 同色（foreground）
- label：文字內容，`flex-1`
- suffix：canonical 走 item prop（`shortcut` / `badge` / `endIcon` → MenuItem `endContent` 正規 slot，真正靠右對齊列尾）；`DropdownMenuShortcut` child 僅相容用 escape-hatch（inline 附加在 label 尾、**不靠右**,見「快捷鍵提示 API」段）。指示型 icon 用 `fg-muted`

padding 公式：`py = (field-height - 1lh) / 2`，單行時總高度等於同 size 的 Button / Input。

---

## Suffix 模式

| Pattern | 內部 gap | 內容 | 用途 |
|---|---|---|---|
| **獨立後綴** | `gap-2` (8px) | `[badge?] [endIcon?]` | 狀態指示（未讀數）、導覽提示（ExternalLink） |
| **子選單指示** | `gap-1` (4px) | `[value?] [badge?] [ChevronRight]` | 展開下一層，value 顯示目前狀態（如 "深色"） |

SubTrigger 的 ChevronRight 由元件自動渲染，不需手動加。子選單指示中的 value 和 badge 是可選的——讓使用者不用展開就能看到下一層的目前狀態。

---

## 浮層規格

所有 elevation-200 浮層共用同一套視覺規格：

| 屬性 | Token |
|---|---|
| 背景 | `bg-surface-raised` |
| 陰影 | `--elevation-200` |
| 圓角 | `rounded-lg` (8px) |
| 邊框 | `border border-border` |
| 間距 | `sideOffset={8}`（見 `../Popover/popover.spec.md` SSOT） |
| Align | **跟隨 trigger 位置:左 → `start` / 中 → `center` / 右 → `end`**,見 `../Popover/popover.spec.md`「Align 對齊 canonical(跨浮層 SSOT)」|
| 最小寬度 | `max(180px, 觸發元件寬度)`——窄 trigger 時吃 180px 地板；可用 `minWidth` prop override |

SubContent 使用相同規格，包括 sideOffset。

---

## Size

透過 `DropdownMenuContent` 的 `size` prop 設定，經 SizeContext 向下傳遞，所有子項目自動套用。

| Size | Label | Icon | Checkbox 控件 |
|---|---|---|---|
| sm | `text-body leading-compact` (14px, 1.3) | 16px | 16px |
| md | `text-body leading-compact` (14px, 1.3) | 16px | 16px |
| lg | `text-body-lg leading-compact` (16px, 1.3) | 20px | 20px |

RadioItem 不渲染 radio 控件——選中以 `bg-neutral-selected` 背景高亮(見 `../Menu/menu-item.spec.md`「選中指示器」),故控件尺寸欄僅適用 CheckboxItem。

DropdownMenu 是掃描模式——使用者快速瀏覽選項，所有尺寸使用 `leading-compact`。

---

## 鍵盤操作

由 Radix DropdownMenu 提供;**`Tab` / `Shift+Tab` 與子選單裡的 `Escape` 兩處由本元件改寫**(2026-09-25,來歷見下一節):

| 按鍵 | 行為 |
|---|---|
| `↑` `↓` | 移動焦點 |
| `Home` / `End` | 跳到第一／最後一個 item（`PageUp` / `PageDown` 同） |
| 首字 typeahead | 打字元自動跳到 **label 符合**的 item——children 為字串時元件自動 forward `textValue`,description / badge / shortcut 不進比對;複雜 children(非純字串)由 consumer 顯式給 `textValue` |
| `Enter` / `Space` | 執行目前焦點的動作 |
| `Tab` / `Shift+Tab` | **收起全部層(含子選單),焦點從開啟選單的那顆鈕往下 / 往上走一站** —— 效果等於在觸發鈕上按 `Tab` / `Shift+Tab`。選單內容掛在頁面最末端,所以下一站一律從觸發鈕算,不從選單項算。觸發鈕在對話框或面板裡時,照那個框的規則在框內繞圈;頁面上已經沒有下一站時,焦點留在觸發鈕 |
| `Escape` | **只關焦點所在的那一層**:在主選單 → 關選單、焦點回觸發鈕;在子選單 → 只關這一層、焦點回上一層打開它的那一項(與 `←` 同效果)。**每按一次少一層** |
| `→` | 展開子選單 |
| `←` | 收合子選單，焦點回到 SubTrigger |

**關閉之後焦點去哪**(全 DS 規則住在 `ds-canonical/references/keyboard-model-canonical.md`「彈出框開著時的 Tab 與 Esc」,本表只是本元件的落地):
`Escape` 或選了項目 → 回觸發鈕;點外面 → 留在點的地方(非 modal 預設,Radix `hasInteractedOutsideRef`);`Tab` → 已經走到下一站,不再拉回觸發鈕,也不呼叫 consumer 的 `onCloseAutoFocus`。

### `Tab` 與子選單 `Escape` 的來歷(2026-09-25)

**user 原話(逐字,附條件同意)**:選單 Tab:「你確定這個符合我們一致的設計語言且不違背世界級的設計就這樣做」;子選單 Esc:「你確定這符合我們一致的設計語言且不違背世界級的設計就這樣做」;追問:「看最後是怎樣定義，選單類應該要一致吧？這樣才符合世界級的設計？」。條件(世界級 + DS 一致)的查證是 **AI 研究**(待辦總帳 `governance/planning/2026-09-25-interaction-and-hover-remediation.md` B10 / B11);Tab 那一題 user 可在預覽否決。

- **子選單 `Escape` 只關一層**:W3C「Close the menu that contains focus and return focus to the element or context, e.g., menu button or parent `menuitem`, from which the menu was opened」(https://github.com/w3c/aria-practices/blob/3f094fde1c81b25dfa69162563bf28d093f854d4/content/patterns/menubar/menu-and-menubar-pattern.html#L153 );同派:Adobe React Aria(https://github.com/adobe/react-spectrum/blob/956ecbcb8803f0d0d5d5d973bb169d70c52aea02/packages/react-aria/src/menu/useSubmenuTrigger.ts#L161-L171 )、Fluent(https://github.com/microsoft/fluentui/blob/d27922755bebae866d9ffe86b7da44c27ec801ee/packages/react-components/react-menu/library/src/components/Menu/Menu.cy.tsx#L952-L964 )、GitHub Primer 測試「closes top menu on escape or left arrow key press」(https://github.com/primer/react/blob/f2c075a5d4d0b51a279c39effa18226ad909929d/packages/react/src/ActionMenu/ActionMenu.test.tsx#L626-L649 )、VS Code(https://github.com/microsoft/vscode/blob/2ec783d855253a817b5787fb48bc6c3d8d31c0c5/src/vs/base/browser/ui/menu/menu.ts#L953-L957 )、Windows 桌面選單(https://github.com/microsoft/microsoft-ui-xaml/blob/258a2e9b0852b69c98162e6daf9906ec8fe5161a/dxaml/xcp/dxaml/lib/MenuFlyoutPresenter_Partial.cpp#L232-L235 )、Chrome(https://github.com/chromium/chromium/blob/c53fe9e04b2856967d1f2f716b99b0911251e521/ui/views/controls/menu/menu_controller.cc#L2155-L2167 )、Firefox「Pressing Escape hides one level of menus only.」(https://github.com/mozilla-firefox/firefox/blob/0a5c5bffebd796cedba281419efd2f8f3cc7c85d/layout/xul/nsXULPopupManager.cpp#L2642-L2648 )。有一手資料的 9 家裡唯一例外是本元件的底層 Radix(子選單 Esc 呼叫 `rootContext.onClose()` 關整棵,https://github.com/radix-ui/primitives/blob/f7ecd5ab16f5e1e820eb5786a1419a98a2d594ae/packages/react/menu/src/menu.tsx#L1262-L1266 ),本元件改寫它。DS 內部:對話框、側滑面板、AI 面板早已寫明 Esc 只關最上層 / 最內層(`../Dialog/dialog.spec.md`、`../Sheet/sheet.spec.md`、`../AgentPanel/agent-panel.spec.md`),子選單原本是全 DS 唯一例外。
- **`Tab` 收起並往下走**:W3C「When focus is on a `menuitem` in a `menu` or `menubar`, move focus out of the `menu` or `menubar`, and close all menus and submenus.」(https://github.com/w3c/aria-practices/blob/3f094fde1c81b25dfa69162563bf28d093f854d4/content/patterns/menubar/menu-and-menubar-pattern.html#L82 );Fluent 測試「should be able to tab to next element after the root trigger」(https://github.com/microsoft/fluentui/blob/d27922755bebae866d9ffe86b7da44c27ec801ee/packages/react-components/react-menu/library/src/components/Menu/Menu.cy.tsx#L579 );Primer「When Tab or Shift+Tab is pressed, the menu should close and the focus should naturally move to the next item」(https://github.com/primer/react/blob/f2c075a5d4d0b51a279c39effa18226ad909929d/packages/react/src/hooks/useMenuKeyboardNavigation.ts#L29-L30 )。**世界級在這題不一致**:Radix(「menus should not be navigated using tab key so we prevent it」,https://github.com/radix-ui/primitives/blob/f7ecd5ab16f5e1e820eb5786a1419a98a2d594ae/packages/react/menu/src/menu.tsx#L570-L572 )、Adobe React Aria(測試「contains focus within the menu」,https://github.com/adobe/react-spectrum/blob/956ecbcb8803f0d0d5d5d973bb169d70c52aea02/packages/react-aria-components/test/Menu.test.tsx#L1842-L1877 )、VS Code(「Stop tab navigation of menus」,https://github.com/microsoft/vscode/blob/2ec783d855253a817b5787fb48bc6c3d8d31c0c5/src/vs/base/browser/ui/menu/menu.ts#L132-L139 )是「按了不動」那一派。本 DS 採 W3C 這一派,理由是 DS 自己的鍵盤分工「Tab 換區、方向鍵在區裡走、Esc 退一步」(`ds-canonical/references/keyboard-model-canonical.md`)——選單是一個區,Tab 就該離開它(AI 推導,條件查證見待辦總帳 B11)。
- **實作**:`dropdown-menu-keyboard.ts` 的 `handleMenuTab`(`Content` / `SubContent` 的 `onKeyDown`)與子選單的 `closeLevel`(`SubContent` 的 `onEscapeKeyDown`);2026-09-26 從 `dropdown-menu.tsx` 拆出(該檔 879 行超過 800 行上限),`dropdown-menu.tsx` 只留視覺層。「從觸發點算下一站」與 SelectMenu 共用一份 `../../lib/focus-after-trigger.ts`(2026-09-26 兩份合一,待辦總帳〇節「按鍵規則合併」)。觸發點是透明錨點時(AgentFab 右鍵選單),以「宣告 `aria-controls` 指向本選單的可聚焦元素」為開啟者。觸發點本身不在 Tab 路上時(例:樹 / 側欄列上 `tabIndex=-1` 的選單鈕),以它在文件裡的位置為起點往下 / 往上走 —— 從列上選單鈕打開的選單按 `Tab`,會直接離開那一整串。

---

## 破壞性動作

刪除等不可逆動作的 **prefix icon 和 label 都使用 `text-error`**——prefix icon 是 label 的視覺延伸，與 label 同色。Suffix shortcut 維持 `fg-muted`。

---

## 禁止事項

- ❌ 不要用 DropdownMenu 做選值——「選一個值填回 field」用 SelectMenu
- ❌ 不要在 item 內放獨立互動元素（如 Button、Switch）——item 本身就是互動單位
- ❌ disabled item 不可有 hover 效果
- ❌ Label 不可被點擊或取得焦點
- ❌ 不要手動在 SubTrigger 內加 ChevronRight——元件自動渲染
- ❌ 不要在同一 item 混用 `shortcut` prop 與 `<DropdownMenuShortcut>` child(兩條後綴 API 擇一;canonical 用 prop)——同一個 item 只用一種後綴

---

## StateBehavior(DropdownMenu 層級特有)

Item-level default / hover / focused / selected / disabled **色彩**由 MenuItem primitive SSOT 擁有(`patterns/element-anatomy/item-anatomy.spec.md`「選擇 / 狀態視覺規則」),在本元件 `ColorMatrix` story 承載並直接引用 MenuItem token。**selected × highlighted 疊加**:owner = `item-anatomy.spec.md`「選中 × 互動疊加」格(2026-08-11 全家族統一)——**滑鼠 hover 釘住 `bg-neutral-selected` 不變;鍵盤模態的反白(highlighted)畫框 `focus-ring-inset`,框疊在選中底色上**(2026-09-07 user 拍板「A5畫框」;原深一階底色已退役;2026-09-09 起框由 `radixCursorClass` 統一畫在所有反白列上、不分選中與否,`not-hover:` 分流一併移除);**僅 RadioItem checked 走此 selected-bg 規則**(checked 底色套外層 Radix RadioItem)。CheckboxItem checked **不套 row bg**——checked 由內層 checkbox 控件表達,反白時同一般列(指標模態底色、鍵盤模態框)。DropdownMenu 的 `StateBehavior` story 展示**浮層層級特有的動態行為**:open / close 動畫(Radix `data-state` 驅動)、Submenu 展開 / 收起、CheckboxItem toggle(多選不 close)——這些是 item primitive 沒有的維度。

---

## 邊界案例

- **Disabled trigger**:由 trigger Button 的 `disabled` prop 控,該 Button 自動繼承 disabled token(M24 state precedence);click trigger 不開 menu。
- **Disabled item**:`<DropdownMenuItem disabled>`(Radix 內建支援),視覺繼承 MenuItem SSOT(`text-fg-disabled` + `aria-disabled=true` + 鍵盤導覽 skip + 不觸發 onSelect)。
- **Loading(async submenu / async items)**:DropdownMenu primitive 不獨立 own loading prop。async submenu 場景應由 consumer 在 `<DropdownMenuSub>` 內條件性渲 `<DropdownMenuItem disabled>` + spinner label(如「載入中...」);或 fetch options 前先 disable 整個 menu trigger。完整 loading body 替換 pattern 屬 SelectMenu scope,不在 DropdownMenu scope。
- **Empty(no items / async fetch result empty)**:consumer 應條件性渲 `<DropdownMenuItem disabled>` 顯示「無可用動作」字樣;不渲空 menu。
- **Dark mode / density**:走 MenuItem + Popover SSOT 自動 adapt;density 繼承 page(不鎖;DropdownMenu item 高度 = field-height-{size} 隨 page density 變,鎖 md 會釘死 md-scale 對不上 lg 觸發點),SSOT 見 `tokens/density/density.spec.md`。
- **大量 item(> 100)**:建議上游分頁 / 搜尋收斂或考慮 windowing(對齊 Ant Select / MUI Autocomplete 慣例);本元件無虛擬化——action menu 本不該長到這個量級,超過先重想資訊架構(選值場景改用 SelectMenu 系 + searchable)。

---

## 相關

- `../Menu/menu-item.spec.md` — 共用的 MenuItem primitive（prefix 對齊、尺寸、狀態）
- `../SelectMenu/select-menu.spec.md` — 選值（選完留在 field 裡）的對應元件
- `../Button/button.spec.md` — 通常作為 DropdownMenuTrigger
- `../Dialog/dialog.spec.md` — 複雜流程時的改用選擇

## A11y 預設

**ARIA / Pattern**:繼承 Radix `dropdown-menu` primitive a11y 預設(role / aria-* / 鍵盤導覽)。詳 [Radix Accessibility docs](https://www.radix-ui.com/primitives/docs/components/dropdown-menu#accessibility)。

**Keyboard 行為**:

- Tab — 選單關著:把焦點移到觸發鈕(觸發鈕本身是一站)
- Enter / Space / ↓ — 開啟
- ↑/↓ — 導覽 items（Home/End 跳首尾項，PageUp/PageDown 同）
- 首字 typeahead — 打字元自動跳到 label 符合的 item(比對 `textValue`,見「鍵盤操作」表)
- Enter / Space — 選擇目前焦點的選項
- Tab / Shift+Tab — 選單開著:收起全部層,焦點從觸發鈕往下 / 往上走一站(2026-09-25 起,見「鍵盤操作」)
- Esc — 只關焦點所在的那一層(子選單 → 回上一層那一項;主選單 → 回觸發鈕)

**Focus**:預設非 modal —— 焦點不鎖在選單裡(`Tab` 會離開,見上)。開啟時焦點進選單;關閉時 `Esc` / 選了項目 → 回觸發鈕,點外面 → 留在點的地方,`Tab` → 下一站(本元件 `onCloseAutoFocus` 在 Tab 離開時擋掉還觸發鈕)。反白(Radix `data-highlighted`)是**唯一的游標**,依**反白來歷**分流(owner = `ds-canonical/references/focus-canonical.md` 規則一「兩類元件」+ 規則二,user 2026-09-09 拍板「都要畫框,不上底色」):**滑鼠移過搬走反白** = hover → `bg-neutral-hover`、無框;**鍵盤搬走反白** = 游標 → 畫框 `focus-ring-inset`(內描邊,列撐滿選單寬)、不上底色,而且滑鼠停留列的 hover 底色一起消失(四種項目上都沒有 `hover:` 樣式;滑鼠停著不算搶,2026-09-09 下午 user 三問、Radix Menu 原始碼證實 `onPointerMove → item.focus()` 就是搶 —— https://github.com/radix-ui/primitives/blob/main/packages/react/menu/src/menu.tsx)。來歷由 `hooks/use-input-modality.ts` 的 `useCursorMover` + 各項目 `onPointerMoveCapture → markPointerGrab` 判(本元件刻意用 `data-highlighted` + 模態而非瀏覽器 `:focus-visible`,因 Radix 對 hover 做程式化 focus、各瀏覽器 `:focus-visible` 行為不一 — 見 dropdown-menu.tsx docblock「Hover / highlight canonical」)。2026-09-09 之前鍵盤導覽到的未選中項只有底色不畫框 —— AI 推導自 Radix 慣例,已撤回。**Trigger focus 指示**:Trigger 走全域 `:focus-visible` 外描邊(`styles/base.css`,幾何 SSOT = focus-canonical「框怎麼畫」);asChild 場景由子元件(通常 Button)同樣走全域外描邊。

**ARIA composite scroll wrapper**:`DropdownMenuContent` 的 viewport-aware body 仍消費 `ScrollArea`,但 viewport 傳 `viewportTabIndex={null}` 完全省略 generic wrapper 的 `tabindex`。`role="menu"` 內的 focus owner 是 Radix roving-focus `menuitem*` family；額外 `div[tabindex]` 會破壞 required-children 結構。群組 Label 是正常可讀文字,使用 `fg-secondary`(非低對比的 `fg-muted`)。

**Modal trigger focus**:modal menu 開啟時,Root 會把 Trigger 暫時設為 `tabIndex=-1`,與 Radix 對 app subtree 的 `aria-hidden` 同步；關閉後恢復 consumer 原 tab order。此規則由 DropdownMenu SSOT 統一負責,consumer 不各自追蹤 open state。`modal={false}` 不套用此調整。

**驗證**:Storybook a11y addon panel 應 0 critical violation;鍵盤完整可操作(無需滑鼠)。WCAG AA contrast ≥ 4.5:1(text)/ 3:1(UI)。

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `account-menu.spec.md`
- `action-bar.spec.md`
- `command.spec.md`
- `file-viewer.spec.md`
- `menu-item.spec.md`
- `popover.spec.md`
- `select-menu.spec.md`
- `sheet.spec.md`
- `sidebar.spec.md`
- `tree-view.spec.md`
