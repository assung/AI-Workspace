---
component: Tooltip
family: composite
variants: {}
sizes: {}
traits:
  - isOverlay
benchmark:
  - Radix Tooltip primitive: github.com/radix-ui/primitives/tree/main/packages/react/tooltip
  - Ant Design Tooltip: github.com/ant-design/ant-design/tree/master/components/tooltip
  - MUI Tooltip: github.com/mui/material-ui/tree/master/packages/mui-material/src/Tooltip
  - Polaris Tooltip: github.com/Shopify/polaris/tree/main/polaris-react/src/components/Tooltip
---

# Tooltip 設計原則

## 定位

Tooltip 是 hover 或 focus 時出現的短文字提示，用於補充畫面上未能清楚傳達的資訊。
基於 Radix Tooltip（shadcn 包裝）+ 橋接 DS token。

**Layout Family**：非上述 family — composite / multi-section（多區塊組合，自 own layout）。

## 何時用

Tooltip 的判斷標準是：**畫面上的資訊是否已經足夠讓使用者理解？**

- **畫面不夠清楚 → 用 tooltip 補充。** 例如：icon-only 按鈕沒有文字 label，使用者需要 tooltip 才能確認這個 icon 代表什麼操作
- **畫面已經清楚 → 不需要 tooltip。** 例如：按鈕已有完整的文字 label（「儲存」「刪除」），tooltip 重複同樣的文字沒有價值
- **截斷文字 → 用 tooltip 顯示完整內容。** 但只有當文字實際被截斷時才顯示——tooltip 是補救機制，不是裝飾

## 出現時機

全產品統一一組時間參數，不因 tooltip 類型或位置而異——不一致的延遲會讓使用者無法建立穩定的操作預期。

**Warm-up pattern（暖機模式）：**

1. 使用者首次 hover 某個觸發器 → 等待初始延遲，確認是刻意停留而非滑鼠路過，避免游標掃過畫面時提示持續閃爍
2. Tooltip 出現後，使用者移到下一個觸發器 → 在掃描窗口期內，tooltip 即時切換，不再等待（toolbar 逐一掃描場景）
3. 使用者離開所有觸發器超過掃描窗口期 → 系統冷卻，下次 hover 重新等待初始延遲

這是一個行為的兩個階段,不是兩種不同的延遲。所有 tooltip(包括 Button icon-only 自動產生的)共享同一組參數——初始延遲由 DS shared constant `MOTION_DELAY_PLAIN_MS`(Tooltip Root wrapper 預設 `delayDuration`;Radix Root prop 優先於 Provider 同名設定)統一,warm-up 掃描窗口(`skipDelayDuration`)由全域 `TooltipProvider` 控制。

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| 內容需要互動（按鈕 / 連結 / 輸入框）| `HoverCard` | Tooltip 不可點擊，HoverCard 才支援互動元素 |
| 需要長篇說明（多段文字 / 圖片）| `HoverCard` / 側邊 help panel | Tooltip 是一句話補充 |
| 欄位驗證錯誤 | inline error message | Tooltip 需要 hover 才能看到，錯誤必須 persistent |
| 必要資訊的唯一載體 | 直接顯示在畫面上 | Tooltip 觸控裝置無法觸發，關鍵資訊不能只靠 hover |
| 按鈕已有完整文字 label | 不要加 tooltip | 重複同樣的文字沒有價值 |

## 與 Button icon-only 的關係

Button 的 `iconOnly` 模式已內建自動 tooltip（以 `aria-label` 驅動），開發者不需要額外包 `<Tooltip>`。

**例外——`iconOnly` + `asChild`**：當 `iconOnly` 同時搭配 `asChild` 時，內建 tooltip wrapper **不啟動**（Radix Slot 只接受單一 child，Button 主動補 tooltip 會破壞單 child 規則）。此時 consumer 必須**自行傳入 child 的 `aria-label`** 給螢幕閱讀器，並視需要自行包 `<Tooltip>`（見 `../Button/button.spec.md` 與 `button.tsx` 的 asChild 警告）。

只有在非 Button 元素需要 tooltip 時，才手動使用 Tooltip 元件。

## 內容完整性

Tooltip 是資訊的終點——內容只能是短篇、不可互動且能直接完整呈現的文字，不得再觸發 tooltip，也不應依賴截斷或省略。Tag、多標籤、卡片或其他 rich content 改用 HoverCard；需要操作的內容使用 Popover。

## 子元素色彩

Tooltip 底色是深色，子元素永遠套用 dark theme token（透過 `data-theme="dark"` wrapper）。元件放進 tooltip 自動適配深色背景，不需要特殊樣式。

## Align 對齊

**Tooltip 走「輕量浮層」例外**(見 `../Popover/popover.spec.md`「SSOT 適用範圍」)—— hover 觸發、純文字展示、寬度極窄(max 280px),底層定位採預設 `center` 貼合指標即可。不強制對齊 structured overlay 的 trigger-position canonical。

## Edge collision(避免貼 viewport 邊)

**`collisionPadding` default = 8**(消費 `OVERLAY_COLLISION_PADDING` overlay 家族 canonical,與 Popover 一致;HoverCard 是 documented exception 特意用 12 補 Radix rounding,見 `hover-card.tsx` 註解),Radix `avoidCollisions` 預設 true 會自動翻邊,但 padding 0 會讓 tooltip **貼齊 viewport 邊緣**(視覺上擠)。default 8 讓 tooltip 跟 viewport 邊保留最少 8px 呼吸距離。consumer 需自訂傳 prop 即可覆寫。

本 DS 選 8px 是為了與 overlay 家族共用 collision 常數，避免單一元件另立近似值。

## 最大寬度（元件級常數）

Tooltip 最大寬度 **280px**（見 `.tsx` 的 `max-w-[280px]`）——超過換行。避免單條 tooltip 占據過大空間遮蔽內容，同時保證文字可完整呈現（見「內容完整性」節，tooltip 是資訊終點，不截斷）。

**單一元件的 canonical 寬度屬於該元件自己的 design spec，不抽為跨元件 token**。Token 系統只管共享值（如 `--field-height-*`、`--layout-space-*`）；單一元件獨有的結構常數留在 component code + 本 spec。

## 邊界狀態

- **觸控裝置**:無 hover,tooltip 無法觸發——必要資訊不可只靠 tooltip 承載(見「何時不用」「禁止事項」)
- **長文字**:超過 max-width 280px 自動換行、完整呈現不截斷(見「最大寬度」「內容完整性」)
- **貼近 viewport 邊**:Radix 自動翻邊 + `collisionPadding` 8px 呼吸距離(見「Edge collision」)
- **空內容**:`TooltipContent` 的 `children` 為 `null` / `undefined` / `false` / 空字串時**不掛浮層**——不渲染帶 padding 的空 `role="tooltip"` 殼,trigger 原樣保留。Tooltip 是資訊補救機制(見「何時用」),沒有補充內容就不該出現。實作於 `tooltip.tsx` 的 `TooltipContent` 以空值 guard 提早 return null 落地
- **Loading**:Tooltip API 無 loading prop 或內建 async state；content 的資料生命週期由 consumer own。
- **錨點失去版面**(2026-09-16 user:「關閉那顆按鈕的 tooltip 會跑去視窗左上角閃動一下」):觸發點被藏起來(`display:none` 祖先 / keep-mounted 收起 / 隱藏的 docs 分頁 / 虛擬捲動回收)或卸載時,**浮層不得被畫出來**。內容 portal 到 body,不會跟著被藏;錨點量出來是 0×0,Radix 仍會拿它算位置 → `(0, sideOffset)` 視窗左上角,關閉動畫還會在那裡播完。DS 預設開 `hideWhenDetached`(SSOT:`tokens/elevation/overlay-geometry.ts` `OVERLAY_HIDE_WHEN_DETACHED`;Popover / HoverCard / DropdownMenu 同一顆常數),位置與 `visibility:hidden` 由同一次定位計算寫進同一個 style 物件,所以錯位的那一幀不可能被畫出來。機械閘:`scripts/overlay-detached-anchor-invariant.mjs`(修前的 build 跑它會紅在 `translate(0px, 8px)`)。

## 受控開關(open / defaultOpen / onOpenChange)

Radix idiom passthrough:`open`(受控)/ `defaultOpen`(非受控初始開啟)/ `onOpenChange`(開關回報)三 prop 語意與 Radix Root 一致。實作上 DS `Tooltip` wrapper **恆以受控模式掛 Radix Root**——`open` 未傳時由 wrapper internal state 鏡射 Radix 的 hover/focus/delay 決策(`defaultOpen` seed internal state),開/關**時機**仍由 Radix 決定(見「為何無 StateBehavior」)。理由:`truncated-text.tsx` 截斷抑制 canonical `open={isTruncated ? undefined : false}` 若直通 Radix 會反覆 controlled ↔ uncontrolled 切換(dev warning 噪音,consumer 實證)。`open` 與 `defaultOpen` 同傳時 `open` 勝(Radix idiom)。

## 禁止事項

- ❌ 不要在已有完整 label 的按鈕上加 tooltip 重複同樣的文字
- ❌ 不要在 tooltip 裡放互動元素——改用 HoverCard
- ❌ 不要把 tooltip 當作必要資訊的唯一載體——tooltip 需要 hover 才能看到，觸控裝置無法觸發
- ❌ 不要為個別 tooltip 設定不同的延遲時間——全產品統一一組參數
- ❌ 不要在 tooltip 內截斷資訊——tooltip 是資訊終點，內容必須完整
- ❌ 不要對 `TooltipContent` 傳空內容——空 tooltip 是無意義的視覺雜訊(空值時元件不掛浮層,見「邊界狀態」)

---

## 為何無 ColorMatrix / SizeMatrix / StateBehavior

Tooltip 是**單一職責 hover 提示 primitive**(一句話補充),刻意無變體:

- **無 ColorMatrix**:Tooltip 固定一種視覺(`--tooltip` bg + white text,內部 wrapper 強制 `data-theme="dark"`——不隨頁面主題反轉,dark mode 下 `--tooltip` 有自己的深色值),無 variant / severity / hue。若需要有色 hint,那是 Popover / HoverCard 的職責。故無 color matrix。
- **無 SizeMatrix**:Tooltip 無 size prop,尺寸由內容 + max-width 常數決定(本 spec「最大寬度」段)。不提供 sm/md/lg tier——短文字 hint 不需要尺寸變體。
- **無 StateBehavior**:Tooltip 是 passive 出現 / 消失(hover / focus 觸發,見「出現時機」段),無 hover / selected / active / disabled 這類互動元件 state。開 / 關行為由 Radix primitive 處理,寫在 `Overview` 的 usage 說明已足夠。

對應 anatomy story:保留 `Overview` + `Inspector`(side 切換 + token 對照) + 元件特有 `PlacementReference`(4 種 side 方向對照 + side-aware 動畫表;Tooltip 走 `align="center"` 輕量浮層例外,見「Align 對齊」段,無 align 軸矩陣)。

---

## 相關

- `../HoverCard/hover-card.spec.md` — hover 觸發的可互動浮層（**Tooltip vs HoverCard 的分界 SSOT 在 HoverCard spec**「與 Tooltip 的分界」段落）
- `../Button/button.spec.md` — `iconOnly` 模式自動產生 tooltip（由 aria-label 驅動）
- `../../tokens/elevation/elevation.spec.md`「疊放順序」— Tooltip `z-[70]`,蓋在 Toast(`z-[60]`)與所有 modal / 浮層之上;唯一可能在它上面的是頁面層的拖曳影像(拖曳元件放在 modal / 浮層裡時,影像被那一層封頂、在提示之下)(user 2026-10-13 採納;理由、世界級對照與閘都在該節)

## A11y 預設

**ARIA / Pattern**:繼承 Radix `tooltip` primitive a11y 預設(role / aria-* / 鍵盤導覽)。詳 [Radix Accessibility docs](https://www.radix-ui.com/primitives/docs/components/tooltip#accessibility)。

**Keyboard 行為**:

- Tab — focus trigger 時顯示
- Esc — 關閉

**Focus**:non-modal hover/focus surface — focus 開啟 surface,**不 trap**,focus 仍 在 trigger,Esc 關閉。Visible focus ring 由 trigger 元件自身的 focus-visible 樣式提供(各 trigger 元件 canonical;Tooltip 本體不另加焦點框)。(2026-05-27 修正 codex M31 finding:Tooltip 非 modal,不該有 focus trap,原 wording 誤導)

**驗證**:Storybook a11y addon panel 應 0 critical violation;鍵盤完整可操作(無需滑鼠)。WCAG AA contrast ≥ 4.5:1(text)/ 3:1(UI)。

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `agent-panel.spec.md`
- `calendar.spec.md`
- `coachmark.spec.md`
- `date-picker.spec.md`
- `dialog.spec.md`
- `hover-card.spec.md`
- `inline-edit.spec.md`
- `item-anatomy.spec.md`
- `link-input.spec.md`
- `motion.spec.md`
- `popover.spec.md`
- `profile-card.spec.md`
