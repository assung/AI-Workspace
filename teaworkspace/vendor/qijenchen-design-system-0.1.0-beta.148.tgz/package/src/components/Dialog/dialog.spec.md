---
component: Dialog
family: composite
variants: {}
sizes: {}
traits:
  - isOverlay
benchmark:
  - Radix Dialog primitive: github.com/radix-ui/primitives/tree/main/packages/react/dialog
  - Ant Design Modal: github.com/ant-design/ant-design/tree/master/components/modal
  - MUI Dialog: github.com/mui/material-ui/tree/master/packages/mui-material/src/Dialog
  - Polaris Modal: github.com/Shopify/polaris/tree/main/polaris-react/src/components/Modal
---


# Dialog 設計原則

## 定位

Modal 對話框，基於 Radix Dialog。用於**需要使用者注意力、阻斷背景互動**的操作流程（建立、編輯、確認）。

**Layout Family**：非上述 family — composite / multi-section（多區塊組合，自 own layout）。

---

## 何時用

- **需要專注的操作流程**：建立 / 編輯複雜表單、多步驟精靈、付款結帳
- **破壞性動作確認**：刪除、離開不儲存、登出多個裝置
- **短暫但重要的資訊**：首次引導、重要公告必須被看到才能繼續
- **需要阻斷背景互動的脈絡**：使用者必須完成或取消此流程才能回到頁面

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| 短暫的操作回饋（成功 / 失敗訊息）| `Toast` | Dialog 會阻斷流程，Toast 非阻斷 |
| 持久的頁面內通知 | `Alert` | Alert 是 inline 嵌入，不浮起 |
| 側邊操作面板（不需完全阻斷）| `Sheet` | Sheet 從側邊滑入，視覺更輕、常搭配列表 detail |
| 浮動的精簡選單 | `DropdownMenu` / `Popover` | Dialog 是 modal,DropdownMenu/Popover 是輕量浮層 |
| Hover 才出現的輔助資訊 | `Tooltip` / `HoverCard` | Dialog 需要明確觸發,hover 不該是 modal 觸發 |
| 手機全屏編輯 | `Sheet` (bottom / fullscreen) | Dialog 預設 viewport inset,行動裝置用 Sheet 更自然 |

---

## 結構

```
DialogContent (fixed, centered)
├── DialogHeader(消費 SurfaceHeader)
│   ├── DialogTitle
│   └── Close button(永遠存在,規格見「關閉按鈕」)
├── DialogBody(scrollable——ScrollArea canonical,見下)
└── DialogFooter(消費 SurfaceFooter)
    └── Action buttons
```

**Padding SSOT**：Header / Body / Footer 的 padding + 分隔線由 `patterns/overlay-surface/overlay-surface.spec.md` own——Dialog 與 Popover 共用同一套 primitive，避免 token 漂移。Dialog 特有行為:Header 的 Close 按鈕;Body 用 `<ScrollArea>` wrap(viewport-fill 專用,SSOT 見 overlay-surface.spec.md 「Body overflow canonical」節 + `components/ScrollArea/scroll-area.spec.md`)。

## Density(2026-06-16 定論:全繼承 page,不鎖)

Dialog **不自設任何 density attribute**,layout-space + ui-size 全繼承 page。效果:md page → body `px-loose`=16 / header `py-tight`=12(header 48);lg page → 24 / 16(header 56),隨 page。

**為何不鎖(撤回本 session 一度加的 `data-layout-space="lg"`)**:本 `density.spec` 第 10 行親自定義 layout-space 管「dialog body padding」—— Dialog 若鎖死 layout-space,等於 override 我們自家 dial 對它點名要管的對象失效 = **自相矛盾**。有「同類 padding-density dial」的世界級 DS(SAP Fiori cozy/compact 做 `syncStyleClass` 專門把 page density 同步進 dialog;AWS Cloudscape compact「propagate to all components, in all view types」,例外只列 informational + tiny dropdown,modal 不在內)都讓 **modal 跟 page dial 走**,沒有一家把 modal 釘固定 tier。Material/Atlassian 的固定 24 是因為它們**沒有** density dial(其 24 = 我方 lg)。

**「modal 要寬鬆呼吸」怎麼滿足**:lg 產品自動拿 24(Material 級);md 產品本就要緊湊(資訊密集),16 是合格 modal padding(Polaris Modal = 16,世界級下限)。**「button 不撐高 header」**由 ui-size 繼承 page 解決(button = page sm),與 layout-space 鎖不鎖無關 → 故不需鎖。

**Header 高度**:padding-based = title line-box 24 + `py-tight`×2 → md 48 / lg 56,**隨 page tier**(= `--chrome-header-height` 同 tier 對齊)。

**世界級對照**:Material M3 / Atlassian 24(無 dial,= 我方 lg)/ Polaris 16(= 我方 md 下限)/ SAP Fiori + Cloudscape(有 dial → modal 跟 dial = 我方繼承)。

## Layout

- **水平 padding**：`px-[var(--layout-space-loose)]`（header / body / footer 統一）
- **Header / Footer 垂直 padding**：`py-[var(--layout-space-tight)]`
- **Body 垂直 padding**：`pt-[var(--layout-space-tight)]` + `pb-[var(--layout-space-bottom)]`——底部留較大空間，視覺上不壓迫

## Viewport Inset

Modal 與 viewport 四邊保持 `--layout-space-viewport-inset`(48px)最小間距。**這顆 token 是 2026-09-11 從
`--layout-space-bottom` 拆出來的**:後者的語意是「結論留白:內容到 action buttons」(`layoutSpace.spec.md` Token 表),
跟「浮層外殼到視窗邊」是兩個概念,值剛好都是 48 而已。耦合著會讓任何人調結論留白時,意外改掉全站 Dialog 的高度**與最大寬度**。

寬與高都吃同一個 inset:`min(maxWidth, 100vw - inset*2)` / `min(100svh - inset*2, maxHeight)`。

**其他消費者**:AppShell 的浮層「另一側至少留」的距離(user 2026-10-14 規格 U:55「浮層也可以拖曳調寬，另一側至少保留 48px」)—— AI agent 浮層的左側(2026-09-16 起;2026-10-14 前是「蓋板寬 = 容器 − inset」撐滿,現在寬度照紀錄、inset 是下限)與 Menu 浮層的右側;規則住 `../AppShell/app-shell.spec.md`「版面規則」§9。本 token 的 owner 仍是本段;改值時三個消費者一起變。

## 高度

### 最大高度(上限)—— 兩種模式共用同一條公式

```
上限 = maxHeight 有值 ? min(100svh - inset*2, maxHeight) : (100svh - inset*2)
```

- **恆小於視窗高**,所以 header 與 footer 在絕大多數情況都露得出來(超長內容由 body 自己捲,外框不動)。
- **consumer 只能往更矮調**:`maxHeight` 傳比視窗大的值也會被 `min()` 夾住。型別 `string | number`
  (number 視為 px;string 才寫得出 `60svh` / `calc(100svh - 120px)`),與同元件的 `maxWidth` 同型別。
  形狀對齊 `DropdownMenu` 的 `maxHeight`(同樣是「可選更低上限」)。
- **用 `svh` 不用 `vh`**:行動裝置網址列收合時 `100vh` 大於實際可視高度,底部主要動作鈕會被切掉。
  DS 其他填滿視窗的外框已是這個選擇(`app-shell.tsx` 的 `h-svh`、`sidebar.tsx` 的 `100svh`)。桌機兩者等值。

### 高度軸(怎麼長)—— 正交於上限

| `height` | 行為 | 什麼時候用 |
|---|---|---|
| **`'fill'`(預設)** | 高度 = 上限。內容多寡不改變外框幾何,body 擁有捲動 | 開啟到關閉期間**內容高度會變**:異步載入、可展開區塊、可增減的清單 |
| **`'hug'`** | 高度隨內容長高,碰到上限才由 body 捲動 | 開啟到關閉期間**內容高度不會變**:確認框、短表單、固定文案 |

**判準是時間維度,不是當下看起來有幾行**:從開啟到關閉,內容高度會不會因為使用者的操作與互動而改變?
會 → `fill`;不會 → `hug`。理由:隨內容長高的浮層一旦內容變高變矮,整個對話框會上下跳動,體驗很差 ——
先把可用高度穩定下來、讓 body 自己捲,外框就不動了。**現在預期不會變、但未來會加入異步 section 的,選 `fill`。**

`autoHeight?: boolean` 已 **deprecated**,等同 `height="hug"`;兩者同時傳時 `height` 勝並在 dev 環境 warn。**DS 內部(元件、story、閘的夾具)一律不再使用**(2026-10-20 把 30 處用法遷完 —— 27 處在 DS 原始碼(CommandDialog、AgentPanel 改名 / 刪除對話框、各頁 story)、3 處在閘的夾具;獨立驗證 OV-09:設計原則頁還在教舊名);保留這個 prop 只為了既有 consumer 不壞。閘 `scripts/overlay-story-contract-invariant.mjs` S3(DS 原始碼與閘夾具裡任何 `<DialogContent autoHeight>` 都紅)。

**世界級對照**:Material Web(`max-height: min(560px, calc(100% - 48px)); height: fit-content`)、
Atlassian(`if (!input) return 'auto'`)、Polaris(只宣告 `max-height`)、Carbon(size 綁 48/72/84/96% 上限)、
Ant Design(不宣告高度)—— 五家第一方原始碼**預設都是「隨內容 + 視窗為上限」**。
本 DS 預設選 `fill` 是刻意偏離:DS 的主場景是內容會變的產品 dialog,穩定外框優先;
需要世界級預設行為的場景顯式傳 `height="hug"`。

**閘**:`scripts/dialog-height-invariant.mjs` —— H1 兩種模式回報同一個上限、H2 上限 = 視窗 − inset×2 且小於視窗且不溢出、
H5(2026-09-12 新增)在 240px 視窗下掃**每一支** dialog / sheet story,驗「沒有後代畫到容器外」+「捲到底後
最後一個互動元素完整可見」。H5 有**自己的**對照組 `--selftest-h5`(既有 `--selftest` 會拿掉高度上限、
把 dialog 變成 99904px 高,那樣誰都不會溢出,H5 的條件永遠觸發不了);`--selftest-h5` 還原
容器 overflow 與 Tabs 的 flex,實測精準抓到 `展示--with-tabs-in-header`。
H1-H4 當時全綠卻沒攔下這個 bug,因為它們只測 dialog **自己**的高度,沒測「dialog 與 body 之間夾了別的 wrapper」。
H3 `hug` 真的隨內容長高而 `fill` 不隨內容變、H4 `maxHeight` 只能更矮。
對照組把上限拿掉必須紅(實測 fill 變 99904px、溢出視窗)。

## maxWidth

預設 512px，consumer 可透過 `maxWidth` prop 調整。型別 `string | number`（傳 number 視為 px）。

**父層契約(2026-09-12 補,原本漏了)**:DialogContent 必須是 `flex flex-col` + `max-h` + **`overflow-hidden min-h-0`**。
這不是新規定 —— `patterns/overlay-surface/overlay-surface.tsx:180-182` 逐字寫著「parent(PopoverContent /
HoverCardContent / Dialog / Sheet)是 flex flex-col + max-h + overflow-hidden」,Popover 與 HoverCard 一直有,
**Dialog 與 Sheet 漏了**(user 2026-09-12 截圖:視窗變矮時 dialog body 內容直接畫到圓角容器外面)。

**中間 wrapper 也要能收縮**:上面那條只保證「不畫到外面」;要讓「內容溢出走 body 捲動」成立,
DialogContent 到 DialogBody 之間的**每一層**都必須是可收縮的 flex column。實際踩到的是 `<Tabs>` ——
Radix Tabs Root 是裸 `display: block` + `min-height: auto`,夾在中間時整包內容原樣頂出容器
(實測 204px 的 dialog 裡 Tabs Root 撐到 271px)。修法是讓 **Tabs Root 自己**成為
`flex min-h-0 data-[orientation=horizontal]:flex-col`(`tabs.tsx`),consumer 不需要背咒語;
已逐 story 比對 23 支含 Tabs 的畫面幾何 Δ=0。

**邊界**:上限被 viewport inset 截斷 `min(maxWidth, 100vw - inset*2)`(見「Viewport Inset」);無下限 clamp——過小值不擋,內容溢出走 body 捲動,由 consumer 自負。

## 關閉按鈕

> **跨家族 SSOT pointer**:DialogHeader 屬 **Padding-based overlay header 家族**;border / padding / dismiss size / withTabs(tabs 進 header 時 border auto-suppress)的跨家族視覺契約 SSOT 詳 `patterns/header-canonical/header-canonical.spec.md`。本節僅 codify Dialog 特有 close X size + chrome-unbounded rationale。

永遠存在於 DialogHeader 右側。使用 `<Button data-dismiss iconOnly dismiss size="sm" startIcon={X} aria-label="關閉" />`，不可移除——使用者永遠需要明確的關閉手段。

**Size canonical(v5 chrome-unbounded)**:Button native size **sm**(隨 page density:28 md / 32 lg),命中區亦同(命中 ≡ 可視,owner = `ds-canonical/references/hit-area-canonical.md`;2026-09-24 把原文的「touch target」正名為命中區 —— 本 DS 以滑鼠指標的精度為前提,尺寸不以觸控門檻推導)。SurfaceHeader 的 `[data-unbounded]` CSS rule 自動對 text variant / dismiss 套負 my → **layout 佔位 = title line-box**(slot 衍生自 `--font-body-lg-size`×1.5=24,見 `overlay-surface.spec.md` slot 段)。效果:
- Header 只有 title + close X → max layout = 24 → header = 24 + 2×`py-tight`(隨 page:md 12 / lg 16)= **48 md / 56 lg**(= `--chrome-header-height` 同 tier 對齊)✓
- Header 塞 bounded primary(無 `data-unbounded`)→ header 自然長高

**Canonical 來源**:Dialog 是 overlay chrome，corner close X 屬 action group region，必用 Button(非 Inline Action / 非自刻 button)。詳見 `patterns/element-anatomy/inline-action.spec.md`「Dismiss canonical — X close only」+ `patterns/overlay-surface/overlay-surface.spec.md`「Chrome dismiss size canonical」。

### Header actions slot(2026-07-08)

Header 級操作(記錄 prev / next 導覽、header 級溢出選單 ⋮ 等「作用於整個 dialog 內容」的操作)走 `<DialogHeader actions={…}>` slot,**不**塞 children 自刻右側 cluster。

- **何時用**:操作對象是 dialog 承載的記錄本身(切換上下筆、複製連結、更多選單)。欄位級操作仍歸 body;confirm / cancel 歸 footer。
- **分隔線由 DS 自動放**:actions 與內建 Close X 之間 DS 渲 `<ButtonDivider>` — `action-bar.spec.md:281`「最右側為關閉 / 解除按鈕 → 分隔線必須(誤觸保護)」;幾何 = ButtonDivider `mx-1` 於 `gap-2` cluster → 兩側 12px 對稱(同 spec「分隔線幾何」段)。
- **按鈕形態**:`<Button variant="text" iconOnly …>`(text variant 自動 `data-unbounded`,不撐高 chrome header;對齊 action-bar「溢出按鈕一律最低視覺重量」)。
- ❌ **禁**:consumer 在 children 內自刻 cluster + divider(分隔線落點歸 DS,自刻 = 漏分隔線 / 幾何 drift 根因 — 2026-07-08 WM 詳情 header 錨例)。

## Title

`text-body-lg font-medium truncate`——單行截斷，不換行；截斷時 hover 顯 tooltip 補完整標題（僅實際截斷才顯——rule owner `components/Tooltip/tooltip.spec.md`「截斷文字 → tooltip」；實作消費 `patterns/element-anatomy/truncated-text.spec.md` `<TruncatedText>`）。

**Header 可成長**:Dialog 提供 `<DialogDescription>` primitive 作副標/補充說明(`mt-[var(--item-gap-label-desc-reading-lg)] text-body text-fg-secondary` — title body-lg 16 + desc body 14 → reading-lg token)。Consumer 傳 title + description 時 header 自然長高(這也是為何 Dialog / Sheet / Popover 的 SurfaceHeader 刻意 **padding-based 而非 fixed-h** — 宣告 chrome 可成長)。詳見 `patterns/overlay-surface/overlay-surface.spec.md`「為什麼 SurfaceHeader 是 padding-based」+ `tokens/uiSize/uiSize.spec.md`「Chrome header 選型 canonical」節(含「2 種 pattern 對照」)。

## Footer 按鈕

預設 size `md`，與 Field 系統表單元件尺寸一致。按鈕靠右對齊（`justify-end`），間距 `gap-2`。

## 視覺

- **Overlay**：`bg-overlay`
- **Shadow**：`elevation-200`（浮層級）
- **圓角**：`rounded-lg`
- **背景**：`bg-surface-raised`
- **邊框**：`border-border`
- **分隔線**（header / footer）：`border-divider`

## 動畫

**Canonical = 從中心淡入 + 輕微縮放,不位移**(2026-09-09 定;anchor:user 抓到「dialog 從左上角飛到中間」)。

| 階段 | 幾何 | 時長 / 曲線(全部消費 `tokens/motion/motion.spec.md`「進出場動畫 token」,經 `overlay-motion.ts` 的 `surfaceMotion`) |
|---|---|---|
| 進場 | `fade-in-0` + `zoom-in-95`(opacity 0→1、scale 0.95→1,transform-origin 中心) | `--motion-duration-surface` 250ms / `--motion-easing-enter` |
| 離場 | `fade-out-0` + `zoom-out-95` | `--motion-duration-surface` 250ms / `--motion-easing-exit` |
| Overlay | 只 fade | 同上 |
| 收尾 | 關閉後保持最後一格(透明 / 縮小)直到卸載(surfaceMotion 內建 `holdClosedEndState`,不靠 Radix 的執行期補丁;`tokens/motion/motion.spec.md`「開合動畫」) | — |
| `prefers-reduced-motion` | 不播:surfaceMotion 只在 `motion-safe:` 下宣告動畫(2026-10-07 前寫的 `motion-reduce:animate-none` 權重輸給 `data-[state=…]:animate-*`,從沒生效,待辦總帳 T7) | — |

**為何不用 slide(置中位移)**:置中靠 `left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2`。shadcn v3 時代 DialogContent 另掛 `slide-in-from-left-1/2 slide-in-from-top-[48%]`,那是因為 Tailwind v3 的 `-translate-x-1/2` 走 `transform`,會被 keyframe 的 `transform` 整個蓋掉,所以要在 keyframe 裡把置中位移再寫一次(v3 dialog 原始碼:<https://ui.shadcn.com/r/styles/new-york/dialog.json>)。Tailwind v4 的 `-translate-x-1/2` 改寫進獨立的 `translate` 屬性(<https://tailwindcss.com/docs/translate>,`translate: calc(1/2 * -100%) var(--tw-translate-y)`),不再被 keyframe 蓋掉;而 tw-animate-css 的 `@keyframes enter` 仍是 `transform: translate3d(var(--tw-enter-translate-x), var(--tw-enter-translate-y), 0) scale3d(…)`(`node_modules/tw-animate-css/dist/tw-animate.css`)。兩個位移相加 → 第一幀中心落在視窗中心**左 w/2、上 0.48h**(480×189 的確認框實測 −240px / −90.72px),看起來就是從左上角飛進來。shadcn v4 版本已把這兩組 class 拿掉(<https://github.com/shadcn-ui/ui/blob/main/apps/v4/registry/new-york-v4/ui/dialog.tsx>:`translate-x-[-50%] translate-y-[-50%] … data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95`,無 slide)。

**世界級對照(2026-09-09 逐一開原始碼)**:

| 來源 | 進場幾何 | 位移 |
|---|---|---|
| shadcn v4 `dialog.tsx`(<https://github.com/shadcn-ui/ui/blob/main/apps/v4/registry/new-york-v4/ui/dialog.tsx>) | `fade-in-0` + `zoom-in-95`,`duration-200` | 無 |
| Radix Themes `base-dialog.css`(<https://github.com/radix-ui/themes/blob/main/packages/radix-ui-themes/src/components/_internal/base-dialog.css>) | `rt-dialog-content-show 200ms`:`opacity 0→1; transform: translateY(5px) scale(0.97) → scale(1)` | 5px(視覺上等同不位移) |
| Angular Material `dialog.scss`(<https://github.com/angular/components/blob/main/src/material/dialog/dialog.scss>) | `opacity 0→1; transform: scale(0.8) → none`,easing `cubic-bezier(0,0,0.2,1)` | 無 |
| MUI `Dialog.js`(<https://github.com/mui/material-ui/blob/master/packages/mui-material/src/Dialog/Dialog.js>) | 預設 transition = `Fade`(只 opacity) | 無 |
| Material Web(M3)`animations.ts`(<https://github.com/material-components/material-web/blob/main/dialog/internal/animations.ts>) | scrim opacity 0→0.32、container height 35%→100% + 內容 fade | `translateY(-50px→0)`(M3 expressive 的例外,不採) |
| Apple HIG Modality / Alerts(<https://developer.apple.com/design/human-interface-guidelines/modality>) | alert 居中、疊在所有內容之上;無「從角落滑入」 | 無 |

主流四家(shadcn <https://github.com/shadcn-ui/ui/blob/main/apps/v4/registry/new-york-v4/ui/dialog.tsx> / Radix Themes <https://github.com/radix-ui/themes/blob/main/packages/radix-ui-themes/src/components/_internal/base-dialog.css> / Angular Material <https://github.com/angular/components/blob/main/src/material/dialog/dialog.scss> / MUI <https://github.com/mui/material-ui/blob/master/packages/mui-material/src/Dialog/Dialog.js>)一致 = 中心淡入 + 縮放;唯 Material Web <https://github.com/material-components/material-web/blob/main/dialog/internal/animations.ts> 帶 50px 下落,屬 expressive 風格,與本 DS 企業級中性沉穩(`--motion-easing-enter` = Material standard-decelerate,見 `tokens/motion/motion.spec.md`)不合,不採。

**閘**:`scripts/dialog-coexistence-invariant.mjs`「進場第一幀」段 —— (S) 靜態禁 DS-wide 任何檔案同時出現 `slide-in-from-left-1/2` 類置中位移 class 與 `-translate-x-1/2` 置中;(M) 瀏覽器把進場動畫凍在 t=0(WAAPI seek)量 `[role=dialog]` 中心相對視窗中心偏移必 ≤ 1px;對照組把兩組 slide class 加回去必須紅。

## 狀態處理的職責邊界

Dialog 是容器，無整體 disabled / loading / empty 狀態——這些屬於內容層的責任：

| 狀態 | 處理方式 |
|------|---------|
| **Loading**(內容載入中) | Consumer 在 `DialogContent` 內渲染 Skeleton / CircularProgress,不是讓 Dialog 本身等待開啟 |
| **Empty**（如步驟 dialog 還沒資料）| Consumer 在 content 區用 `Empty` primitive |
| **Error**（操作失敗）| Consumer 在 content 區用 `Alert` |
| **Disabled**（整個 dialog）| N/A——dialog 要麼開著（可互動）要麼關著（不存在）。要鎖操作請 disable 內部個別 Button / Field |

**Dark mode**：由 semantic token（`bg-surface-raised` / `border-border`）自動切換，無自訂 palette。

**Density**:Dialog **全繼承 page**(layout-space + ui-size 皆不自鎖),見上「Density」段。

---

## 並存(`persistentElements`)

由來:代理原則 v14 條 A / B(`governance/planning/2026-09-06-agent-principles-v14.md`)—— 有自己 URL 的內容開著時,指定的常駐區域(代理面板、評論側欄)要**仍然可用**;它對宿主其餘部分仍然是 modal。

- **怎麼開**:`<Dialog persistentElements={() => [panelEl]}>`;Root 自動走 Radix `modal={false}`(否則 Radix 的 `hideOthers(content)` 會把常駐區域一起關掉),DS 再用 `inertOutside([content, ...persistent])` 把其餘一切設成 `inert`(`lib/overlay-coexistence.ts`;自己記帳、不與 Radix 的 `aria-hidden` 鎖共用計數,頁面上不屬於任何控件的播報區 `[aria-live]`(Toast 區、DS 播報)保留、照常念,與一般 modal 的 `hideOthers` 同一個目的;控件裡的播報區跟著被擋住的控件一起 inert —— 2026-10-07 根因見該檔說明)。
- **遮罩**:Radix 在非模態不畫 Overlay,DS 自己畫 `CoexistenceMask` —— `fixed inset-0` 的遮罩,用 `clip-path: path(evenodd)` 在每個常駐節點的位置挖洞;洞裡沒有遮罩像素也沒有命中區,常駐區域照常可見可點;洞外點下去是「外部點擊」→ 關閉(modal 語意)。洞的座標以遮罩自己的盒子為原點(遮罩可能被傳送進帶 transform 的畫布)。
- **層級**(2026-09-08 定):遮罩 `z-30` < 並存 modal 內容 `z-40` < AI agent 浮層 `z-[45]` < 一般 modal `z-50`(全 DS 層級表的一段;整張表 —— 含之上的 Toast `z-[60]`、Tooltip `z-[70]` —— 唯一住所 `../../tokens/elevation/elevation.spec.md`「疊放順序」)。沒有 URL 的確認框(不傳 persistentElements)維持一般 modal,蓋在常駐區域之上。AI agent 浮層自己的遮罩(同一支 `CoexistenceMask`,接住指標;點它關閉代理面板、並存 modal 留著,2026-09-17 裁示)也在 `z-30`,所以並存 modal 仍在它之上、面板之下;本遮罩算洞時把任何 `[data-coexistence-mask]` 當「遮罩不是洞」跳過,並存 modal 的外部點擊守衛把常駐殼子樹(含那張遮罩)視為不關;浮層左側留白處因此疊了兩張遮罩、暗兩次(刻意:那一帶既在 modal 外、也在面板外)。2026-10-14 起 AI agent 浮層的寬度照寬度紀錄(不再撐滿到只留 48),並存 modal 可能有一部分露在浮層左側:它在代理遮罩之上(`z-40` > `z-30`)但被抑制(`inert`),指標點在它上面會落到底下的代理遮罩 → 關閉 AI agent、modal 完整露出可操作,與點遮罩同一個結果(AI 推導:層級表與點遮罩關閉都是既有規則,這一格是兩者的交集)。反過來,一般 modal(`z-50`)開著時視窗變窄、AI agent 變成浮層:modal 畫在浮層上面、不是被蓋住的宿主,照樣可操作(AI 推導,2026-10-14 審查抓到原本被一起設成 `inert`;規則住 `../AgentPanel/agent-panel.spec.md`「疊在浮層上面的不是宿主」)。
- **框外事件的守衛**(2026-09-09 / 2026-09-10 定;`lib/overlay-coexistence.ts` `createPersistentGuard`,Dialog 與 FileViewer 共用同一份):非模態分支把「指標按在框外 / 焦點跑到框外」當關閉訊號,並存時三種目標**不算框外**:(1) 保留節點子樹;(2) 保留區**自己開出來的浮層**(入口鈕右鍵選單、面板裡的 Select / Popover;portal 到 body,用觸發器的 `aria-controls` / `aria-owns` 認回來)—— **含它關閉中的階段**(Radix 只在開著時寫 `aria-controls`,滑鼠點選單項後選單關閉中仍會收到一次焦點;認過的浮層 id 要記住,否則對話框會在選項執行的同時被關掉,2026-09-10 user 抓到);(3) 疊在上面的另一個 dialog。閘:`scripts/agent-url-registry-demo-invariant.mjs` S11(右鍵選單留著)、S12(滑鼠點選單項:選項執行、對話框不關、遮罩仍在;鍵盤路徑為對照)。
- **Esc 與外部互動**:焦點在常駐區域內時的 Esc / pointer / focus 不算「框外」(`onPointerDownOutside` / `onFocusOutside` / `onInteractOutside` 對常駐節點 preventDefault),否則把焦點移進代理面板就會把對話框關掉。
- **捲動**(2026-09-29 定,待辦總帳 OE13;user 原話「第二題照你建議」—— 建議由 AI 提出、user 採納):並存時**舞台鎖捲動**(它對宿主其餘部分仍然是 modal),**常駐區自己的捲動照常**。機制 = Radix 同款 `RemoveScroll shards`:Content 是鎖的根(`as={Slot}`,不多一層 DOM)、常駐節點是 shards(鎖外但准捲,只擋它捲到底之後的溢出),其餘一切的 wheel / touchmove 被擋;疊上一般 modal 時由它的鎖(lockStack 最上層)接手。`react-remove-scroll` 因此列為 DS 直接相依(exact `2.7.2`,與 Radix 相依同版)。為什麼先前可捲:Radix 只在 modal 分支掛它 —— `radix-ui/primitives` `packages/react/dialog/src/dialog.tsx` `DialogOverlayImpl` 逐字 `<RemoveScroll as={Slot} allowPinchZoom shards={…contentRef…}>`,而 `DialogOverlay` 在 `context.modal` 為 false 時回 `null`(https://github.com/radix-ui/primitives/blob/main/packages/react/dialog/src/dialog.tsx);並存走 `modal={false}`,非模態分支沒有任何捲動處理。一手預設(四家都鎖):Radix Dialog.Root `modal` — Type `boolean`、Default `true`(https://www.radix-ui.com/primitives/docs/components/dialog);MUI Modal `disableScrollLock` — Type `bool`、Default `false`、「Disable the scroll lock behavior.」(https://mui.com/material-ui/api/modal/);Ant Design Modal `scrollLock` — 「Whether to lock body scroll when modal opens」、`boolean`、Default `true`、6.5.0(https://ant.design/components/modal);Chakra UI v2 Modal `blockScrollOnMount` — 「If `true`, scrolling will be disabled on the `body` when the modal opens.」、`boolean`、Default `true`(https://v2.chakra-ui.com/docs/components/modal/props)。`removeScrollBar` 保留預設 true,與一般 modal 同款(body 有捲軸才拿掉並補寬防跳版;並排佈局 body 沒捲軸 → 開關對話框常駐側欄 0px 位移,閘量)。**限制**:常駐區自己 portal 到 body 的非模態浮層不在 shards 裡,滾輪會被擋 —— 與已裝版本 Radix 在一般 modal 裡開 Popover 同款限制。閘:`scripts/dialog-coexist-scroll-lock-invariant.mjs`(舞台空白處合成滾輪 scrollTop 不變、常駐區清單會動、一般 modal 照舊鎖、開關無跳版;`--selftest` 在頁面上把鎖拆掉必紅)。
- **`portalContainer`**:Content 預設傳送到 body;story 的「模擬瀏覽器畫布」或產品的嵌入式畫布可傳一個帶 transform 的容器,`fixed` 定位以它為準,modal 與遮罩不會跑出畫布。
- **遮罩的洞只挖給「點得到或畫得出來」的盒子**(2026-09-09 根因修正):常駐節點底下 `display:contents` 的殼與 `pointer-events:none` 的定位圖層都沒有資格自己當洞,往下找子節點;`<svg>` / `<img>` / `<canvas>` / `<video>` 即使 pointer-events:none 也算。錨:user 2026-09-09「為何關閉 agent 之後,原本 dialog 該有的遮罩就消失了?」—— 代理關閉後常駐殼裡換成入口鈕 Dock,它外層是與舞台等大的 `pointer-events-none absolute inset-0` 裁切圖層,舊判準「有盒子就是洞」把整層當成洞,evenodd 之下洞 = 外框、遮罩整張被挖空。
- **背景位置模式(Background location)**(user 2026-09-09 原話:「若有來源頁面,則保留該頁面作為 Modal 的背景;若無來源頁面,則將 Modal 顯示於預先定義的預設背景頁面之上」):有 URL 的 modal 由宿主路由承載 —— 從某一頁點開時,該頁留在 modal 底下作背景(路由記 `backgroundLocation`);直接以 modal 網址進入(重新整理、上一頁回到該網址、分享連結)沒有來源頁,宿主把 modal 疊在**預先定義的預設背景頁**上。上一頁 / 下一頁 / 重新整理都維持這個模型。這是宿主路由層的責任,Dialog 只提供 `persistentElements` + `portalContainer`,不讀 URL;示範 → `AgentPanel/展示/UrlRegistryDemo`(v14 推導表「有來源頁」「直接進入 modal 網址」兩列)。
- **閘**:`scripts/dialog-coexistence-invariant.mjs`(常駐區可聚焦可打字、其餘背景被抑制、預設路徑照舊隔離)、`scripts/dialog-coexist-scroll-lock-invariant.mjs`(並存捲動鎖:舞台不捲、常駐區可捲、一般 modal 照舊、開關無跳版)、`scripts/agent-url-registry-demo-invariant.mjs`(S1–S9:幾何、header / footer 變體、存檔、新增、刪除確認、背景位置、session、關 agent 遮罩仍在、AI agent 浮層態工具列可點 + Esc 分區;2026-09-09 併入原 `agent-modal-coexistence-invariant.mjs`)。

---

## 常見誤解

| 誤解 | 正解 |
|------|------|
| 「側邊 / 長停留面板也用 Dialog」 | 視覺重量不同——Dialog 是中央阻斷 modal,Sheet 側滑較輕(見「何時不用」+ 禁止事項「長 form wizard」條) |
| 「hug 是預設」 | 預設採 viewport-bounded 固定高度(`height="fill"`)以維持穩定外框;`height="hug"` 只給內容量已知且穩定的短 dialog(見「高度行為」) |
| 「maxWidth 想設多寬都行」 | 受 viewport inset 公式截斷(見「maxWidth」邊界) |
| 「視覺不顯示標題就可拿掉 DialogTitle」 | 必須保留,用 VisuallyHidden 包裹給 screen reader(見「A11y 預設」) |

---

## 禁止事項

- ❌ **不用 nested Dialog 承載多步驟流程**：一層一步的精靈式堆疊會讓使用者失去所在位置感，複雜多步驟流程改用單一 Dialog + 內部步驟切換。
  **⚠️ 本條 2026-08-09 收窄**（原文是「不在 Dialog 內 nested Dialog」，理由寫「使用者無法預測 Esc 關哪一層」）。兩個問題：
  （a）**該理由在本專案的技術棧不成立**——`@radix-ui/react-focus-scope` 的 `createFocusScopesStack()` 在新 scope 進入時 `pause()` 前一層、移除時 `resume()`；`@radix-ui/react-dismissable-layer` 以 layers 陣列索引判定，Esc 與 outside-click 只作用於最上層。堆疊順序是確定的，不是不可預測。
  （b）**原文與本檔「何時用」段自相矛盾**——`:29` 明列「破壞性動作確認：刪除、**離開不儲存**」是 Dialog 用途，而「離開不儲存」的確認必然出現在正在編輯的 Dialog 之上。原文的全稱禁令讓這個既有用途無法表達。
  **收窄後允許**：確認 / 警告 / 破壞性動作二次確認可疊在既有 Dialog 之上（Esc 只關最上層）。**仍禁止**：把流程步驟拆成一層層 Dialog。
- ❌ **不用 Dialog 顯示非阻斷訊息**：成功 / 失敗的短暫回饋用 Toast；持續性系統狀態用 Alert。Dialog 的阻斷成本過高
- ❌ **不把長 form wizard 塞 Dialog**：超過 3 步驟或表單高度接近全螢幕的流程改用獨立頁面或 Sheet，Dialog 不適合長時間停留
- ❌ **不在 Dialog footer 把 primary action 放左側**：CTA 靠右（`justify-end`）是跨平台使用者期待（macOS / Windows / Web 主流皆如此），反向放置會降低可用性

---

## A11y 預設

Radix Dialog 自動處理：

- **Modal 語意**：`role="dialog"`(Radix 刻意**不**設 `aria-modal="true"`,改用 aria-hidden 的 `hideOthers()` 把背景兄弟節點設 `aria-hidden` + FocusScope trap 達成隔離,避免 `aria-modal` 在部分 screen reader 隱藏整頁的已知 bug）
- **標題綁定**：`<DialogTitle>` 自動成為 `aria-labelledby` 指向對象，screen reader 開啟時讀出標題
- **說明綁定(DS 補的)**:有 `<DialogDescription>` 時 `aria-describedby` 指向它;**沒有說明(只有標題的對話框,DS 允許)時不寫 `aria-describedby`**。Radix 不論有沒有說明都寫一個指向說明 id 的 `aria-describedby`,沒寫說明時就指向不存在的元素(壞掉的 IDREF),開發模式還印「Missing `Description`」警告 —— 2026-10-20 前 Dialog / Sheet / FileViewer 都是(獨立驗證 OV-15)。機制:`DialogDescription` 掛上時向 `DialogContent` 登記,沒有登記、consumer 也沒自己指定 `aria-describedby` 時拿掉(`../../lib/overlay-description.ts`,Sheet 同一支、FileViewer 沒有說明元件直接不寫);consumer 不必再傳 `aria-describedby={undefined}`。閘 `scripts/overlay-story-contract-invariant.mjs` R7。
- **Focus trap**：焦點鎖在 Dialog 內，Tab 循環不逃出
- **Esc 關閉**：按 Esc 自動關閉 —— **一次只少一層,而焦點所在的控件自己那一層也算一層**(2026-10-01;規則與出處 `ds-canonical/references/keyboard-model-canonical.md`「焦點所在的控件自己那一層也算一層」):對話框裡改過的欄位(接 `useFormValidation`)/ 就地編輯中 / 表格的格游標 / 拖曳中 → 第一下 Esc 由控件撤銷(回復欄位 / 取消編輯 / 清游標 / 取消拖曳),對話框不關,第二下才關;乾淨的控件按 Esc 直接關。**輸入法組字中的 Esc 不關**(那一下是在取消選字,例:改名對話框用注音打字時按 Esc 取消選字,不該把對話框連同打到一半的名字一起關掉)。機制:`DialogContent` 的 `onEscapeKeyDown` 經 `../../lib/overlay-escape.ts` `withOverlayEscape`(2026-10-01 取代 ime-composition.ts 的 `withImeSafeEscape`)—— 焦點所在控件在這一層裡宣告了 `data-escape-layer` 就把那一下留給它,consumer 的 `onEscapeKeyDown` 在那一下不會被呼叫;沒有表單引擎的 `<Input>` 沒有「原值」可回復,Esc 直接關
- **Focus return**：關閉時焦點返回開啟它的元素。Radix 只還給 `DialogTrigger`;**受控 `open`、沒有 `DialogTrigger`(普通按鈕 / 列上動作 / 快捷鍵開的)→ `DialogContent` 預設就記下開啟者、關閉時還給它**(2026-10-01,待辦總帳 OE29;`../../lib/overlay-focus-return.ts` `useTriggerlessFocusReturn`:內容掛上時記開啟者、沒有 Radix 觸發點就經 `returnFocusToOpener` 還,modal 按遮罩收起也還)。開啟者住在一個會跟著關掉的選單 / 浮層裡(列上的 ⋯ 選單項開了對話框)→ 還給那個選單的觸發鈕(`persistentOpenerOf`;W3C dialog 關閉後焦點「回到打開它的那個元素,或在它消失時合理的替代」,<https://github.com/w3c/aria-practices/blob/3f094fde1c81b25dfa69162563bf28d093f854d4/content/patterns/dialog-modal/dialog-modal-pattern.html#L96-L101>)。consumer 要送去別處就在 `onCloseAutoFocus` 先 `preventDefault()` 再自己 focus(`CommandDialog` 2026-10-01 已改用預設;AgentPanel 改名 / 刪除對話框自己接線的照舊勝出)。FileViewer 不經 `DialogContent`(直接用 Radix Dialog),2026-10-20 起同樣消費 `useTriggerlessFocusReturn`(此前自己記開啟者、少了 `persistentOpenerOf` → 從選單項開的檢視器關閉後焦點掉到 body;閘 `scripts/escape-and-focus-contract-invariant.mjs` F-menu-fileviewer)。2026-10-01 前這種開法焦點掉到 body(實測 Dialog 並存夾具、AgentPanel 刪除確認框)
- **Overlay click**：點擊 overlay 關閉（可透過 `onPointerDownOutside` 阻止）

Consumer 必須保留 `<DialogTitle>`——即使視覺不顯示，也要用 `VisuallyHidden` 包裹提供給 screen reader。

---

## anatomy story 結構

Dialog 是 modal 浮層元件,關鍵決策維度是 `maxWidth`(400/480/512/560/720)× `height`(fill / hug)× `destructive` × open/close 行為。互動 `Inspector`(右側 Controls 即時切 `maxWidth` / `height` 看寬度 tier 與高度模式差異)搭配結構性矩陣 side-by-side 比對,完整呈現「照情境選 size / 選高度模式」的決策。

對應 anatomy story:`Overview` + `Inspector` + 元件特有 `HeightBehavior` + `SizeMatrix` + `StateBehavior` + `ColorMatrix` + `Accessibility`。

---

## 相關

- `../Sheet/sheet.spec.md` — 側邊滑入的輕量替代（共用 Radix Dialog base）
- `../Toast/toast.spec.md` — 非阻斷的短暫回饋
- `../Alert/alert.spec.md` — 頁面內持久通知
- `../Popover/popover.spec.md` — 輕量浮層（non-modal）
- `../DropdownMenu/dropdown-menu.spec.md` — 浮動選單
- `../Tooltip/tooltip.spec.md` — hover 輔助資訊
- `../../patterns/overlay-surface/overlay-surface.spec.md` — Header / Body / Footer padding SSOT（Dialog + Popover 共用）

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `accordion.spec.md`
- `agent-panel.spec.md`
- `alert.spec.md`
- `coachmark.spec.md`
- `command.spec.md`
- `dropdown-menu.spec.md`
- `elevation.spec.md`
- `file-viewer.spec.md`
- `motion.spec.md`
- `overlay-chrome-sizing.spec.md`
- `overlay-surface.spec.md`
- `popover.spec.md`
- `scroll-area.spec.md`
- `sheet.spec.md`
- `toast.spec.md`
- `uiSize.spec.md`
