---
component: Avatar
family: self-contained
variants: {}
sizes: {}
traits:
  - hasInteractiveStates
  - isMatrixHeavy
benchmark:
  - MUI Avatar: github.com/mui/material-ui/tree/master/packages/mui-material/src/Avatar
  - Ant Design Avatar: github.com/ant-design/ant-design/tree/master/components/avatar
  - Polaris Avatar: github.com/Shopify/polaris/tree/main/polaris-react/src/components/Avatar
---


# Avatar 設計原則

## 定位

Avatar 是視覺身份標識——代表一個人、一個實體（專案、組織、App）。不是裝飾。

**Layout Family**：非上述 family — self-contained primitive（獨立視覺，無 slot 結構）。

**實作基礎**：純視覺 atom——img + 文字 fallback 組合，無 external primitive base。Radix 有 Avatar primitive 但只提供 fallback 邏輯，本 DS 直接用 native `<img>` + CSS + 錯誤處理已足夠，避免多一層依賴。

---

## 何時用

- **人員識別**：留言者頭像、指派者、作者、團隊成員列表
- **組織 / 專案識別**：workspace logo、專案 icon、app 身份
- **列表項目的主視覺 prefix**：通訊錄、成員管理、chat room 列表
- **hover 顯示完整人員卡**：與 HoverCard 搭配呈現 ProfileCard content

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| 抽象概念 icon（設定、通知、搜尋）| Lucide Icon | Avatar 代表實體身份，icon 代表動作 / 概念 |
| 純文字的 name chip（「Ada Chen」單獨顯示）| `Tag` / 純文字 | Avatar 是視覺 + fallback 文字，純文字 label 用 Tag |
| 人員資訊卡（name + title + actions）| `ProfileCard`（內部含 Avatar）| ProfileCard 是組合元件，Avatar 是其中的身份 prefix |
| 通知計數指示 | `Badge`（可疊加在 Avatar 右上）| Avatar 承載身份，Badge 承載計數 |

---

## Avatar HoverCard 原則(DS-wide canonical,必遵守)

**任何 person avatar,hover 必出現 ProfileCard(HoverCard)。預設行為,不 opt-in**。

**消費者實作 canonical**:
```tsx
<Avatar
  size={40}
  src={person.photoUrl}
  alt={person.name}
  hoverCard={
    <ProfileCard
      name={person.name}
      avatar={{ src: person.photoUrl, alt: person.name }}
      subtitle={`${person.role}｜${person.employeeId}`}
      actions={<ProfileCardDefaultActions />}
      // ↓ hover context 必含 View more:hover 只顯示精簡資料,user 需要 escape hatch 到完整 profile 頁
      onViewMore={() => navigate(`/people/${person.id}`)}
    />
  }
/>
```

**`onViewMore` 為 hover context 必含**(2026-04-23 canonical):
hover ProfileCard 是 preview,所有 preview 必提供「看完整資料」的路徑。
缺 `onViewMore` 使用者點不到完整 profile → hover 成單向死路。詳 `../ProfileCard/profile-card.spec.md`「View more」canonical；該 action 是從 preview 進入完整資料的必要路徑。

**適用範圍(ALL person avatars,無例外)**:PeoplePicker tag / table cell 頭像 / sidebar user / comment author / avatar 堆疊 / Dialog·Sheet member list / FileItem rich author / Menu·Dropdown assignee·owner / chat·thread·notification 頭像。

**世界級對照**(hover → profile 是 default,不是 opt-in):Slack / Figma / Linear / Notion / GitHub —— hover person avatar(或 username)→ profile popover / user card,全部 default 行為。

**例外(ProfileCard 不適用,但 hoverCard 通用行為仍可用)**:
- Entity avatar(專案 / 組織 logo / app icon)— 不代表人員,**不自動套 ProfileCard**(ProfileCard 是人專用內容模板:64px 圓形 + presence 狀態 + Chat/通話 動作,實體沒有)。但 `hoverCard` prop 本身是**通用行為**(型別 `React.ReactNode`,avatar.tsx `AvatarProps.hoverCard`),entity / square avatar **仍可配 hoverCard 顯示其他內容**(如實體資訊卡);此時 focus ring 自動跟隨 square 形狀(rounded-md)。未來若需實體資訊卡,做成**平行的內容元件**(對齊 Atlassian `ProfileCard` / `TeamProfileCard` 分離 + GitHub `data-hovercard-type` 各 type 獨立內容),**不泛化 ProfileCard**。
- Bot / automated account avatar(Atlas / Octocat 等)— 本 DS 後續視需求決

**為什麼必 default**:Person avatar 單獨無 context(只有照片 + 首字),user 不知是誰;opt-in 模式會讓一半 consumer 忘記加,DS 品質不可控。**違規檢測(M10 proactive scan)**:`grep '<Avatar.*alt=\{'` 全 src,檢查 person name(非 entity)alt 且沒 `hoverCard` prop 者;目前無專用 hook,靠 grep 掃描。

**Keyboard 可達 canonical(2026-04-22 D4 UX audit 補齊)**:
當 Avatar 有 `hoverCard` prop,Avatar wrapper **必 keyboard focusable**,讓 keyboard-only user 也能 reach ProfileCard popover。Avatar 元件內部自動套:
- `tabIndex=0`(可 Tab 到;focus 時 Radix hover-card 自動開卡)
- `role="img"` + `aria-label`(取 `alt`)——2026-07-07 CI axe 補修:aria-label 掛在無 role 的 generic `<div>` 是 ARIA 禁用組合(axe `aria-prohibited-attr`,serious);Avatar 語義本質 = 身份圖像,`role="img"` 讓命名合法、子孫自動 presentational、不對 AT 承諾任何互動行為
- 全域 `:focus-visible` 外描邊(`outline: 2px solid var(--ring)`,往外 2px;元件不寫任何 focus class,wrapper 只依 `shape` 帶 `rounded-full` / `rounded-md` 讓外描邊圓角跟隨形狀)(keyboard focus 視覺 indicator)
- **不掛 `role="button"` / `aria-haspopup`**(2026-07-06 user 拍板拆除):原本宣告了卻無 Enter/Space 行為、無 `aria-expanded` = 對 AT 的空承諾(D4 finding);對齊 Radix hover-card 官方(刻意零 popup ARIA,定位 sighted-user 輔助)+ GitHub hovercard(trigger 無 popup ARIA)
- 若無 `hoverCard` → 純展示 `<div>` 不 focusable(避免 tabTrap 噪音)

Rationale:Radix `HoverCardTrigger asChild` 不自動加 tabIndex 給 non-focusable child。若 Avatar wrapper 是 `<div>` 沒 tabIndex,keyboard user 無法 reach ProfileCard content,違反 WCAG 2.1.1(Keyboard)。此 canonical 確保 DS-wide「person avatar → ProfileCard」keyboard 可達,且 ARIA 只宣告真的有的行為。

**Status dot a11y(2026-04-22 D4 UX audit 調整)**:Avatar status dot 內部 span 從原 `role="status"` + `aria-label="presence: online"` 改為 `aria-hidden`。Rationale:`role="status"` 是 live region,多 Avatars(member list / mention picker)會造成 SR 洪水噪音;presence 資訊應整合進 parent avatar 的 `aria-label`(world-class Slack / Teams / Discord 共通)— consumer 傳 `alt` 時自帶語意(e.g. `alt="Alan Chen (online)"`)。

### 溢出人員列表（+N）

Avatar 堆疊的「+N」hover 也出 **HoverCard**（不是 Tooltip）——列表內 person tag 需要 dismiss 互動、每個 person tag hover 需再出 name card（嵌套 HoverCard），Tooltip 非互動不支援。架構：`+N → HoverCard（人員列表）→ 每個人名 → HoverCard（name card）`。`+N` 在堆疊裡的位置與畫法見下方「頭像堆疊(疊在一起時)」段。

### 純文字截斷 vs 人員頭像

| 被截斷的內容 | Hover 顯示 | 元件 |
|---|---|---|
| 人員頭像 | name card（完整資訊 + 操作） | HoverCard |
| 純文字（檔名、標題） | 完整文字 | Tooltip |

---

## 三種內容模式

按優先順序：

| 模式 | 觸發條件 | 內容 | 用途 |
|---|---|---|---|
| **Image** | 有 `src` | 圖片填滿 | 照片、上傳頭像 |
| **Icon** | 有 `icon` 或 src 載入失敗且無 alt | LucideIcon 在底色背景 | 類別標識、預設頭像 |
| **Text** | 有 `alt` 且無 src/icon | 首字大寫 | 無照片時的 fallback |

---

## 尺寸

`size` 接受 **數字（px）** 或字串 **`'fill'`**。**不提供預設尺寸名稱**——尺寸由消費元件（item-layout 系統）決定。

### 兩種模式

| `size` 值 | 行為 | 何時用 |
|----------|------|------|
| `number`（預設 32） | Avatar 寫死為固定 px 尺寸 | 獨立使用、需要明確尺寸時 |
| `'fill'` | Avatar 填滿父容器（`width:100% height:100%`），icon 用 60% 寬高、文字用 `50cqi`（container query inline-size） | 父容器（如 MenuItem 的 prefix slot）已決定尺寸時 |

**外框 = 可見圓（`size` 為 `number` 時的硬契約）**：Avatar 最外層節點的寬高必須等於 `size` 指定的可見尺寸，不得被父容器沿交叉軸拉伸（`size='fill'` 是唯一例外，它的語意就是填滿父容器）。三件事全部以這個外框為基準，所以外框一被撐大就同時壞三處：狀態圓點與 `badgeCount`（相對外框絕對定位）、`:focus-visible` 焦點框（畫在外框的 border box 上，外框帶 `rounded-full`，被撐寬會變成膠囊）、以及 `hoverCard` 的浮層錨點（Radix 以外框量位置，外框變寬浮層就橫向偏移）。**只寫 `shrink-0` 不足**：它只擋主軸收縮，擋不住交叉軸拉伸（直向 flex 會拉寬，grid 格子由 `justify-self` 管、`align-self` 也碰不到），所以固定尺寸模式必須另外鎖寬。機械閘 `scripts/avatar-anchor-box-invariant.mjs`：每個 hover-card trigger 的 Avatar，外框 box 與內層 `[data-avatar-size]` box 的差需 ≤ 0.5px。

**為什麼有 `'fill'` 模式**：當 Avatar 放在 item-layout 的 prefix slot，prefix 的尺寸由消費元件（MenuItem、ListItem 等）依照 size variant 決定。Avatar 不該知道也不該寫死自己的尺寸——應該被動填滿父容器。`'fill'` 模式透過 CSS container query 讓內部 icon/text 自動隨父容器縮放。

### 內部元素比例

不論哪個模式，內部 icon 和 text 都按相同比例：

| 元素 | 公式 | 範例（size=32） |
|---|---|---|
| Icon | `round_even(size × 0.6)`（fill 模式用 `width:60% height:60%`） | 20px |
| Text fallback 字體 | `round(size × 0.5)`（fill 模式用 `font-size:50cqi`） | 16px |

- Icon 60%：業界標準（Material Design、Apple HIG）
- Text 50%：讓 initials 與圓形留出一致內距，且自動對齊本 DS 字體 scale（10→12→16→20px）

### 常用尺寸參考

由 item-layout 消費元件決定：

| 場景 | Avatar 用法 |
|---|---|
| Menu item / List item inside prefix slot | `<Avatar size="fill" />`（讓父 prefix 控制尺寸） |
| 獨立使用（獨立頁面 hero / profile header 的大 avatar） | `<Avatar size={40} />`（顯式指定 px） |

> **勿混**：上表「page header 40px」指**獨立頁面 hero / profile header** 的大 avatar。**App chrome / global header 內的 avatar（品牌 + 帳號入口）≠ 此處**——走 `../../patterns/header-canonical/header-canonical.spec.md` 4.5 = **24px density-fixed**（chrome header avatar canonical），兩者 scope 不同。

---

## 圓 vs 方的語意判斷

| Shape | 用途 |
|---|---|
| `circle`（預設） | 人物（照片、姓名） |
| `square` | 實體（專案、組織、App、品牌） |

**判斷標準：「這個 avatar 代表一個人，還是一個東西？」** 圓角由 `.tsx` inline style 決定（無 cva），消費 radius token：`circle` = `var(--radius-full)`、`square` = `var(--radius-md)`（avatar.tsx `radius` ternary；不硬寫裸值，token 調整時自動跟隨）。

---

## 背景色

Icon 和 Text 模式使用 primitive step-1 subtle 背景 + 對應 step-7 前景色。`solid` boolean prop 可切換為 step-6 全色背景 + on-emphasis 配對前景(yellow / amber / orange / lime 深字,詳「Solid」段)。

與 Tag 元件完全對齊——**消費同一組 categorical 色相 SSOT**（`tokens/categorical-color.ts`），所有有色 variant 直接使用 primitive token（`--color-{hue}-*`），不使用 semantic token（`--primary`、`--error`）。色名即色相 1:1 對 color token（零 offset）。Avatar 的「blue」代表藍色本身，不代表「主要操作」語義。neutral 用 `foreground`，有色用 primitive step-7（`--color-{hue}-7`）優先辨識度。

**注意**：`red` variant = `--color-red-*`（品牌紅家族 hue 25），**與語意 `--error`（= `--color-deep-orange-6`，hue 38）無關**。2026-06-04 修正原「red variant 接 deep-orange」offset。12 色相與 Tag / Calendar event 完全一致。

### Subtle（預設，`solid=false`）

**通則**:12 色相一律 `--color-{hue}-1` subtle 背景 + `--color-{hue}-7` 前景（1:1 零 offset,無 per-hue 特例）。**neutral 例外**（非色相）:`--muted` 背景 + `--foreground` 前景。逐色 mapping 的 implementation SSOT = `tokens/categorical-color.ts`。

### Solid（`solid=true`）

**通則**:12 色相一律 `--color-{hue}-6` 全色背景;**neutral 例外**:`--color-neutral-9` 背景 + `--inverse-fg` 前景。前景依底色明暗分桶（見下）。

**Solid 文字色規則（on-emphasis 配對,2026-06-04,與 Tag 共用 SSOT）**：依 step-6 底色明暗分桶,合規門檻 = WCAG **large/bold 3:1**（user 拍板「以最低為原則」）。底夠深 → `--on-emphasis`（白）；底太亮 → `--on-emphasis-dark`（深,= `black-a85`,原 `warning-foreground` 改名）:**yellow / amber / orange / lime** 四色用深字,其餘用白。**★ green 例外**:white 實測 2.47 連 3:1 都不過,但維持白字（慣見「綠底白字」觀感）= documented exception。對比由 `categorical-color-invariants.mjs` I4 機械驗(green exempt);逐色 mapping SSOT = `tokens/categorical-color.ts`。

Image 模式不顯示背景色（圖片填滿），`solid` prop 無效果。

---

## Disabled

Avatar 包在 disabled Field wrapper context 內時，會經 `useResolvedFieldDisabled()`（讀 `fieldCtx.disabled`，**涵蓋 `<Field disabled>` 與 `<Field mode="disabled">` 兩者**）**自己**套 `opacity-disabled`（= `var(--opacity-disabled)`，0.45）self-dim（取代既有 wrapper blanket opacity-disabled 逃生艙，2026-05-13 R3.5；**2026-06-08 trigger 由「只認 `mode==='disabled'`」改為 `fieldCtx.disabled`，與其他 field 控件的 disabled cascade 統一**——`<Field disabled>` 內 PeoplePicker 人名變灰時 avatar 同步變淡，視覺一致）；沒包在 Field wrapper 內的 standalone Avatar（ProfileCard / FileItem / HoverCard / Dialog 等 display 場景）維持原樣不變（`fieldCtx=null` → 不觸發）。Avatar 不提供自身 `disabled` prop。詳見 `color.spec.md` 的 Disabled 狀態。

---

## Overlay:Status dot + Count badge(可並存,不同角)

Avatar 支援兩個 overlay API(`status` 右下 presence / `badgeCount` 右上 count),**可同時並存** — 兩者是不同角、不同語義的 slot,對齊 `badge.spec.md`「Avatar 可疊 status + count」canonical + Slack / Teams / iMessage / LINE 標配。

> **2026-06-01 修正**:原「擇一不並存」(AR22)決策與 `badge.spec.md`(明文「Avatar 可疊兩個 badge」)+ `avatar.tsx`(兩個 prop 各自獨立 render,從未 type-level 互斥)三方衝突。經 M26 source-verified benchmark(Slack / MS Teams / iMessage 標配 presence dot + count badge 並存)+ user 拍板,統一為「**可並存(視覺照舊,code 不變)**」。

**為什麼可並存(且不同角)**:presence(右下,跟著臉看)是「這個人的線上狀態」,count(右上,視覺掃描 inbox 的自然落點)是「此對話的未讀量」——語義不同、不同角。**signal crowding** 原則真正禁止的是「**同一角疊兩個同類 indicator**」(如右上同時塞 count + dot),不是「不同角、不同語義」的兩個訊號。世界級 chat app(Slack / Teams / Discord / iMessage)標配兩者並存、把兩者分開不疊在同一角。

| Overlay | Prop | 元件本體 | 位置 | 語義 | 世界級對照 |
|---------|------|---------|------|------|-----------|
| Status dot(presence)| `status="online"/"away"/"busy"/"offline"` | **Avatar 內部 `span`**(非 Badge) | **右下角**(circle avatar 圓周 45°) | 此人現在線上狀態 | Slack / Teams / Discord |
| Count badge(通知)| `badgeCount={N}` | **`<Badge variant="critical">`**(此 anchor 唯一 Badge) | **右上角** | 此對話 / 此使用者有 N 條新事件 | iMessage / Slack thread / LINE / WhatsApp |

**為什麼 status 做 Avatar 內部 span 而不是 `<Badge dot>`**:兩者語義完全不同——presence 是「這個人的狀態」,Badge 是「計數 / 通知緊急度」。若用 Badge 承載 presence,color token 會混用(Badge 有 low/medium/high/critical 對應緊急度,presence 有 online/busy/away/offline 對應狀態;強行映射會失真);brand 也無法獨立調 presence 色而不動 Badge 色。世界級 Slack / Teams / Discord 同樣把 presence dot 做成 avatar 自有 primitive,不走 badge 系統。

### Status dot 尺寸與比例

- `dotSize = clamp(8, round(avatarSize × 0.28), 16)` — 28% 是 Slack / Teams 世界級平均
- Floor 8:小 avatar(24-28px)下可辨識但不喧賓奪主(若 floor 10 → 24px avatar 的 dot 占 42% 太大)
- Ceiling 16:64px+ 的大 avatar 不讓 dot 過度放大,保持「輔助指示器」視覺權重
- 與頭像之間的縫:**從圓上挖出來**(2026-09-26 起;此前是圓點外畫一圈 `box-shadow`、顏色寫死 `--surface-raised`),寬 = DS 通用縫 `--stack-gap`(2px),dotSize ≥ 12 時多 1px 保持視覺比例。露出的是真正在後面的東西,所以頭像放在深色頁面(#0A0A0A)、半透明卡片、滑過的列上都不會出現一圈錯色的灰邊 —— 舊做法在深色頁面上實測就是一圈 #1F1F1F(待辦總帳 N49;步驟條外圈同一種病、同日改)。挖法與「頭像堆疊」段相同(遮罩挖空,不是外圈);圓點本身不再畫任何圈

### Status 顏色 token(presence namespace)

走 semantic token `--status-online / --status-busy / --status-away / --status-offline`,**不直接用 success / error / warning**。理由:presence 跟「操作成功 / 錯誤 / 警告」是不同語境,token 獨立讓 brand 可以只調整 presence 色(例:把 online 改霓虹綠)不動到 success。

### Count badge 實作

Avatar `badgeCount` 內部消費 DS `<Badge variant="critical" max={99}>`,加上 `-top-1 -right-1` 偏移;與頭像之間的縫(`--stack-gap`,2px)同樣**從圓上挖出來**(膠囊形的洞:徽章寬度隨字數變,由 ResizeObserver 量它的盒子再算遮罩;2026-09-26 起,此前是 surface 色 2px `box-shadow` 外圈,深色會錯色,同上段)。`badgeCount <= 0` 不渲染(0 或 undefined 皆空)。

**編輯態人員標籤的移除 ×**(`PeoplePicker` 堆疊模式,`person-display.tsx` AvatarDismissOverlay)也疊在頭像右上,同樣挖空:Avatar `dismissCutout`(`@internal`)在標籤被滑過 / 焦點在標籤內時(與 × 顯示的條件相同)才打開那個洞,平常頭像完整;× 的位置與大小只有一個住所 `AVATAR_DISMISS_OVERLAY_PX`。

**為什麼預設 `critical`(紅)**:計數 on avatar 在世界級 chat app 的慣例就是「待處理未讀」,紅色是約定俗成的 attention 色;需要其他 variant 的少見情境,consumer 自己 compose `<Avatar>` + `<Badge>` top-right 手刻(不開 prop 避免多選擇認知負擔)。

---

## 頭像堆疊(疊在一起時)

多位人員並排、互相疊一小段的畫法 —— PeoplePicker 多人 stack(檢視 / 唯讀 / 表格格子 / 編輯)、表格多人欄、任何「前幾位 + `+N`」的頭像列。規則住本段;機制住 `avatar.tsx`「頭像堆疊」段(`stacked` prop 與 `AVATAR_STACK_*` 匯出),三處消費者(`MultiPersonDisplay`、`PersonAvatarTag`、OverflowIndicator 的 circle 形狀)都用同一份。

| 項目 | 規則 |
|---|---|
| 順序 | 第一顆在最上面,依序往下;`+N`(OverflowIndicator `shape="circle"`)是最後一項,在最下面。每項同尺寸 |
| 重疊 | 第 2 項起往左疊 2px(`AVATAR_STACK_OVERLAP_PX`) |
| 分開方式 | **挖空**:後面那顆被前面那顆蓋住的地方,連同外面 2px 的縫(`AVATAR_STACK_GAP_PX`),整片從畫面上拿掉。縫裡露出的是真正在後面的東西(畫布、唯讀欄位、滑過的表格列、深色欄位)。**不畫外圈** |
| 半透明底色 | 不會疊到別人身上:重疊的地方只剩上面那顆(neutral `--muted` 底、深色主題的彩色淡底、`+N` 的 `--secondary` 底都是半透明,見「背景色」段與 `../OverflowIndicator/overflow-indicator.spec.md`) |
| 鍵盤焦點 | 某一項裡有東西拿到鍵盤焦點時,整項升到最上層 —— 全域外描邊往外畫,左半圈不被上一顆蓋住(`ds-canonical/references/focus-canonical.md` 判準表「疊層/徽章不算鄰居」→ 往外) |
| 名片 | 重疊那 2px 屬於上面那顆(滑過開上面那顆的 ProfileCard);挖空不改變任何一顆的觸發範圍 |

**為什麼挖空、不畫外圈**(2026-09-26 採用,紀錄見待辦總帳 L3 與「其餘建議」條):

- 舊做法(2026-04-02 起)每顆加 2px 外圈、圈色寫死 `--surface`。外圈只擋得住「圈」的那一段,擋不住重疊處:上面那顆的半透明底色直接疊在下面那顆上,透出下面那顆(2026-09-26 AI 實測,重疊處與「把下面那顆藏起來」相比:淺色灰疊灰差 9–10、深色差 17(0–255 通道差);示範 story 的 `+N` 疊在受控單色照片上差 170–215)。
- 圈色寫死 `--surface` 只在白底正確:深色主題 `--surface` 本身是白 8% 半透明,圈變成一道比頭像還亮的月牙;唯讀欄位(`--bg-readonly`)或滑過的表格列上,每顆外面多一圈白邊。
- 挖空與背景色無關,不需要為每種背景另建不透明 token(`tokens/README.md` 建 token 前先質疑是否真需要)。換成不透明底色的做法,2026-09-26 AI 模擬實測在唯讀欄位上灰頭像與欄位同色、在深色比欄位暗。

**縫寬 2px 是 AI 推導**:與舊外圈同寬(白底上看起來與舊版相同),也與 DS 其他「把疊上去的東西分開」的縫同寬(本檔「Status dot 尺寸與比例」、「Count badge 實作」、上傳列的進度條與焦點框、步驟條外圈、全域焦點框往外畫的間隙)—— 這個值 2026-09-26 抽成 token `--stack-gap`(`tokens/uiSize/uiSize.css`;JS 雙生 `tokens/uiSize/stack-gap.ts`,由 `scripts/token-twin-invariant.mjs` 鎖住兩邊相等),本段是它設計理由的住所。Primer 的縫是 1px。

**世界級對照**:

| DS(釘版本) | 疊在一起時怎麼分開 | 一手出處 |
|---|---|---|
| GitHub Primer(@primer/react 38.40.0) | **挖空**:第 2 顆起用遮罩挖掉「前一顆的圓 + 1px」(`mask-composite: exclude` + 圓形 `radial-gradient`);整組 `isolation: isolate` | [AvatarStack.module.css#L168-L194](https://github.com/primer/react/blob/%40primer/react%4038.40.0/packages/react/src/AvatarStack/AvatarStack.module.css#L168-L194)、[#L3](https://github.com/primer/react/blob/%40primer/react%4038.40.0/packages/react/src/AvatarStack/AvatarStack.module.css#L3)「`--avatar-border-width: 1px`」、[#L12](https://github.com/primer/react/blob/%40primer/react%4038.40.0/packages/react/src/AvatarStack/AvatarStack.module.css#L12)「`isolation: isolate`」 |
| MUI(v9.4.0) | 每顆 2px 實線框,框色寫死頁面底色 `palette.background.default` | [AvatarGroup.js#L42](https://github.com/mui/material-ui/blob/v9.4.0/packages/mui-material/src/AvatarGroup/AvatarGroup.js#L42) |
| Fluent 2(@fluentui/react-avatar 9.11.8) | 疊放時每顆加 `box-shadow` 外圈,圈色寫死 `colorNeutralBackground2` | [useAvatarGroupItemStyles.styles.ts#L59-L61](https://github.com/microsoft/fluentui/blob/%40fluentui/react-avatar_v9.11.8/packages/react-components/react-avatar/library/src/components/AvatarGroupItem/useAvatarGroupItemStyles.styles.ts#L59-L61) |
| Ant Design(6.6.5) | 群組內每顆的框色寫死 `groupBorderColor`,第 2 顆起往左疊 | [avatar/style/index.ts#L176-L185](https://github.com/ant-design/ant-design/blob/6.6.5/components/avatar/style/index.ts#L176-L185) |

外圈派(MUI / Fluent / Ant)的圈色都是一個固定的底色 token(出處同列)。**AI 推導**:這與 DS 舊做法同一類,只在那個底色上看起來是縫;本 DS 的欄位有唯讀底、表格有滑過底、深色 `--surface` 半透明,所以選挖空(Primer)。此取捨由 AI 依上述實測整理後提出,採用紀錄同上。

---

## 禁止事項

- ❌ 不要用 Avatar 當裝飾——每個 Avatar 必須代表一個明確的身份
- ❌ 不要手動指定 icon 尺寸——60% 自動計算
- ❌ 不要用 square 給人物——人用 circle，東西用 square
- ❌ 不要省略 `alt`——即使有 `src`，`alt` 是圖片失敗時的 fallback 來源
- ❌ 不要手刻頭像堆疊(負 margin + 外圈 `ring` / `box-shadow` / `border`)——用「頭像堆疊(疊在一起時)」段的共用做法(`stacked` + `AVATAR_STACK_*`)
- ❌ 不要把挖空遮罩掛在接焦點的外層——遮罩外的東西不繪製,會把畫在外面的焦點框整圈裁掉;遮罩只掛在圓那一層
- ❌ 不要在疊在頭像上的東西(狀態圓點 / 計數徽章 / 移除 ×)外面畫一圈底色當縫(`box-shadow` / `ring`)——那一圈只在一種底上是對的,深色頁面上是一道灰邊;縫一律從圓上挖(「Overlay」段與「頭像堆疊」段同一套做法)

---

## A11y 預設

- **`alt` 必傳**:即使有 `src`,`alt` 是 image fallback / SR 訊號雙重來源。Person avatar `alt` 應含 name + presence(例 `"Alan Chen (online)"`),entity avatar 用品牌 / 專案名,純裝飾(極罕見)用空字串 `alt=""`(`aria-hidden`)。
- **無 `alt` 時 fallback**:image 模式自動降級 initials / icon;一律不靜默渲染無 SR 標的元素。
- **Status dot SR 處理**:status dot 內部 span `aria-hidden`(presence 訊號整合進 parent `alt`),避免 `role="status"` live region 在 member list 造成 SR 洪水(詳「Status dot a11y」段)。
- **`badgeCount` 語意**:內部消費 `<Badge variant="critical">`,由 Avatar 傳入 `aria-label="N 則未讀"` 提供計數語義(DS 預設文案 = 中文,consumer 經 `badgeAriaLabel` 換語言;2026-10-20 前是英文 `N unread`)(Badge 本身只有 `role="status"`,不自產 aria-label);`badgeCount <= 0` 不渲染避免空 announce。
- **HoverCard 整合**:Avatar 帶 `hoverCard` prop 時自動 `tabIndex=0` + `role="img"` + `aria-label`(取 `alt`;**與 `badgeCount` 並用時 count 併入同一 aria-label** — `role="img"` 使子孫 presentational、內層 Badge 計數語義被壓平,故外層 label = `${alt}, ${badgeAriaLabel ?? 'N 則未讀'}`(沒給 `alt` 時名字是「查看個人資訊」),對齊 Slack 單一 accessible name 做法,2026-07-14 補修)+ 全域 `:focus-visible` 外描邊(元件不寫任何 focus class),確保 keyboard user 能 Tab 進入觸發 ProfileCard popover;**不掛 `role="button"` / `aria-haspopup`**(2026-07-06 拆除;role="img" 為 2026-07-07 axe 補修,詳「Keyboard 可達 canonical」段)。
- **Image alt 語意**:meaningful image(person photo / brand logo)用實質 `alt`;decorative-only(極少)走 `alt=""`,但 Avatar 本質是身份識別,decorative 用法應改用 Icon 元件。

---

## StateBehavior 範疇

Avatar 是**身份視覺 primitive**(顯示人 / 組織 / 物件的代表視覺),本身無自有的 hover / active / selected 互動 state。但有兩個由 context 委派 / 自管的視覺 state,故 anatomy 仍有 `StateBehavior` story(內容降級 fallback chain + status presence dot 四態):

- **focus-visible**:Avatar 帶 `hoverCard` prop 時 wrapper 變 focusable,委派 keyboard focus 給該 wrapper,焦點框走全域 `:focus-visible` 外描邊(`outline: 2px solid var(--ring)`,往外 2px;wrapper 不寫任何 focus class)(見「Keyboard 可達 canonical」段);無 `hoverCard` 則純展示不 focusable。
- **disabled**:Avatar 在 disabled Field wrapper context 內經 `fieldCtx` 自套 `opacity-disabled` self-dim(見「Disabled」段),非互動 state 而是視覺 context state。
- hover 行為(彈 ProfileCard)由 `hoverCard` prop 委託給 HoverCard primitive,屬 HoverCard 的 state 不屬 Avatar。

對應 anatomy story:`Overview` + `Inspector` + `ColorMatrix` + `SizeMatrix` + `StateBehavior` + `Accessibility`。

---

## 空值 / 驗證 / 邊界

非互動 primitive,無 loading / error state;各邊界已散見對應段,此處收斂索引:

- **`src` null / 圖片載入失敗**:自動降級 Icon / Text fallback chain(見「三種內容模式」)。
- **`alt` 缺失**:fallback 與 SR 行為見「A11y 預設」(alt 必傳 canonical)。
- **`size="fill"` 無確定尺寸的父容器**:fill 以父容器尺寸為準,僅用於「父已決定尺寸」的 slot(見「兩種模式」表);父無確定尺寸時改用顯式 `size={px}`。
- **Disabled context**:見「Disabled」段(fieldCtx self-dim)。

## 相關

- `../HoverCard/hover-card.spec.md` — `hoverCard` prop 的浮層容器(觸發與定位由 HoverCard 負責)
- `../ProfileCard/profile-card.spec.md` — person avatar hover 必出的人員資訊卡內容
- `../Badge/badge.spec.md` — `badgeCount` 內部消費的 count badge(右上角 overlay)
- `../Tag/tag.spec.md` — categorical 色相 SSOT 共用(`tokens/categorical-color.ts`,12 色相 1:1)

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `account-menu.spec.md`
- `badge.spec.md`
- `file-item.spec.md`
- `hover-card.spec.md`
- `menu-item.spec.md`
- `motion.spec.md`
- `overflow-indicator.spec.md`
- `people-picker.spec.md`
- `profile-card.spec.md`
- `uiSize.spec.md`
