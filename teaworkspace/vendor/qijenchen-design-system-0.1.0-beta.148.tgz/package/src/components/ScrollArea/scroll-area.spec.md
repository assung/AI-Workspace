---
component: ScrollArea
family: self-contained
variants: {}
sizes: {}
traits: []  # Radix wrapper 捲軸 primitive,無 trait variants(R3 trait enforce 無適用項;2026-07-04 dim 29 補宣告)
benchmark:
  - Radix ScrollArea primitive: github.com/radix-ui/primitives/tree/main/packages/react/scroll-area
---

# ScrollArea 設計原則

ScrollArea 是**跨 OS 視覺一致的自訂捲動容器**——用 overlay 捲軸取代原生 scrollbar,解決 macOS / Windows / Linux 之間的跑版落差。

**Layout Family**:非上述 family — self-contained primitive(純捲動容器,無 slot 結構)。

**實作基礎**:基於 Radix ScrollArea primitive(shadcn passthrough 結構)——由 Radix 處理 viewport / scrollbar / thumb 的 pointer 拖曳與 overflow-detection,本 DS 橋接 token(scrollbar 寬度、thumb bg、hover 反饋)與 a11y 行為(Viewport `tabIndex={0}` 預設 + `viewportTabIndex={-1}` 雙 tab-stop opt-out + `viewportTabIndex={null}` ARIA composite wrapper opt-out + DS focus ring;Radix 不處理 keyboard,亦不自動標 Viewport focusable)。

**實作取向**:本元件包裝既有 scroll-area primitive，目的是統一跨 OS 的捲軸視覺，並避免 DataTable / Sheet / Dialog 在 always-visible scrollbar 環境中被吃掉內容寬度。

---

## 為什麼需要 ScrollArea

Native scrollbar 跨 OS 不一致:

| OS | 行為 |
|----|------|
| macOS | Overlay——不吃寬度,預設隱藏,捲動時浮出 |
| Windows / Linux | Always-visible——永遠吃 ~15–17px 寬度 |

**結果**:同一個 DataTable 橫向捲動、Sheet / Dialog 內容垂直捲動在 macOS 視覺對齊,在 Windows 右側被 scrollbar 吃 17px 跑版。「Left pinned + Row Actions」的 DataTable 截圖即是此類已觀察的跨 OS bug。

ScrollArea 用 Radix 自訂 overlay 捲軸 → **跨 OS 一致、不吃寬度、捲動時浮出(hover / scroll 自動顯示)**。

---

## 何時用

- **寬內容橫向捲動**——內容寬於容器的一般場景(寬表格類 demo、程式碼區塊等)。**例外:DataTable 中央捲動區不用 ScrollArea**——走 native `overflow-x-auto` + JS scrollLeft 同步(pinned column 結構需求,理由與 post-v1 重構計畫見 `data-table.spec.md`「捲軸 canonical」節;2026-06-12 收斂跨 spec 張力,以已實作且有 rationale 的 DataTable 側為準)。**~~例外二:Pagination 最後一階~~**(2026-09-10 撤銷):分頁列**不再有任何捲動** —— 最後一階改成砍頭尾頁碼(156px,低於 DS 最窄容器),`overflow-x-auto` 整條拿掉。查證支持:16 家世界級掃過約 20 個分頁原始檔,沒有一家讓數字頁碼列橫向捲(唯一命中的 `TablePagination.js:29` 是表格頁尾工具列)。理由與數字見 `pagination.spec.md`「為什麼不捲」
- **Sheet / Dialog body 垂直捲動**——內容可能超出容器高度
- **Sidebar nav 長列表**——導覽項目多於可見高度
- **任何「內容可能溢出容器」且「跨 OS 視覺必須一致」的 sub-region**

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| 全頁捲動 | 瀏覽器 document scroll(native) | ScrollArea 是 sub-region 元件,document 層級保持 native 更符合 OS 慣例 |
| 單行 truncate | `text-overflow: ellipsis` | 不需要實際捲動,純截斷視覺處理 |
| 極短內容 | 不包任何 wrapper | 內容不會溢出 → ScrollArea 是視覺噪音 |
| 固定高度但內容永遠不溢出的容器 | 一般 `<div>` | ScrollArea 額外 overhead 無收益 |

## 近親元件分界

| vs | 差異軸 | 何時用 ScrollArea |
|---|---|---|
| **OverflowIndicator** | OverflowIndicator 是 horizontal 元素 list 的 hidden-count badge;ScrollArea 是 cross-OS scrollbar 視覺一致化 | 跨 OS 視覺一致 scrollbar(Windows 醜原生 vs macOS overlay)|
| **Document native scroll** | Native scroll 用 OS scrollbar;ScrollArea 用 Radix overlay scrollbar | sub-region container,非全頁 |
| **AspectRatio** | AspectRatio 鎖比例不 scroll;ScrollArea 允許溢出 scroll | 內容可能 overflow 容器需 scroll |

本 DS 只在有明確邊界的 sub-region 使用 ScrollArea，document 級捲動保留 native，避免破壞瀏覽器的頁面捲動語意與恢復位置。

---

## Orientation

- **`vertical`**(預設)——垂直捲動(長清單、Sheet body)
- **`horizontal`**——水平捲動(寬表格、Tag 溢出列)
- **同時垂直 + 水平**——大型 DataTable 雙向(wrapper `<ScrollArea>` 已內建一個 vertical `<ScrollBar>`,consumer 只需再渲染一個 `<ScrollBar orientation="horizontal">`)

## 視覺 token

| 元素 | Token | 值 |
|------|-------|----|
| Scrollbar 寬度 | 固定 10px(`w-2.5` / `h-2.5`;ScrollArea 自繪的 Radix 拇指) | 跨 size 不變——scrollbar 是功能性元件,不隨內容尺寸變化。**不含 DataTable**(原生捲軸,見下段) |
| Thumb 邊緣 inset | 1px(實作細節見 `.tsx`) | thumb 與容器邊緣保留 1px 視覺 inset,不貼死邊界 |
| Track | 透明(無 bg) | overlay 浮層,不搶視覺 |
| Thumb bg | `--scrollbar-thumb` → hover `--scrollbar-thumb-hover`(semantic alias,resolves to `--border` / `--border-hover` = neutral-5/-6) | 靜態時低存在感,hover 加深反饋可抓握。2026-05-09 抽 SSOT alias,與 DataTable **原生**捲軸的 `scrollbar-color` 共享同一組顏色 token(DataTable 沒有自繪 / fake scrollbar —— 原句「fake scrollbar」2026-09-05 更正),避免 thumb 視覺未來演化時誤動 Field/Input/Checkbox border |
| Thumb radius | `rounded-full` | 圓形 thumb 在垂直／水平方向都保持同一端點幾何 |
| 過渡 | `transition-colors` | 色彩變化平滑,不做尺寸動畫 |

**Scrollbar 寬度固定 10px 不隨 size 變**:不同 size 的元件(sm/md/lg Button 等 ScrollArea 消費者)都消費同一個 10px scrollbar;scrollbar 是「捲動機制」不是「內容尺寸」,不需要對齊 content 字級。

**DataTable 不在這個 10px 之內**(2026-09-05 更正,原寫「DataTable 都消費同一個 10px」;2026-09-11 再更正 Chromium 的值):它不用 ScrollArea,走**原生捲軸**。`data-table.css` 先宣告 `scrollbar-width: thin` + `scrollbar-color`,再用 `@supports selector(::-webkit-scrollbar)` 把這兩條在 Chromium 上重設回 `auto`(2026-09-08 撤回 0374642a 時恢復 main 既有設定)—— 所以 **Chrome / Edge 吃的是瀏覽器預設寬度**(macOS classic 15px、Windows 17px、overlay 模式 0),**只有 Firefox 拿到 `thin` 與自訂色**。實際寬度不寫死在任何地方,由 `measureScrollbarGutters` 每次量。與 ScrollArea **只共用顏色 token** `--scrollbar-thumb` / `--scrollbar-track`;thumb 寬度與 radius 在 Chromium 皆不可控。不用 `::-webkit-scrollbar` 湊成 10px 的理由見 `data-table.spec.md` 缺陷表 H(裸 `::-webkit-scrollbar` 會把 overlay 捲軸強制變成佔版面的 classic 捲軸)。

---

## 禁止事項

- ❌ **不用於全頁捲動**——document scroll 保持 native,ScrollArea 是 sub-region 工具。強行包整頁會遮掉瀏覽器 reader mode / native pull-to-refresh 等 OS 能力
- ❌ **不用於單行 truncate**——`text-overflow: ellipsis` 就夠,用 ScrollArea 等於讓使用者水平捲動看一行字,UX 扭曲
- ❌ **不巢狀 ScrollArea**——使用者捲動時分不清是哪個 scope 捲動(外層還是內層?),焦點管理混亂。需要巢狀結構時重新設計 layout(如拆成 Tabs / Accordion)
- ❌ **不在 Viewport 直接設 overflow**——Radix 已在 Viewport 內部處理 overflow 機制,手動設會破壞 primitive(scrollbar 偵測失效 / thumb 位置錯亂)
- ❌ **不用於極短內容**——內容不會溢出就不需要 wrapper,多包一層是視覺噪音 + DOM 浪費

---

## A11y 預設

Radix primitive + 本 DS a11y 橋接:

- **鍵盤捲動**:本 DS 在 Viewport 加 `tabIndex={0}`(預設)使其可被鍵盤聚焦(Radix 不自動把 scroll container 標 focusable,Safari 尤其需要;此即 axe `scrollable-region-focusable` fix)。聚焦後 `ArrowUp/Down/Left/Right` / `PageUp/Down` / `Home/End` 捲動為瀏覽器原生行為,非 Radix 提供。**`viewportTabIndex={-1}` opt-out(2026-07-14)**:內容已有自帶 focusable + 鍵盤處理的元素(如 TimePicker `role="listbox"` `tabIndex={0}`)時傳 `-1`,消除「Viewport+內容雙 tab stop、焦點落 Viewport 時方向鍵觸發原生捲動非元件行為」;axe 由內部 focusable 內容滿足。**`viewportTabIndex={null}` composite opt-out(2026-07-31)**:ScrollArea 被 `role="menu"` 等 ARIA composite 當純結構 wrapper、鍵盤與 focus 由其 item family own 時,完全省略 viewport `tabindex`;`-1` 仍會留下 `div[tabindex]`,不能滿足 composite 的 required-children 結構
- **Focus 可見**:聚焦的 Viewport 顯示 DS 焦點框(`focus-visible:focus-ring-inset`,往內 2px),非瀏覽器原生 focus ring(2026-09-24 訂正,原 `focus-visible:outline-ring` 是已退役的手寫 outline 寫法,`scroll-area.tsx:69` 實為 `focus-ring-inset`)
- **Scrollbar 非 tab stop**:scrollbar thumb 不搶焦點,使用鍵盤的使用者透過 viewport 捲動(Radix 內建)
- **Pointer 支援**:thumb 可拖曳,track 可 click-to-jump(Radix 內建)

本元件已內建 `tabIndex`(預設 0;`viewportTabIndex={-1}` / `{null}` 依上述兩種 owner 情境 opt-out)+ focus ring(滿足 axe `scrollable-region-focusable`)。但 Viewport 預設**無 `role` / accessible name**——**若 scroll 區域有具體語意(如「留言列表」「程式碼區塊」),consumer 應提供 `aria-label`**,否則 SR 只報「可捲動區域」無內容描述;純視覺裝飾容器可省略。(2026-05-31 #31:修正原「consumer 無需額外處理 a11y」過度宣稱)

---

## 邊界案例

- **Dark mode**:`--scrollbar-thumb` / `--scrollbar-thumb-hover`(resolves to `--border` / `--border-hover`)自動由 semantic token 切換,無自訂 palette,詳見 `color.spec.md`
- **但 DataTable 的原生捲軸不吃這組 token(2026-09-12 釐清)**:`data-table.css` 在 Chromium 上把
  `scrollbar-color` 重設回 `auto`,所以 Chrome / Edge 的捲軸配色**完全由 `color-scheme` 決定**。
  DS 原本從沒宣告過 `color-scheme`(計算值 `normal`)→ dark mode 下瀏覽器照樣畫亮色捲軸
  (user 2026-09-12 截圖)。現在 `tokens/color/semantic.css` 在 `:root, [data-theme]` 宣告 `color-scheme: light`、
  在 `[data-theme="dark"]` 宣告 `color-scheme: dark`,巢狀 theme 邊界一併翻。
  機械閘 `scripts/color-scheme-invariant.mjs`(C1 計算值 = theme / C1b 巢狀邊界 / C2 用原生控制項當觀測器
  確認**瀏覽器真的照做**,不只驗宣告存在)。
- **Density**:scrollbar 寬度不受 density 影響(功能性 primitive,不隨 field-height / layout-space 放大縮小)
- **Disabled**:ScrollArea 無互動狀態——內容是否可操作由 consumer 決定,captured 容器本身不 disable
- **Empty**:內容為空時 scrollbar 不顯示(Radix 自動偵測 overflow,無溢出 → scrollbar 隱藏)
- **Loading**:ScrollArea 只提供捲動能力，不擁有內容 loading；Skeleton / CircularProgress 由 consumer 放在 viewport 內容內。

---

## 為何無 StateBehavior

ScrollArea 是**捲動容器 primitive**,本身**無互動狀態**(見「邊界案例」段:無 disabled,內容捲動由瀏覽器原生處理)。唯一的 state 是「scrollbar visible / hidden」,但這由 Radix 依 overflow 自動偵測,非 consumer 或元件 prop 可控。重寫 StateBehavior 會讓 consumer 誤以為有 hover / focus / disabled prop 可切。orientation(水平 / 垂直 / 雙向)的結構變化由元件特有 `OrientationBehavior` own。

對應 anatomy story:保留 `Overview` + `Inspector` + `ColorMatrix`(scrollbar track / thumb 色) + `SizeMatrix` + `Accessibility` + 元件特有 `OrientationBehavior`。

---

## Radix Viewport `display:table` 陷阱 + `fillX`(2026-07-08 WM 戰役 codify)

Radix Viewport 內建 wrapper `min-width:100%; display:table`——這是**水平捲動的 min-content 溢出機制**,但對「垂直捲動容器內的多欄 flex 佈局」是陷阱:內容以 max-content 佈局突破 100% 寬(WM 兩欄 dialog 右欄被裁 33px 實證)。垂直捲動場景 opt-in `fillX` prop 中和為 block/w-full;**水平捲動勿開**。DialogBody 已預設開啟。

## 相關

- `../DataTable/data-table.spec.md` — 歷史動機來源(橫向捲動跑版問題),**非 consumer**:DataTable 中央捲動區走 native `overflow-x-auto`(0 import,見上方「何時用」例外 +「捲軸 canonical」節)
- `../Sheet/sheet.spec.md` — body 捲動
- `../Dialog/dialog.spec.md` — body 捲動
- `../Sidebar/sidebar.spec.md` — nav 長列表捲動
- `../Separator/separator.spec.md` — 分隔線規則(ScrollArea 與 Separator 分屬不同 primitive)
- Radix ScrollArea — `@radix-ui/react-scroll-area`

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `data-table-known-defects.spec.md`
- `dialog.spec.md`
- `file-viewer.spec.md`
- `overlay-surface.spec.md`
- `sidebar.spec.md`
