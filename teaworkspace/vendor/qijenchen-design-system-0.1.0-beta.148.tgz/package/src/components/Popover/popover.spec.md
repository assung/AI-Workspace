---
component: Popover
family: composite
variants: {}
sizes: {}
traits:
  - isOverlay
benchmark:
  - Radix Popover primitive: github.com/radix-ui/primitives/tree/main/packages/react/popover
  - MUI Popover: github.com/mui/material-ui/tree/master/packages/mui-material/src/Popover
  - Polaris Popover: github.com/Shopify/polaris/tree/main/polaris-react/src/components/Popover
  - Ant Design Popover: github.com/ant-design/ant-design/tree/master/components/popover
---

# Popover 設計原則

## 定位

Popover 是**點擊觸發的浮層容器**——提供定位、動畫、焦點管理，內容由 consumer 決定。

**實作基礎**：shadcn passthrough——基於 Radix Popover。本 DS 保留 shadcn 原結構 + 橋接 DS token（elevation / radius / border）。

**Layout Family**：非上述 family — composite / multi-section（多區塊組合，自 own layout）。

**視覺對齊 Dialog**：外殼 token 與 Dialog 完全一致（`bg-surface-raised` / `border-border` / `rounded-lg` / `elevation-200`）。差別僅兩點：(1) Popover 是 non-modal 輕量浮層不阻斷背景，(2) **layout-space 鎖 `md`** — header / footer padding 不隨頁面放大（輕量 chrome 保持精簡）；**ui-size 不鎖、繼承 page** — 內部控件隨 page 放大、對齊觸發點（2026-06-15 改,原 `data-density` master switch,見 `popover.tsx` docblock）。

**Content size canonical（2026-04-29,2026-06-15 更新）**:ui-size 繼承 page → **fields(Input / Select / Checkbox)預設隨 page ui-size**(md page = `size="md"` field-height-md 32px;lg page 放大,與觸發點一致)。其餘細節走 SSOT pointer:
- Chrome corner buttons(close X / refresh / dismiss)→ `patterns/overlay-surface/overlay-surface.spec.md`「Chrome dismiss size canonical」(sm native + v5 trick)
- Row inline action(panel list row 內 Eye / drag / suffix toggle)→ `patterns/element-anatomy/inline-action.spec.md`「尺寸對照」table(md = 16+18 hover bg)
- Footer action button → `action-bar.spec.md`(輕量 chrome,sm canonical)

**觸發距離 canonical**：`sideOffset = 8`（px）—— trigger 到 Popover 邊緣的垂直/水平間距。小於 4px 會讓浮層貼死 trigger 失去「另一層」感，大於 12px 會拉斷 trigger ↔ content 的視覺關聯。本 DS 固定 8px 作為 overlay primitive 的共用呼吸距離；Dialog 居中或 full-screen，不適用此規則。

**Viewport 邊距 canonical**:`collisionPadding = 8`(px)——浮層與 viewport 邊緣的最小間距。當 popover 原本要貼近 viewport 邊(trigger 在頁面最右側、或視窗很窄)，定位 primitive 會自動推開 8px，防止內容與螢幕邊界相黏。`sideOffset` 管 trigger↔popover，`collisionPadding` 管 popover↔viewport，兩者互補。Consumer 不需傳 — 預設值是 canonical。

**Align 對齊 canonical(跨浮層 SSOT)**:`align` 必須跟隨 trigger 在容器中的位置,**不是自由選擇**:

| Trigger 在容器 | `align` | 對齊行為 |
|---------------|---------|----------|
| **左側 / 左上**(page header left、sidebar filter button) | `"start"` | Popover 與 trigger 左邊緣對齊,向右展開 |
| **置中**(toolbar 中央、modal 內置中按鈕) | `"center"`(default)| Popover 與 trigger 中心對齊 |
| **右側 / 右上**(page header right、設定按鈕、overflow menu) | `"end"` | Popover 與 trigger 右邊緣對齊,向左展開 |

**為什麼**:Popover 通常比 trigger 寬。align 錯方向會 (1)溢出容器邊緣 / 被 viewport 裁切、(2)視覺上 popover「沒黏在 trigger 那一側」產生 disconnect，使用者以為兩者無關。因此 trigger 靠哪邊，浮層就跟著靠哪邊。

**SSOT 適用範圍(2026-04-20 精緻化)**:本規則是**「結構化浮層」的 canonical** —— Popover / DropdownMenu / Coachmark / SelectMenu 嚴格遵守(這些浮層寬度通常比 trigger 寬、且有結構化內容,錯方向必視覺 disconnect)。

**輕量浮層例外**:Tooltip / HoverCard 不適用此 canonical —— 兩者 predominantly hover 觸發、純展示(不互動或極少互動)、寬度隨內容自適應,Radix 預設 `align="center"` 即可涵蓋絕大多數情境。強行套 trigger-position alignment 反而破壞 Tooltip「貼合指標」的輕量感。這兩個 primitive 走自己的 spec canonical(通常 center + 小 sideOffset)。

**SelectMenu 特例**:SelectMenu 是 input-triggered,width 在 min/max 範圍內自動跟 input 同寬 → `align="start"`(對齊 input 左邊緣)在視覺上與「popover 跟 input 同寬」重疊,consumer 感知不到 alignment 差異。仍採用 canonical 以保 code 一致性,但視覺上是透明的。

其他結構化浮層 spec 若討論 align 應 pointer 指回本節。

**結構化組合（可選）**：PopoverContent 外殼無內距，consumer 可選擇：
- **單一 body**：包 `<PopoverBody>` 取得 SurfaceBody canonical padding (`px-loose py-tight`,`overlay-surface.spec.md` SSOT;Dialog body 另有 `pb-[--layout-space-bottom]` 特化)
- **含標題**：組合 `<PopoverHeader>` + `<PopoverBody>`（下分隔線由 Header 提供）
- **含操作按鈕列**：再加 `<PopoverFooter>`（上分隔線由 Footer 提供）

**Dismiss 預設**(與 Dialog 一致):Popover **預設 dismissible** —— 點擊 trigger 外 / 按 Esc / 焦點被移到 content 樹之外(滑鼠點到別處、程式把焦點移走),三者任一皆關閉。由 Radix 內建 `onPointerDownOutside` / `onFocusOutside` / `onEscapeKeyDown` 行為提供,consumer 無需額外 wire。**鍵盤 Tab 不是離開的路**:面板裡按 Tab / Shift+Tab 在面板內繞圈、走不到 content 樹之外(見「A11y 預設」;2026-09-25 更正,原句「focus 離開 content 樹」被讀成 Tab 可以走出去,與實測不符)。如需強制 modal(必須按 Close 才能關),傳 `modal={true}` 並在 Header 放 Close 按鈕;但這是例外,不是預設——Popover 的本質是「使用者可以忽略、繼續主流程」。

> **跨家族 SSOT pointer**:PopoverHeader 屬 **Padding-based overlay header 家族**;border / padding / dismiss size / withTabs(tabs 進 PopoverHeader 時 border auto-suppress + tabs size sm)的跨家族視覺契約 SSOT 詳 `patterns/header-canonical/header-canonical.spec.md`。本節僅 codify Popover 特有 close X v5 unbounded canonical。

**Close X 按鈕(2026-04-22 v5 unbounded canonical)**:所有 `PopoverHeader` 內建右上 X 按鈕,`<Button data-dismiss iconOnly dismiss size="sm" />` native sm(28 md / 32 lg)。透過 SurfaceHeader 的 v5 CSS rule 自動套負 margin 讓 layout 佔位;PopoverHeader 走 `COMPACT_HEADER_SLOT`(= calc(--font-body-size×1.5) = 21 = title line-box,衍生)→ 佔位 21(輕量 chrome,見 `popover.tsx` docblock),非 Dialog 的 24。`hideClose` prop 可讓 composition 元件(如 Coachmark)選擇隱藏。詳 `patterns/overlay-surface/overlay-surface.spec.md`「Chrome dismiss size canonical」。

**Header / Footer 高度 canonical**:padding-based(繼承 SurfaceHeader / SurfaceFooter),高度 = max(child layout) + 2×tight。header:slot 佔位 21(`COMPACT_HEADER_SLOT` = title line-box,衍生)→ max(21 title, 21 slot) + 2×12 = **45**,自然比 Dialog / Sheet 48 輕一級(`popover.tsx` PopoverHeader docblock + overlay-surface.tsx 對照);footer:SurfaceFooter **不**套 unbounded slot trick(僅 padding + `border-t`,見 `overlay-surface.spec.md`「為什麼 SurfaceHeader 是 padding-based」)→ 高度 = max(child layout) + 2×tight(sm action button 28 → **52** md)。詳 `tokens/uiSize/uiSize.spec.md`「Chrome header 選型 canonical」。

---

## Title typography canonical(non-modal 特化,2026-04-22 v4)

**PopoverTitle 用 `text-body font-medium`(14px),不是 Dialog / Sheet 的 `text-body-lg`(16px)**。這是針對 **non-modal 輕量浮層** 的視覺考量,跟 layout-space 鎖 md 同源的輕量 rationale。

**重量分級(world-class 共通 pattern)**:

| Overlay 類型 | Title typography | Rationale |
|------------|------------------|-----------|
| **Modal**(Dialog / Sheet)| `text-body-lg`(16px)| 重量級決策 surface,title 是決策 anchor,需視覺重量 |
| **Non-modal**(Popover / Coachmark / Tooltip / HoverCard)| `text-body`(14px)| 輕量浮層,可忽略、非阻斷,title 是輔助標籤不搶視覺重心 |

**世界級對照**(7 家 DS 同 split):
| DS | Modal title | Non-modal popover title |
|----|-------------|------------------------|
| Material M3 | Headline(24px large / 16px body 分 variant)| Smaller(usually 14-16px) |
| Polaris | Modal title 大號 | Popover 較小 |
| Atlassian | Modal 大 | InlineDialog 小 |
| Notion | Modal 16px+ | Popover 14px |
| Linear | Modal 16px | Popover / HoverCard 14px |
| Figma | Modal 16px | Inline panel / popover 13-14px |
| GitHub Primer | Dialog 16px | Overlay 14px |

**共通原則**:non-modal overlay 的 title 比 modal 小一級。我方採 16 → 14 分級,在 world-class 範圍內。

**Coachmark 的 PopoverTitle 消費**:Coachmark 的 header 小標籤(如 "新功能介紹" / "Tip 1 of 3")繼承 PopoverTitle 14px。Coachmark **body 內容的主 title**(長敘述型 "建立你的第一個 Workspace")另走 `text-body-lg`(見 `coachmark.tsx` CoachmarkBody 主 title `<h3>`)— 那是 body content 不是 chrome title,分離 concerns。

**禁止**:consumer 自己在 PopoverContent 裡手刻 `<h2 className="text-body-lg">` 當 title(繞 PopoverTitle 的 canonical)。若需要大 title,視為該用 Dialog 而非 Popover(選對元件)。

---

## 何時用

- **點擊觸發的輕量浮層**：filter panel、date picker 展開、設定 mini panel
- **需要放互動元素的浮層**：按鈕、輸入框、checkbox 群組
- **非 modal 的補充 UI**：使用者可以忽略並繼續主流程，不阻斷背景互動

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| hover 觸發（非點擊）| `HoverCard` | HoverCard 觸發是 hover，Popover 是點擊 |
| 純文字提示 | `Tooltip` | Tooltip 更輕量，適合純文字 |
| 需要阻斷背景的流程 | `Dialog` | Dialog 是 modal，Popover 非 modal |
| 操作選單（複製 / 刪除）| `DropdownMenu` | DropdownMenu 有 menu 語意 + 鍵盤導覽 |
| 選值下拉 | `Select` / `Combobox` | 下拉選單用專用元件，不自組 Popover + list |

---

## 與 Dialog 的分界

- **Popover**：non-modal 輕量浮層（filter / settings panel / mini 操作面板）——背景仍可互動
- **Dialog**：modal 阻斷互動（confirmation / form wizard / 需要完成才能繼續的流程）

**判斷法**：問「使用者可以 ignore 這個浮層、繼續使用主介面嗎？」可以 → Popover；不可以、必須處理才能繼續 → Dialog。

## 與 DropdownMenu 的分界

- **DropdownMenu**：有預設 item 結構（MenuItem list），語意是「從清單中選一個動作」— click 單一 item 即觸發 action,無 save CTA
- **Popover**：內容自由（任意 React 元素），可放按鈕、輸入框、圖表、form;支援「暫存選中狀態 + 明確 save CTA」

選單類(click 單項即動作,無 save)用 DropdownMenu;自由組合 UI 面板(多欄表單、filter 控制群、「選完按套用」的多選工作流)用 Popover。

### 合法但少見:Popover 內含可選 item 列 + footer save CTA

Popover 可以在 body 放可選 item 列,**但必在 footer 有 CTA 按鈕(套用 / 儲存 / 完成)觸發狀態提交**。這個 pattern 跟 DropdownMenu 的差別是:**DropdownMenu 一 click 即觸發動作,Popover 這類是「暫存選擇 → 按 CTA 才 commit」**。

**body 是一份可選清單時,列走選單列**(`patterns/overlay-surface/overlay-surface.spec.md`「預設:浮層的 body 是一份可選清單 → 走選單列」):body 撤 chrome padding、`Command`(cmdk)包住提供鍵盤與 listbox 結構、item 自帶 `px-loose` 對齊 header 標題。**不要用 `CheckboxGroup` + 裸 `Checkbox` 自組** —— 那是表單欄位的組合方式,不是選項清單。典型情境:

- **多選 filter panel**:勾選列 + 底部 `清除 / 套用`(canonical = `FilterPanel` story 的 `StatusFilterPanel`)
- **Bulk edit**:選多個 options + 底部 `儲存變更`
- **Custom toolbar 設定**:可選 toggle 列 + 底部 `套用偏好`

canonical 判斷:「使用者 click 單項是否立即改變系統狀態?」是 → DropdownMenu;否(要按 footer CTA 才 commit)→ Popover。

---

## 禁止事項

- ❌ **不把 Popover 當 Tooltip**：Tooltip 是 hover 觸發的純文字輔助，Popover 是 click 觸發的互動面板，語意與觸發模型不同
- ❌ **不用 Popover 做 confirmation dialog**：確認框必須阻斷背景互動,使用者不能忽略——那是 Dialog 的職責
- ❌ **不在 Popover 內放 nested Popover**：嵌套層級混亂、焦點管理崩壞，複雜互動改用 Dialog 或拆成多步驟

---

## 邊界案例

- **極長內容**:PopoverContent 設 `max-h-[var(--radix-popover-content-available-height)]`(popover.tsx:103),body 包 `<PopoverBody>`(SurfaceBody `flex-1 min-h-0 overflow-y-auto`)→ viewport 太小時 header / footer 留在視窗內、body 內捲。中間 wrapper 必 forward flex chain,詳 `../../patterns/overlay-surface/overlay-surface.spec.md`「Viewport-aware scroll chain invariant」。
- **Viewport 邊緣**:`collisionPadding = 8` 自動推開(見「Viewport 邊距 canonical」)。
- **嵌套 Popover**:禁止(見「禁止事項」)。
- **Dark mode**:殼走 semantic token 自動 adapt(見 `color.spec.md`)。
- **Density**:layout-space 鎖 `md`(header / footer padding 精簡);ui-size 繼承 page(見「定位」段)。
- **空內容 / loading / error / validation ownership**:Popover shell **不擁有**這些狀態——由 `PopoverBody` 內的 consumer 內容層負責:空狀態放 `<Empty>`、載入放 `<Skeleton>`、錯誤放 `<Alert>`、表單驗證放 `<Field>` 的 `FieldError`。structural pattern 的職責邊界 SSOT 見 `../../patterns/overlay-surface/overlay-surface.spec.md` SurfaceBody「邊界」段(loading / error / empty 屬 consumer 內容層)。
- **disabled ownership**:Popover 容器無 disabled 態;trigger 的 disabled 由 trigger 元件自管(`<Button disabled>`),content 內控件各自的 disabled 由該控件負責(對應 `StateBehavior` story「職責邊界」段)。

---

## A11y 預設

焦點 / 鍵盤 / ARIA 行為分兩層——**DS 覆寫**(改 Radix 預設)與 **Radix 內建**(沿用)：

- **開啟焦點(DS 覆寫)**：DS 以 `onOpenAutoFocus` 覆寫底層 primitive 的預設 autofocus(見 `popover.tsx` `handlePopoverOpenAutoFocus`),開啟時把焦點落在 body 第一個**表單控件**(`input` / `textarea` / `select` / `button`,排除右上 close X);查無表單控件時退回 footer 按鈕,再無則落在 content 容器(`role="dialog"`)本身。原預設會先 focus 右上 close X,DS 覆寫以避免觸發 tooltip leak，selector 與 `dialog.tsx handleOpenAutoFocus` 共用同一套 DS canonical。**注意**:(1) 若移除此 default handler,行為會回退成底層預設 focus close X;(2) selector 只認表單控件——body 若只含 `a[href]` / `[tabindex]` / `contenteditable` 類可聚焦內容,焦點會落在 content 容器而非該內容,consumer 需自傳 `onOpenAutoFocus` 指定要聚焦的元素。
- **關閉返回(Radix 內建)**：關閉時 focus return to trigger
- **Esc 關閉(Radix 內建 + DS 守門)**：按 Esc 自動關閉並返回焦點。Radix 呼叫 `onEscapeKeyDown` 之後、沒被 `preventDefault` 就關(<https://github.com/radix-ui/primitives/blob/d8b1ffadc6fe0bd2486816751953dfadf14b3357/packages/react/dismissable-layer/src/dismissable-layer.tsx#L102-L110>);`PopoverContent` 的 `onEscapeKeyDown` 經 `../../lib/overlay-escape.ts` `withOverlayEscape`(2026-10-01 取代 ime-composition.ts 的 `withImeSafeEscape`)判定「這一下 Esc 由誰處理」:**輸入法組字中**不關(那一下是在取消選字);**面板裡焦點所在的控件宣告了自己還有一層**(改過的欄位、鍵盤搬到一半的排序條件 / 欄位)→ 那一下留給控件、面板不關,下一下才關 —— 一次只少一層,規則與出處 `ds-canonical/references/keyboard-model-canonical.md`「焦點所在的控件自己那一層也算一層」;控件在這一層**外面**(可打字的 DatePicker 欄位握著焦點、日曆浮層開著)→ 浮層才是最內層,照舊只關浮層、欄位的草稿不動。這幾下 consumer 傳的 `onEscapeKeyDown` 都不會被呼叫,其餘照常轉呼叫。Dialog / Sheet / FileViewer 同一支
- **Tab 留在面板裡(Radix 內建,modal / non-modal 皆同)**:焦點在面板裡的可 Tab 元素上時,在最後一格按 Tab 回到第一格、在第一格按 Shift+Tab 回到最後一格,鍵盤走不出面板(面板裡沒有可 Tab 的元素、焦點落在 content 容器本身時,Tab 原地不動);要離開面板 = 按 Esc(焦點回 trigger)。機制:Radix Popover 內容的 FocusScope `loop: true`(`@radix-ui/react-popover` 1.1.15 `dist/index.mjs:225-226`;non-modal 時 `trapped: false`,見下一條)。這就是 W3C 對話框的規則 ——「Like non-modal dialogs, modal dialogs contain their tab sequence. That is, Tab and Shift + Tab do not move focus outside the dialog.」(<https://github.com/w3c/aria-practices/blob/3f094fde1c81b25dfa69162563bf28d093f854d4/content/patterns/dialog-modal/dialog-modal-pattern.html#L29-L30>),而 Popover content 本身就是 `role="dialog"`。2026-09-25 更正:本條原寫「預設 non-modal **不鎖焦點**」,R15 實測 Tab 出不去,與實作不符(待辦總帳 B11)
- **Focus trap(Radix 內建,僅 modal)**:`modal={true}` 時連滑鼠點外面 / 程式移焦都出不去(`trapped: true`),焦點鎖在 content 內
- **點外 / 焦點被移走即關(Radix 內建,non-modal)**:non-modal 不 trap 的意思是**滑鼠點到別處、程式把焦點移走**時焦點可以離開,一離開就由 DismissableLayer 觸發 dismiss 自動關閉——這是 dismiss-on-focus-out 機制,**不是**「Tab 可以走出去」
- **例外:選單類浮層按 Tab = 收起並往下走**:DropdownMenu 選單與單選下拉(Select / PeoplePicker single)不是對話框,開著按 Tab 收起、焦點從觸發鈕往下(Shift+Tab 往上)走;規則在各自 spec(`../SelectMenu/select-menu.spec.md`「A11y 預設」、`../DropdownMenu/dropdown-menu.spec.md`),來源 = 待辦總帳 B11。多選下拉(有全選鈕)面板裡有按鈕 / 搜尋框,是對話框型,照上面「Tab 留在面板裡」
- **ARIA(Radix 內建)**：trigger 自動 `aria-expanded` / `aria-controls`，content `role="dialog"`
- **Accessible name(DS 覆寫)**:Radix Popover 沒有 Radix Dialog Title 式的自動接線,content `role="dialog"` 預設**無 accessible name**。DS 以 context 補同機制(見 `popover.tsx` `PopoverTitleContext`):`<PopoverTitle>` 掛載時自動把 id 接上 content 的 `aria-labelledby`;consumer 自傳 `aria-label` / `aria-labelledby` 一律優先

焦點與 accessible name 的 DS 覆寫 default 已 wire 在 `PopoverContent`(consumer 可傳自己的 `onOpenAutoFocus` override),保留 Radix `data-state` 屬性即可。**無 `<PopoverTitle>` 的 naked popover 需 consumer 自傳 `aria-label`**,否則 `role="dialog"` 無 accessible name。

---

## Inspector

`Inspector` 提供互動 Controls 即時切換 PopoverContent 六個關鍵維度:`side` / `align`(12 種定位組合)、`sideOffset`(與 trigger 距離)、`width`(w-72 / w-80 / w-96)、`showHeader` / `showFooter`(chrome 結構開關)。內容區由 consumer 決定,Inspector 聚焦容器層級的可試玩 prop(對齊 `sheet.spec.md`「Inspector」canonical)。`PlacementMatrix` 另以靜態 12-cell side × align 矩陣一眼呈現所有定位組合;Header / Body / Footer padding 屬 `overlay-surface` SSOT,由 `ColorMatrix` 的 token 表 + 該 pattern spec 覆蓋。

對應 anatomy story:保留 `Overview` + `Inspector` + 元件特有 `PlacementMatrix`(12-cell side × align 矩陣) + `ColorMatrix` + `SizeMatrix` + `StateBehavior`(open / close / animation) + `Accessibility`。

---

## 相關

- `../HoverCard/hover-card.spec.md` — hover 觸發的對應浮層
- `../Tooltip/tooltip.spec.md` — 純文字提示
- `../Dialog/dialog.spec.md` — 需要阻斷的 modal
- `../DropdownMenu/dropdown-menu.spec.md` — 有 menu 語意的操作選單
- `../SelectMenu/select-menu.spec.md` — SelectMenu 消費 Popover 作為浮層容器
- `../Coachmark/coachmark.spec.md` — Coachmark 為 Popover 的 composition pattern(無 header / 有 media / footer justify-between),共用所有 overlay-surface SSOT
- Radix Popover primitive — `@radix-ui/react-popover`
- `../../patterns/overlay-surface/overlay-surface.spec.md` — Header / Body / Footer padding SSOT（Dialog + Popover 共用）

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `agent-panel.spec.md`
- `coachmark.spec.md`
- `dialog.spec.md`
- `dropdown-menu.spec.md`
- `hover-card.spec.md`
- `overlay-chrome-sizing.spec.md`
- `overlay-surface.spec.md`
- `select-menu.spec.md`
- `tooltip.spec.md`
