---
component: DateGrid
family: composite
variants: {}
sizes: {}
traits:
  - hasInteractiveStates
  - isInternal
benchmark:
  - react-day-picker (shadcn Calendar base): github.com/gpbl/react-day-picker
  - Ant Design DatePicker: github.com/ant-design/ant-design/tree/master/components/date-picker
  - MUI X Date Pickers: github.com/mui/mui-x/tree/master/packages/x-date-pickers
---


<!-- M22 retrofit DONE 2026-05-03 v11(real source URLs added inline below)-->

# DateGrid 設計原則

## 定位

DateGrid 是 **DatePicker 內部的 date-grid primitive**(月份格網 + 前後導航 + 日 cell),**不直接面向 consumer**。2026-04-21 從原本的 `Calendar/` 改名為 `DateGrid/`,因為「Calendar」此命名在世界級 DS 慣例專指**事件檢視 canvas**(見 `../Calendar/calendar.spec.md`),而本元件只是「選日期用的格網」,不做事件呈現。保留 Calendar 名字給 event view 元件是世界級對齊。

**實作基礎**:`react-day-picker@9` 包裝 + 本 DS token 覆寫預設視覺。**載入 RDP `style.css` 為結構基底**(tsx `import 'react-day-picker/style.css'`),再以 `classNames` prop 逐 key 用 DS token 覆寫視覺層(caption / weekday / day / range 等);**未列出的結構 key 沿用 RDP 原生 `.rdp-*` 預設**。故非「零 rdp-*」,而是「DS token 管視覺層、rdp-* 提供結構層」。

**Layout Family**:非上述 family — composite / multi-section(月份 caption + 星期標頭 + 日期網格 + nav 按鈕,多區塊組合)。

**Storybook title 層級**:`Design System/Internal/DateGrid/*`(非 Components/,因為它是 DatePicker 的 internal primitive;對齊 `.claude/rules/ui-development.md`「Public component vs Internal primitive canonical」(intent-based 判準):consumer 經 `DatePicker` wrapper 取得,不直接 import 本元件)。

**世界級命名對照(為什麼不叫 Calendar)**:

| DS | 「Calendar」此名字給誰 | DayPicker 內部格網叫什麼 |
|----|-----------------------|-------------------------|
| Notion | event calendar 檢視(月/週/日) | 無(DatePicker 另有 calendar popup) |
| Google | Google Calendar(event 檢視) | 無公開 DS,DatePicker 另管 |
| Ant Design | inline 行事曆(含事件) | 無(DatePicker 自建 panel) |
| Apple HIG / Fantastical | event 檢視 | 無(DatePicker inline) |
| Material MUI | `<Calendar>` 已棄 → `<DateCalendar>`(date picker grid,single-date only;Range 走另元件 `<DateRangeCalendar>`)— source: [github.com/mui/mui-x](https://github.com/mui/mui-x/blob/master/packages/x-date-pickers/src/DateCalendar/DateCalendar.tsx) | `<DateCalendar>` |
| React Aria | `<Calendar>`(date picker grid)— source: [React Aria Calendar](https://react-spectrum.adobe.com/react-aria/Calendar.html) | `<Calendar>` |
| **本 DS** | **`<Calendar>`**(event 檢視 canvas,見 `../Calendar/`) | **`<DateGrid>`**(本元件) |

結論:本 DS 用 **`Calendar` 表示 event view**、用 **`DateGrid` 表示 date-picker grid**。兩個名稱直接反映資料模型與 interaction contract，避免 consumer 以同一 component identity 混用事件瀏覽與日期選取。

---

## 何時用

DateGrid 是 internal primitive(見「定位」),一般 consumer 經 `DatePicker` 取得;以下為 DS 內部組合或進階 inline 場景:

- **Inline 月曆顯示**:dashboard / 行事曆小卡 / 日期 filter bar
- **DatePicker 浮層內嵌**:DatePicker 消費本元件作為選日 popup(見 `../DatePicker/date-picker.spec.md`)
- **範圍選擇**:`mode="range"` 適用「from → to」場景(訂單日期範圍、查詢時段)
- **多日選擇**:`mode="multiple"` 適用「勾選多個不連續日期」(event sign-up)

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| 日期輸入欄位 | `DatePicker` | DateGrid 是 inline,欄位需要 trigger + popup 結構 |
| 純顯示單日期 | `<DatePicker mode="view">` / `Intl.DateTimeFormat` | 不需 interactive 月曆 |
| 時間選擇(時分) | `TimePicker`(見 `../TimePicker/time-picker.spec.md`)| DateGrid 只處理日期層級 |
| 事件行事曆(日程本) | 專用行事曆元件 | DateGrid 是日期選擇;事件日誌需要 event overlay / drag / week/month view 切換 |

---

## mode(react-day-picker API)

| mode | 選擇行為 | 典型場景 |
|------|---------|---------|
| `single` | 單日選取,點新日取代舊選 | DatePicker / 生日 / 到期日 |
| `multiple` | 可勾選多個不連續日期 | event 報名多日 |
| `range` | from → to 連續範圍 | 訂單日期範圍 / 查詢時段 |

**mode 無預設值**(react-day-picker v9 `mode?: Mode | undefined`,本元件薄包裝不補 default):未傳 `mode` 時 grid 為**非互動純展示**(day 渲染純文字非 button,不可選);DS 內所有消費者(DatePicker / stories)皆顯式傳 `mode`。

**range vs multiple 分界**:選的是「連續區間」(只在乎起迄兩端)→ `range`;選的是「各自獨立的日子」(可不連續、逐日增減)→ `multiple`。起迄日場景(訂單 / 查詢時段)固定走 `range`;簽核 / 報名這類逐日勾選走 `multiple`。

---

## 實作機制:classNames 鏡射 modifier keys(2026-04-21 AR43 修正)

**重要**:react-day-picker v9 的 cell state DOM attribute 只有 `data-selected / data-disabled / data-today / data-outside / data-focused`(另有非 state 的 `data-day / data-month / data-hidden`);**`data-range-start / data-range-middle / data-range-end` 不存在**。

因此用 `[&[data-range-middle=true]]:xxx` 這種 attribute selector **根本不會生效**(舊版做法錯誤)。

**正解**:把 state 樣式放進 `classNames[state]` 物件,v9 的 `getClassNamesForModifiers` 會在對應 modifier 為 true 時把該 key 的 class 附加到 Day CELL。範例:`classNames.range_middle: "before:content-[''] before:absolute before:inset-y-0 before:-inset-x-[2px] before:bg-neutral-selected [&>button]:!bg-transparent"`(用 `before:` pseudo + semantic `--neutral-selected` token,對齊下方 Range track canonical 與 tsx)。

`[&>button]:xxx` 從 cell 向內選子 button 用於 button-level 樣式(selected / disabled 的藍底白圓等)。

---

## 五種 cell state canonical(2026-04-21,AR43 定案)

本 DS picker grid 的視覺狀態 contract：
- today 不做 ring circle(跟 hover ring 混淆),改用 underline 或 dot
- selected 用藍底白字圓,range 端點共用同樣視覺
- range 中段用灰底 rectangle track,跟端點的圓相切成連續 pill
- hover 非 filled(與 selected 區隔)
- disabled 顯示灰底圓圈(明確「此格不可選」),非 opacity-50

| State | 視覺 | Token 角色(class 細節見 tsx)| 備註 |
|-------|------|------------------------------|------|
| **today**(未選) | today indicator | 消費 `primary` semantic role；確切結構與尺寸由 `date-grid.tsx` 擁有 | 與 selected background 保持不同狀態語言，兩者疊加時仍可辨識 |
| **today + selected** | 數字下方短圓桿(白) | bar 色切 `on-emphasis` | 選中藍底上藍 bar 隱形,必切白;以 state 疊加 selector 覆寫 |
| **disabled** | 灰底 + 淡字 | `bg-disabled` + `fg-disabled` + `cursor-not-allowed` | 跟 Button disabled token 一致,不自創 palette |
| **outside(非本月)**| 單月:淡字(只文字);**兩月以上:不渲染**(格留空) | `fg-muted` —— **僅在該日仍可點、且未被選中時**;`numberOfMonths > 1` 時 `showOutsideDays` 強制 false(consumer 傳 true 也不放行) | 比 disabled 弱:outside 的前提就是「仍可 hover / 可點」,純是「非焦點月份」的標示。**該日若同時被 disable,一律讓位給 `fg-disabled`**(M24「disabled > muted」)—— 兩者都套會讓「非本月又不可選」比「本月不可選」更深,恰好相反。實作以 `[&:not([data-selected])>button:not(:disabled):not([aria-disabled="true"])]` 表達此前提,不用 `!important` 硬壓(2026-09-07 user 抓圖修正;2026-09-23 加 `:not([data-selected])`,選中是 state、淡字是裝飾)。**兩月並排時同一天會在相鄰兩張月曆各出現一次,區間 track / 端點藍圓 / 預覽框就被畫兩次**(user 2026-09-23 圖一:4/26 在四月與五月面板各一顆藍圓)—— [MUI X `DateRangeCalendar.tsx`](https://github.com/mui/mui-x/blob/master/packages/x-date-pickers-pro/src/DateRangeCalendar/DateRangeCalendar.tsx)(`calendars > 1` 時補位格 `opacity: 0`、不吃任何選取樣式,原註解「otherwise the same day would be rendered in two calendars」)/ [Polaris `Day.tsx`](https://github.com/Shopify/polaris/blob/main/polaris-react/src/components/DatePicker/components/Day/Day.tsx)(`Month.tsx` 把非當月位置當 `null` 交給 `Day`,`Day.tsx` 渲染空的 `EmptyDayCell`)/ [flatpickr `index.ts`](https://github.com/flatpickr/flatpickr/blob/master/src/index.ts)(`showMonths > 1` 時 `prevMonthDay hidden`)/ [react-day-picker 文件](https://daypicker.dev/docs/grid-and-months)(「By default, DayPicker hides the days falling into other months」)都不顯示,只有 [Ant `panel.ts`](https://github.com/ant-design/ant-design/blob/master/components/date-picker/style/panel.ts) 顯示淡字但所有 in-range / range-start / range-end 樣式鎖在 `&-in-view`;user 2026-09-23 拍板「兩月時不顯示鄰月日子」 |
| **selected / range 端點** | 藍底白字圓 | button `primary` 底 + `on-emphasis` 字 | range_start / range_end 共用此視覺 |
| **range 端點 cell bg** | 灰底半圓 track,**高度 = button**,向 middle 外擴 2px bridge gap | `neutral-selected`;class 細節見「Range track canonical」+ tsx | 圓弧半徑 = button 半徑無錯位;舊版 cell-level bg 圓弧半徑 16px 比 button 14px 大 = 視覺 misalign |
| **range track(中間)** | 灰底矩形,**高度 = button**(28×28 @ md),左右各外擴 2px 接合相鄰 cell | `neutral-selected`;button 透明顯露 track(class 細節見 tsx)| track 高度跟 selected 圓一致,不留 2px「fat」邊;相鄰 pseudo 接合連貫橫向 track |
| **hover(未選中)** | 藍圈 outline(無 fill) | button hover ring 色 `primary-hover`(2026-07-07 user 拍板統一:瞬時 hover 進 primary 家族 = hover 階,FileUpload / Slider thumb hover 同族;base 專屬持續選中與 focus),無 bg(ring 寬度等 class 細節見 tsx)| outline 保留 cell 底色，與 selected fill 明確區分 |
| **range 預覽框(停留 / 焦點)** | 同色同粗的藍色細框把「點下去會變成」的區間框起來,兩端半圓、與 track 同高;停留日就是框的那一端 | td `::after`(track 用 `::before`),1.5px `primary-hover`;class 住在 tsx `RANGE_PREVIEW_CLASSNAMES` | 只有 `DatePicker.Range` 會算出這組 modifier(它才知道正在選哪一端);DateGrid 只擁有畫法。規則見下方「區間預覽框」。**跨格不閃**:停留日掛在 button 的 mouseenter / mouseleave,格間 4px 縫隙屬於 table、圓外的四個角屬於 td,指標經過這些地方會先 leave 再 enter、整條框卸掉一幀(user 2026-09-23 抓到「水平移動到隔日框會閃一下」)—— 現行解法是 DateGrid **只在指標真的離開整張格陣時才轉發 leave**,停在縫裡或可點日子圓外的角裡都算「還在上一天」(不論移得多快多慢、走不走中線;慢慢從縫裡走出去的那條路 2026-09-26 補上 = D1,圓外的角 2026-09-26 補上 = D2),見下方「日期格的命中區 = 可視形狀」的「現行機制」;框亮著時在縫或角裡點下去 = 點停留日,見同節「縫與角裡的點擊」;2026-09-23 曾用 day button `::before` 外擴 2px 吃掉那道縫,已於 2026-09-24 撤除(命中區大於可視形狀) |
| **focus-visible(鍵盤焦點)** | 非填色格:往內 2px 藍線;填色格(selected / range 端點):1px 白線退 3px,外圈留藍 | day button `focus-visible:focus-ring-inset`;填色 modifier 另掛 `EMPHASIS_FOCUS_RING_CLASSNAME`(= `focus-ring-inset-emphasis`,幾何 owner `styles/base.css` + `focus-canonical.md`「填色元素上的內描邊」)| 格與格只隔 4px,track / 預覽框就跑在縫裡,往外畫會壓到框線;藍底上藍線看不見、白線貼邊只是削小藍圓(2026-09-23 user 拍板 D,原話在 focus-canonical 來源總帳) |

### 鄰月日子:一條原則(2026-09-24 user 拍板)

**鄰月日子只在「同一天不會在畫面上出現兩次」時顯示**:一張月曆 → 淡字顯示(月界脈絡,前後幾天可直接點);兩張以上並排 → 不渲染(同一天會在相鄰兩張各出現一次,區間 track / 端點藍圓 / 預覽框就被畫兩次)。這是一條原則,不是兩條特例:`DatePicker` 單月與 `DatePicker.Range showTime`(一張月曆)淡字、`DatePicker.Range` 日期(兩張)不渲染,差別只在月數,和 [MUI X `DateRangeCalendar`](https://github.com/mui/mui-x/blob/master/packages/x-date-pickers-pro/src/DateRangeCalendar/DateRangeCalendar.tsx) 開一張或兩張月曆一樣。實作:`date-grid.tsx` 對 `numberOfMonths > 1` 強制 `showOutsideDays=false`(consumer 傳 true 也不放行)。

世界級不是「兩種視圖像素一致」,而是兩題各自有答案,一致的是原則(2026-09-24 逐家讀原始碼 / 文件):

| 家 | 一張月曆的預設 | 兩張並排 |
|---|---|---|
| [flatpickr `index.ts`](https://github.com/flatpickr/flatpickr/blob/master/src/index.ts) | 淡字(`prevMonthDay`) | 不渲染:`isMultiMonth ? "prevMonthDay hidden" : "prevMonthDay"` |
| [Carbon `_flatpickr.scss`](https://github.com/carbon-design-system/carbon/blob/main/packages/styles/scss/components/date-picker/_flatpickr.scss)(底層 flatpickr) | 淡字(`.prevMonthDay { color: $text-helper }`) | 範圍模式仍一張月曆(rangePlugin,無 showMonths) |
| [MUI X `DateCalendar.tsx`](https://github.com/mui/mui-x/blob/master/packages/x-date-pickers/src/DateCalendar/DateCalendar.tsx) / [`DateRangeCalendar.tsx`](https://github.com/mui/mui-x/blob/master/packages/x-date-pickers-pro/src/DateRangeCalendar/DateRangeCalendar.tsx) | 預設不渲染(`showDaysOutsideCurrentMonth` @default false,可開成淡字) | 強制不渲染:`calendars === 1 && showDaysOutsideCurrentMonth`,註解「otherwise the same day would be rendered in two calendars」 |
| [Polaris `Month.tsx`](https://github.com/Shopify/polaris/blob/main/polaris-react/src/components/DatePicker/components/Month/Month.tsx) | 空格 | 空格 |
| [react-day-picker 文件](https://daypicker.dev/docs/grid-and-months) | 預設不渲染(`showOutsideDays` 可開) | 同一個開關,與月數無關 |
| [shadcn `calendar.tsx`](https://github.com/shadcn-ui/ui/blob/main/apps/v4/registry/new-york-v4/ui/calendar.tsx) | 淡字(`showOutsideDays = true`) | 淡字,選中時仍淡字(`aria-selected:text-muted-foreground`) |
| [Ant `panel.ts`](https://github.com/ant-design/ant-design/blob/master/components/date-picker/style/panel.ts) | 淡字 | 兩面板都淡字,in-range / range-start / range-end 鎖 `&-in-view` |
| [Atlassian Calendar](https://atlassian.design/components/calendar/examples) | 淡字(範例可見 29、30 與 1–9) | 無兩月 |

一張月曆:淡字 5 家、預設不渲染 3 家;兩張並排:不渲染 4 家、淡字 2 家;依月數切換只有 flatpickr 明寫,MUI X 的開關語意相同(只在單一月曆時生效)。本 DS 現況正是兩題各自的多數組合。

## 組合狀態(state stacking order)

- today + selected → selected 勝出的**底色**(藍底白字圓);bar 跟著切 on-emphasis(白)保持可見
- range-start / range-end → selected 規則(cell 半圓 track + button 圓)
- range-middle → track 規則(cell 灰底矩形 + button 透明)
- today + range-middle → track(灰底)+ today bar **維持藍色**(2026-07-07 user 拍板:切白只屬「藍底白字圓」的選中日/端點;range 中段是淺灰底,白 bar 近乎隱形 = today 標記消失。range_middle 以 `!bg-primary` 覆寫 today 的 `data-selected` 切白——RDP v9 range 中段日同樣掛 selected modifier 故會誤觸發。對照 Ant panel.ts:cell-today 指示 = colorPrimary,in-range 只換底色、無規則隱藏/改色 today 指示)
- hover 在 selected / disabled 上被 ring-0 壓制(避免二次 hover 出現方框 bug);RDP `mode="range"` 的 range-middle 因同樣掛 selected modifier,button hover ring 一併被壓制(2026-07-05 對照 RDP source 修正舊句「hover ring 仍顯示」)。**`DatePicker.Range` 的中段不掛 selected,停留時由「區間預覽框」接手:停留日不畫單格圈,改畫框的半圓端點**(2026-09-23 user 拍板;此前這一句被當成「中段 hover 不該有圈」的規則,其實它只是描述套件行為,從未有人拍板 —— 來源總帳見 `../DatePicker/date-picker.spec.md`「區間預覽」)
- **選中日 hover 底色升階**:ring 壓制之外,選中日 hover 時 `bg-primary → bg-primary-hover`(2026-07-06 補明文——「選中之上 hover = 同色相升 hover 階」家族,Checkbox / Switch checked hover 同款;code 已有此行為,本句消 spec-code 落差)
- focus-visible + range-middle(RDP `mode="range"`)→ 中段同掛 selected 會吃到填色格的白線,但中段底是淺灰、白線看不見,以 `[&>button]:focus-visible:!focus-ring-inset` 壓回一般往內 2px 藍線(同權重靠順序不可靠);`DatePicker.Range` 的中段不掛 selected,直接走 day button 的內描邊
- outside + selected(單月,選中日落在鄰月位置)→ 藍底白字圓照畫、不淡化(state 勝裝飾,M24);淡字選擇器以 `:not([data-selected])` 讓位。RDP `mode="range"` 單月的鄰月中段日同掛 selected,字色跟當月中段一樣深(不淡化;只在單月 range 出現)
- outside + range / 預覽框(兩月)→ **不存在**:兩月以上鄰月日子不渲染(見 outside 列)。2026-09-23 前這一組從未寫進本清單(M5 缺口),code 憑 range 中段的 `!text-foreground` 決定結果:鄰月日子一進區間就全深、起點藍圓在兩個面板各畫一次;2026-09-07 只修了 outside × disabled 這一對,沒掃同族的 outside × range(M10)

## 區間預覽框(2026-09-23 user 拍板)

**是什麼**:`DatePicker.Range` 停留(滑鼠 / 看得見的鍵盤焦點)在某一天時,用**單日 hover 圈同一條藍色細框**(1.5px `primary-hover`)把「現在點下去,區間會變成從哪到哪」框起來。已選區間的灰色 track 照舊顯示,框疊在上面:縮小時框在 track 裡面、放大時框超出 track。**哪幾天要框由 DatePicker.Range 決定**(它才知道正在選哪一端,規則表在 `../DatePicker/date-picker.spec.md`「區間預覽」);本節只擁有**畫法**。

| 格 | 畫法 |
|---|---|
| 起點 | 上下邊 + 左側邊 + 左半圓(`rounded-l-full`,圓半徑 = button 半徑,與藍圓同弧);右側向鄰格外擴 2px 接縫 |
| 中段 | 只有上下邊;左右各外擴 2px 接縫,不畫側邊 |
| 終點 | 鏡射起點 |
| 單格(起訖同一天) | 完整一圈(左右側邊 + 全圓角),位置與大小 = 單日 hover 圈 |
| 列首 / 列尾(換列處) | 不畫側邊,框是開口的;外擴歸零不溢出面板留白 —— 與 track 在換列處的處理同款 |
| 停留日 | **不畫 button 的單格 hover 圈**,框的半圓端點就是它;缺口朝區間內側,方向依正在選開始日或結束日而定(user 原話:「所 hover 的日期的藍框不會是完整的圓形,而會是一個半圓,至於這個半圓的缺口朝向哪一邊則取決於正在選的是起始日還是結束日」) |
| 已選端點落在框裡 | 藍圓在 button 層(z 在框之上),框的線從圓的上下切點進出,視覺連續;不另外處理 |

**層次**:track = td `::before`、預覽框 = td `::after`、today bar = button 的 `::after`,三者互不衝突;button 在最上層。

**世界級對照**(讀原始碼,2026-09-23):五家有區間選擇的元件庫都在停留時預覽區間,差別只在畫法 —— Ant Design v4 用虛線上下邊 + 兩端側邊([panel.less](https://github.com/ant-design/ant-design/blob/4.x-stable/components/date-picker/style/panel.less) `-range-hover*`,`border-top/bottom: dashed @picker-date-hover-range-border-color`)、MUI X 用 1.2px 虛線([DateRangePickerDay.tsx](https://github.com/mui/mui-x/blob/master/packages/x-date-pickers-pro/src/DateRangePickerDay/DateRangePickerDay.tsx) `previewStyles`)、Ant v5 現行與 Polaris 用與已選區間同色的淺色填([rc-picker PanelBody.tsx](https://github.com/react-component/picker/blob/master/src/PickerPanel/PanelBody.tsx) 把 `hoverRangeValue` 算成 `-in-range`;[Polaris Day.tsx](https://github.com/Shopify/polaris/blob/main/polaris-react/src/components/DatePicker/components/Day/Day.tsx) `(inRange || inHoveringRange) && styles['Day-inRange']`)、Carbon(flatpickr)用填色([index.ts](https://github.com/flatpickr/flatpickr/blob/master/src/index.ts) `onMouseOver` → `startRange / inRange / endRange`)。**本 DS 選實線**:沿用單日 hover 圈的顏色與粗細,不新增第二種「暫定」表達(M23 DS 既有語言優先;user 2026-09-23 Q2 拍板)。我們包的 react-day-picker 本身沒有預覽([range-mode 文件](https://daypicker.dev/selections/range-mode)只有 `range_start / range_middle / range_end`),所以由 DatePicker.Range 自算。

## 日期格的命中區 = 可視形狀(2026-09-24 逐案裁定)

**日期格的可視形狀是那個 28×28(lg 32)的圓**(`day_button` 的 `rounded-full`,懸停時 1.5px 藍圈就畫在它身上),
**命中區就是同一個圓,不外擴**。跨元件契約(`../../ds-canonical/references/hit-area-canonical.md`
「懸停回饋的形狀 ≡ 命中區」)的唯一例外是「可視形狀先天當不了目標的線與點」;28px 的圓不屬於那一類,吃不到例外。
(2026-09-26 補註:區間預覽框亮著時,縫與圓外的角裡那一下點擊交給停留日 —— 那**不是**把命中區外擴:滑過仍只從這顆圓開始,
沒有框時縫與角點了照樣沒反應。規則與理由見下方「縫與角裡的點擊」。)

### 先前這裡有一條隱形帶,而且比看起來大得多

2026-09-23 這裡曾有 `before:content-[''] before:absolute before:-inset-[2px]`,
名義上是「四邊各 2px」,**實測是最遠外推 9.3px** —— 因為 `::before` 是**方的**、沒有圓角,
它不只補了格間 4px 的縫,還把圓**四個角外面**的區域一起收進命中區(方角到圓心 √2×16 ≈ 22.6,圓半徑 14)。

| 量的東西(`elementFromPoint` 逐 0.5px 掃,storybook 展示--單選) | 移除前 | 移除後 |
|---|---|---|
| 圓內取樣點命中 / 漏掉 | 2188 / **0** | 2188 / **0** |
| 圓外取樣點「仍然命中」 | **1763** | **40** |
| 圓外最遠仍命中的距離 | **9.33px** | **1.10px**(瀏覽器對圓角命中測試的抗鋸齒,同 `agent-fab-hit-area-invariant.mjs` 的 `EDGE_TOLERANCE = 1.5`) |
| 格間縫隙中點的擁有者 | 相鄰日期的 button | `<table>`(沒有人宣稱它) |

### 那條帶原本在解什麼 —— 以及為什麼那是表層解

它解的是 user 2026-09-23 抓到的「從某日水平移動到其隔日,藍色的區間框線都會閃動一下」:
停留日掛在 button 的 `mouseenter` / `mouseleave`(react-day-picker 只給這一層),
而格與格之間的 4px(`border-spacing-1`)屬於 `<table>`、不屬於任何一天 ——
指標經過縫時先 leave(整條框卸掉)再 enter(補回)。

**閃動的根因是「停留日在縫裡被清掉」,不是「縫裡沒有人收 enter」。** 幾何外擴改的是後者,是表層。
根因層的解法就在當時那條註解自己引到的 MUI:**只在指標真的離開整張格陣時才清停留日**
([DateRangeCalendar.tsx:479-486](https://github.com/mui/mui-x/blob/master/packages/x-date-pickers-pro/src/DateRangeCalendar/DateRangeCalendar.tsx) ——
`rangePreviewDay` 的清除逐字掛在 `CalendarTransitionProps` 的 `onMouseLeave`,也就是**整個日曆容器**,不是每一天)。

### 現行機制(`date-grid.tsx`)

1. 月曆格陣掛 `data-day-grid` 錨點(`AnchoredMonthGrid`,覆寫 RDP 的 `MonthGrid`)。
2. `handleDayMouseLeave`:leave 事件的 `relatedTarget` 若落在同一張格陣的**縫或角**裡(`isGapOrCorner`),就**不轉發**給消費端;
   其餘一律照常轉發。
   - **縫**:在格陣裡、但既不在 `<td>` 也不在 `<th>` 上 —— border-spacing 的 4px 空白、表格最外圈,都屬於 `<table>` 自己。
   - **角**(2026-09-26 補,D2):在某個**可點日子**的 `<td>` 裡、但不在它那顆圓(button)上。日期是 28px 的圓、放在 28×28 的方格裡,
     圓外的四個角屬於 td、不屬於圓。先前只算縫、把角當成「已經離開」,指標只要沒走在格子正中線上就先清框再補回 ——
     2026-09-26 實測(每步 1px,淺深色相同):偏上 1/4 格 6 步、貼上緣 2px 14 步、貼左緣 2px 14 步、斜穿四格交會處 12 步,
     整條框(17 格)消失;走中線 0 步。09-24 的實測與閘都只走中線,所以沒抓到。
   - 不可點的日子(含它的角)、空白補位格、星期列、格陣之外:都不算,照常清掉。
   - 若整張 DateGrid 被放進別的表格的格子裡,`closest('td,th')` 會找到外面那一格;判斷一律以「那一格在不在本格陣裡」為準,不會把縫誤判成離開。
3. `handleGridMouseOver`:補掉「穿過縫或角之後停在**不可點**的日子、空白補位格或星期列」那條路徑 ——
   disabled 的 button 收不到滑鼠事件、不會再有任何 day enter/leave,沒有這一段的話上一天的預覽框會留著
   (`datepicker-range-preview.mjs`「順序不合不預覽」那兩條斷言就是這樣紅的,2026-09-24 實測)。停在縫或角裡不動作(與第 2 條同一支判斷)。
4. `handleGridMouseLeave`(2026-09-26 補,D1,待辦總帳 N54):補掉「**從縫或角直接離開格陣**」那條路徑 ——
   指標離開最外圈那一天時落在縫或角裡,那次 leave 依第 2 條被吞(欠著);接著指標走出 `<table>`,已經沒有任何一天會再收到 leave、
   也沒有 `td` / `th` 會收到 mouseover,預覽框就卡在上一天。實測(2026-09-26 前):從 6/13 每步 1px 往右,經過縫、月曆內距、浮層邊,
   走到浮層外 20px,停 2 秒仍是 5/4→6/13;每步 1–4、8px 都卡住,6、12、20px 或一次跳出去才會清 —— 快慢決定了指標有沒有「停」在縫裡。
   修法:格陣 `<table>` 掛 `onMouseLeave`,**只在有欠著的 leave 時**補送一次(一次跳出去那條路 day button 的 leave 已照常轉發,不重送)。
   這是上面那句判準「只在指標真的離開整張格陣時才清」本來就要的,缺的只是實作:MUI X 同時掛了「容器 `onMouseLeave` 清除」
   ([DateRangeCalendar.tsx#L481-L486](https://github.com/mui/mui-x/blob/v9.14.0/packages/x-date-pickers-pro/src/DateRangeCalendar/DateRangeCalendar.tsx#L481-L486)
   `onMouseLeave: () => setRangePreviewDay(null)`),2026-09-24 照 MUI 做「縫裡不清」時沒一起做這一半。
   兩張月曆並排時每張各是一張格陣:兩張之間的空白算離開(`../DatePicker/date-picker.spec.md`「滑鼠離開**日期格區**」)。
   縫與角裡照亮(維持上一天)不變;「偏離中線橫越時仍會閃」(D2)由第 2 條的「角」解決。
   閘:`scripts/datepicker-range-preview.mjs`「慢慢移出」段(`exit` 家族,含對照組;(c) 路線貼上緣 2px,先穿過角再出去)。
5. `handleGridClick` / `handleGridPointerDown` / `handleGridMouseMove` / `handleDayFocus`(2026-09-26):框亮著時在縫或角裡點下去 = 點停留日,
   游標同為手形;`handleDayFocus` 只記「滑鼠停留之後,鍵盤又移了看得見的焦點」(最後一個輸入是鍵盤 → 縫與角不接點擊),不改任何焦點行為 ——
   見下一節「縫與角裡的點擊」。

錨點刻意用顯式屬性而不是 `closest('table')`:標籤名是「剛好成立的觀察量」,不是要保證的性質(M37);
而且顯式屬性讓閘的對照組可以只用一行 `removeAttribute` 精準弄壞這個機制。

⚠️ `AnchoredMonthGrid` **必須定義在 module 層**。第一版寫成 render 內的 inline 箭頭函式,
每次 render 都是新的 component type → React 把整個格陣 unmount 再 mount → RDP 內部 effect 重設 state →
`Maximum update depth exceeded`(React #185),storybook 整個 DatePicker range 故事白畫面。

### 縫與角裡的點擊(2026-09-26)

**規則**:區間預覽框亮著、指標停在縫或角裡(框仍停在上一天)時,**點下去 = 點那一天** —— 結果與直接點那一天完全相同
(DatePicker.Range 正在選結束日時:結束日變成那一天、浮層關)。游標在那裡與日期一樣是手形。
沒有框的時候,縫與角點下去沒反應、游標不是手形。
跨元件的原則住在 `../../ds-canonical/references/hit-area-canonical.md`「滑過原則」一-6(評分星星同一條);本節只寫日期的細則。

| 指標在哪、當時的狀態 | 縫與角裡的預覽框 | 點下去 | 游標 |
|---|---|---|---|
| 滑鼠從某一天移進縫或角,框亮著、停留端就是那一天 | 維持上一天 | = 點那一天 | 手形 |
| 沒有框(兩端都空,或對面那端還空、只有單格 hover 圈) | —— | 沒反應 | 一般箭頭 |
| 鍵盤把框移到別天之後,滑鼠還停在縫或角裡 | 框在鍵盤那一天 | 沒反應(縫與角屬於滑鼠上一天,那一天不是框的停留端) | 一般箭頭 |
| 觸控 / 觸控筆點在縫或角裡 | —— | 沒反應(維持原樣) | —— |
| 不可點的日子、空白補位格、星期列 | 清掉(見「現行機制」第 3 條) | 沒反應 | —— |

**來源**:
- 決定:待辦總帳(`governance/planning/2026-09-25-interaction-and-hover-remediation.md`)N54 建議 ①
  「預覽亮著的任何位置、包括縫,點下去就得到正在預覽的值」(`:229`,AI 措辭);2026-09-26 同意批次 `:105` ——
  「日期縫與角」列在 user 沒點名、依「其餘都照建議做嗎」的問法理解為照建議做的四項裡(總帳原文標為 AI 判讀、回報時明講);
  實作的兩句「在縫或角裡點下去 = 確認正在預覽的那一天」「日期圓圈外的角滑過去不再閃」是 **AI 的措辭**,不是 user 原話。
- 原則:user 2026-09-26(總帳 `:225`,逐字)「我滑到某個區塊但不是滑到文字上但文字卻變色了，此時表示產生了樣式變化，儘管沒滑到文字上，此時點擊也應該要有反應，我的意思是這樣」;
  同意改寫原則見 `:65`(「1. 我同意」)。框亮著時,縫與角正是「滑過有變化」的位置。

**點到哪一天 = 框停在哪一天**:同一個角點下去得到哪一天,取決於指標是從哪一天移進來的(例:從 5/20 移進 5/21 的左上角 → 得到 5/20;
React Aria 實測相同,R20 已指出 —— 它在「月曆裡、但不在按鈕上」放開一律確認正在預覽的區間,[`useRangeCalendar.ts#L80-L86`](https://github.com/adobe/react-spectrum/blob/4dd44e0f400636a87a9ad4390903e78c5ae6113c/packages/react-aria/src/calendar/useRangeCalendar.ts#L80-L86))。滑鼠甩得很快、中間幾天沒被取樣到時也一樣 —— 框停在哪一天,點下去就是哪一天,永遠是畫面上框著的那一個。

**這不是把命中區外擴**(與上方「命中區就是同一個圓」相容):滑過(enter)仍只從那顆圓開始;沒有框時縫與角點了照樣沒反應。
縫與角只在「框已經亮著、而且停留端就是那一天」時接那一下點擊 —— 回饋在前、點擊在後,不會出現「沒亮卻點得到」。
判斷「框的停留端就是那一天」直接看那一格有沒有掛上框的端點 class(`RANGE_PREVIEW_CLASSNAMES` 的起點 / 終點 / 單格,只住在 `date-grid.tsx`)——
框正是那組 class 畫出來的,所以這一問就是性質本身,不是旁證(M37)。

**實作**:真的去點那顆 button(`button.click()`),不另寫一份選取邏輯 —— 選取、焦點、關浮層都走 react-day-picker 的同一條路,結果與直接點那一天一模一樣。
游標:日期是 button,手形來自 `../../styles/base.css`「`button:not(:disabled), [role="button"]:not(:disabled) { cursor: pointer; }`」;
縫與角裡點得到時,格陣掛 `data-gap-confirms`,`month_grid` 的 `data-[gap-confirms]:cursor-pointer` 讓縫(`<table>`)與角(`<td>` 繼承)同為手形。
游標與點擊用同一支判斷(`gapConfirmTarget`),指標每移一步重算一次(框是 React 狀態、慢一幀才畫上;鍵盤也可能把框移走)。

**只算滑鼠**(AI 工程判斷;user 的討論與 R21 實測都只涵蓋滑鼠):觸控沒有「滑過」,框停在上一次點的那一天,不是手指現在碰到的位置 ——
手指點在 5/17 的角卻選到 5/10 是錯的。所以觸控 / 觸控筆點在縫或角裡維持原樣(沒反應)。

**鍵盤不變**:本節只動滑鼠。方向鍵、Enter / Space、焦點框、預覽跟著焦點走,全部照舊。

**世界級**(2026-09-26 R21 實測 + 釘版原始碼):

| 系統 | 縫與角裡的預覽 | 在那裡點下去 | 一手出處 |
|---|---|---|---|
| MUI X DateRangeCalendar v9.14.0 | 維持上一天(只在離開月份容器時清) | 沒反應 | [`DateRangeCalendar.tsx#L481-L486`](https://github.com/mui/mui-x/blob/c83b3dd6996f6913947b1be3e5d47655153ced60/packages/x-date-pickers-pro/src/DateRangeCalendar/DateRangeCalendar.tsx#L481-L486) `onMouseLeave: () => setRangePreviewDay(null),` |
| Chakra UI DatePicker(Zag 1.43.3) | 維持上一天(只在離開表格時清) | 沒反應 | [`date-picker.connect.ts#L546-L548`](https://github.com/chakra-ui/zag/blob/46f88c089c1dbb0fc681b31172dc5eb8a07eef0d/packages/machines/date-picker/src/date-picker.connect.ts#L546-L548) `onPointerLeave() { send({ type: "TABLE.POINTER_LEAVE" })`;[`date-picker.machine.ts#L516-L519`](https://github.com/chakra-ui/zag/blob/46f88c089c1dbb0fc681b31172dc5eb8a07eef0d/packages/machines/date-picker/src/date-picker.machine.ts#L516-L519) `actions: ["clearHoveredDate"],` |
| React Aria RangeCalendar | 維持上一天(只有 enter) | **確認正在預覽的區間** | [`useRangeCalendar.ts#L23-L32`](https://github.com/adobe/react-spectrum/blob/4dd44e0f400636a87a9ad4390903e78c5ae6113c/packages/react-aria/src/calendar/useRangeCalendar.ts#L23-L32) 預設 `select`:"select the currently hovered range of dates."(該設定的範圍:"Controls the behavior when a pointer is released outside the calendar or a blur occurs mid selection");讓「月曆裡、但不在按鈕上」也算進去的是 [`#L80-L86`](https://github.com/adobe/react-spectrum/blob/4dd44e0f400636a87a9ad4390903e78c5ae6113c/packages/react-aria/src/calendar/useRangeCalendar.ts#L80-L86) 的 `!target.closest('button, [role="button"]')` |
| Ant Design RangePicker 6.6.5 | 沒有縫:整格就是那一天 | 選那一天 | [`panel.ts#L346-L349`](https://github.com/ant-design/ant-design/blob/4a39f54842eade4e565ab336ef6097cd7e723cdd/components/date-picker/style/panel.ts#L346-L349) `borderCollapse: 'collapse',`、[`#L364-L367`](https://github.com/ant-design/ant-design/blob/4a39f54842eade4e565ab336ef6097cd7e723cdd/components/date-picker/style/panel.ts#L364-L367) 整格 `cursor: 'pointer',`;[rc-picker `PanelBody.tsx#L145-L164`](https://github.com/react-component/picker/blob/a975a11f9a959a811b1ecd901e8ff8ae8f0e515b/src/PickerPanel/PanelBody.tsx#L145-L164) 同一個 `<td>` 掛 `onClick` / `onMouseEnter` / `onMouseLeave` |
| **本 DS** | 維持上一天(縫 + 可點日子圓外的角) | 框亮著時 = 點那一天 | 本節 |

沒有一家兩件事都做:「縫與角維持上一天」取 MUI X、Chakra,「縫裡點下去確認」取 React Aria。
Ant 靠「整格都是那一天」達成同樣的「亮了就點得到」,但它能點的方格(36)大於畫出來的方塊(24),正是本 DS 09-24 撤掉的那條路(上方「先前這裡有一條隱形帶」)。
Ant 整格是手形(上表 `#L364-L367`),與本節「點得到的縫與角是手形」同一個道理。

閘:`scripts/datepicker-range-preview.mjs` 的 `corner` 家族(四條角落路線,每步 1px)與 `gapclick` 家族(角、縫各點一次 + 沒有框時的對照面),
兩家各有 `--selftest` 對照組(把「離開圓進到角」改寫成離開格陣 / 攔下縫與角裡的點擊並把游標蓋回 auto → 必須紅)。

### 實測(2026-09-24)

| 斷言 | 結果 |
|---|---|
| 命中 ≡ 可視(圓) | 圓內 2188 點全命中、0 漏;圓外最遠 1.10px(抗鋸齒容差內) |
| 水平跨格 5/20→5/21(30 小步) | 框最少仍有 **17** 格(0 = 縫裡整條框消失) |
| 垂直跨列 5/20→5/27(30 小步) | 框最少仍有 **17** 格 |
| **對照組**:拔掉 `data-day-grid` 錨點 | 兩條跨法都掉到 **0** —— 證明這組數字量得到機制在不在 |
| `scripts/datepicker-range-preview.mjs` | 109 條全過(exit 0);`--selftest` 五個家族全部會紅,含 `crossing` |

**不越出宿主**:第一格的命中左緣 42.5 落在 `month` 的 padding box(左緣 33)之內 9.5px,連 `<table>` 盒都沒出去。
**不蓋鄰居**:相鄰兩格的命中盒水平間隙實測 **0.00px**(相切零重疊)。

**依據不是觸控尺寸建議** —— 本 DS 明確不以「手指要多大才點得到」當命中區的依據
(hit-area-canonical「本 DS 不採納觸控尺寸建議」)。

### 實測(2026-09-26,角 + 縫與角的點擊)

Chromium 單一行程、1280×900;「現行建置」= repo 的 `storybook-static`(已含 D1);「D1 前建置」= 09-25 的建置;「修後」= 本次改動建出的 storybook。

| 斷言 | D1 前建置 | 現行建置 | 修後 |
|---|---|---|---|
| 角落路線(每步 1px,停 5/20)偏上 1/4 格 / 貼上緣 2px / 貼左緣 2px / 斜穿交會處:框縮掉的步數 | 6 / 14 / 14 / 12 | 6 / 14 / 14 / 12 | **0 / 0 / 0 / 0**(淺、深色另以 R21 量具重量,六條路線全 0) |
| 同路線上「停在格子裡、圓外的角」的步數(證明路線真的經過角) | 2 / 10 / 10 / 8 | 2 / 10 / 10 / 8 | 2 / 10 / 10 / 8 |
| 框亮著,在 5/20 右上角點下去 | 沒反應(框早已清掉) | 沒反應(框早已清掉) | 結束日 5/12 → **5/20**、浮層關;游標 `pointer` |
| 框亮著,在 5/20 右邊縫的中點點下去 | 沒反應;游標 `auto` | 沒反應;游標 `auto` | 結束日 → **5/20**、浮層關;游標 `pointer` |
| 沒有框(兩端都空),在某天的角裡點下去 | 沒反應;`auto` | 沒反應;`auto` | 沒反應;`auto`(不變) |
| 慢慢移出 (c):6/13 貼上緣 2px 往右走出浮層 | 一進角框就沒了(格陣最外圈量到 0 格) | 同左 | 最外圈仍有框(48 格)、出去後 0 格 |
| 鍵盤把框移到 5/5 後,滑鼠仍停在 5/20 的角裡點 | —— | —— | 沒反應;游標 `auto`(對照:不按鍵盤 → 選到 5/20) |
| 同上,但滑鼠停的是 5/4(剛好是鍵盤那個框的起點) | —— | —— | 沒反應;游標 `auto` |
| 框亮著,改用手指點同一個角 | —— | —— | 沒反應(對照:滑鼠點 → 選到框著的那一天) |
| `scripts/datepicker-range-preview.mjs` | 12 條紅(新增 10 條 + D1 的 2 條) | 10 條紅(全是新增的) | 136 條全過;`--selftest` 八個家族全部會紅 |
| **對照組**:拔掉 `data-day-grid` 錨點(中線橫向) | —— | —— | 縮掉 4 步(量具看得到閃) |

## Spacing canonical(2026-05-03 v8)

- **內距住在每一張月曆身上,不在根**(2026-09-18 user 裁示,原話:「我覺得真的要做的話,邏輯就是這樣,
  而不是另外加一個 token,反而造成漂移,因為視覺就是要在各種情況營造對稱感吧?」)。
  `month` 帶 `p-[var(--item-px,var(--field-px))]`(md 12),**根不帶內距**。
  為什麼是 `--item-px`:這個浮層掛在欄位上,內容要跟 trigger 的文字落在同一條線 ——
  那正是 `--item-px` 預設取自 `--field-px` 的理由(`../../patterns/element-anatomy/item-anatomy.spec.md`「Token: `--item-px`」)。
  `DatePicker` 的 footer 與右側時間欄的上內距讀**同一個運算式**,所以整個面板的邊是同一個來源。
- **兩張月曆之間不設 gap**,距離由「各自的內距相加」自然形成(md 12 + 12 = **24**)。
  - **所以沒有、也不需要月間距 token** —— 少一個可以漂的東西。
    同日稍早一度改成 `gap-[var(--layout-space-loose)]`,那是「再加一顆要維護的數字」,已撤回。
  - **對稱是結構保證的**:單張與並排長得完全一樣,不靠任何人記得維護某個值。
  - 世界級同款:**Ant Design 就是這個作法**(兩張各自帶左右內距、中間不設 gap),
    且 v4(內距 12 → 間距 24)與 v5(18 → 36)跨大版本維持 1:2,是刻意的比例。
  - ⚠️ **nav 必須跟著內距走**:`button_previous/next` 相對 `month` 的 **padding box** 做 absolute 定位
    (= 盒子最外緣)。內距搬到 `month` 之後不補偏移,chevron 會比日期格往外 12px(2026-09-18 實測確認)。
    兩顆 nav 因此讀同一顆 `--item-px`。
- **最外圈的 border-spacing 必須抵銷**(`month_grid` 帶 `-m-1`)。
  `border-spacing` 的語意是「格與格之間 4px」,但 CSS **連最外圈也各給 4px** ——
  不抵銷的話日期格會落在 12 + 4 = 16,而 chevron 貼著 12,四邊對稱就破了。
  這 4px **從來沒有人決定過**(2026-09-18 查 git 全史:原規格只說「四邊對稱 12px」),是 `border-separate` 的副作用。
  - **同 repo 早有正確先例**:`Carousel` 用每張投影片的 `pl-4` 當間距,容器就用 `-ml-4` 抵掉(`../Carousel/carousel.tsx:202`)。
  - **上游也不外溢**:`react-day-picker` 自己是 `border-collapse: collapse`,其 457 行 `style.css` 裡 `border-spacing` 出現 **0 次**;
    IBM Carbon 的日曆第一格同樣貼齊容器內距(2026-09-18 讀原始碼 + 實測)。
  - **範圍軌道在列的頭尾要夾住**:range 的 `-2px` bridge 是用來跨過格間 4px 縫接鄰格,
    但列的第一格左邊、最後一格右邊沒有鄰格,不夾就會溢出內距(實測 2px)。
    夾在 `month_grid`(`[&_tr>td:first-child]:before:!left-0` / `last-child`)—— 實測 react-day-picker
    **不會**把加在 `classNames.range_*` 的 class 帶到 `<td>`,掛在那裡不會生效。
- **對齊基準是盒,不是圖示**:chevron 是 24px 按鈕、內含 16px 圖示置中,所以**圖示**在 16、**盒**在 12。
  本 DS 一律盒對盒 —— `../../patterns/overlay-surface/overlay-surface.spec.md:116-117`
  「item 的 **padding-box 左緣** = header title 左緣」「**對齊的是列的前緣,不是文字**」、:121「對齊的同樣是**按鈕左緣**」。
  ⚠️ 不要拿 `data-unbounded` 當水平對齊前例:它的負 margin 全庫**只有垂直的 `my-`**(`overlay-surface.tsx:68`)。
- 實測(2026-09-18 修後):裸 DateGrid 四邊 chevron 盒 12 / 日期格 12 / 最後一排到底 12;
  `DatePicker` 面板 chevron 12 = 星期標頭 12 = 日期格 12 = footer 按鈕 12;
  雙月面板 面板邊→第一格 12、最後一格→下一張第一格 **24**、面板寬 490。
- day cell 固定 `h-field-sm w-[var(--field-height-sm)]`(28px @ md / 32px @ lg)
- week header 同寬,`h-field-sm`
- **Cell 之間 gap = 4px(H + V)**:走 table-native `border-separate border-spacing-1`,不用 grid layout(grid 會 break border-spacing)
- **Caption row alignment canonical**:`pt-3 + h-field-xs + mb-3 = 12 + 24 + 12 = 48px`
  - DateGrid month_caption + TimePickerSidePanel header **必走同樣 48px caption row 結構**
  - title text vertical center Y 一致 = 12 + 12 = 24px(from container top)
  - ⚠️ 改 DateGrid `p-3` → 必同步改 `TimePickerSidePanel pt-3`(root 刻意 bottom = 0,見 date-picker.tsx docblock),否則對齊破

**為什麼用 `h-field-sm` 而非固定 `h-9`**:picker grid 在 lg density 下也要跟 Input 系統一起放大,`h-field-sm` 在 md = 28px / lg = 32px。day cell 尺寸雖固定,但**隨 density 縮放**,視覺跟 popup 內其他欄位(Input / Button)保持比例。

## Nav button canonical(2026-05-03 v9)

Prev/Next chevron 用 `<Button variant="text" size="xs" iconOnly>`(DS primitive 消費,不 hand-coded inline-flex)。透過 RDP v9 `components.PreviousMonthButton / NextMonthButton` override(本元件 `navLayout="around"` 下按鈕由 `DayPicker.js` 於首/末月 caption 兩側直渲;無 navLayout 時才走 `Nav.js` — 兩路徑皆消費此 override,`node_modules/react-day-picker/dist/esm/` 證實)。

**Icon 顏色 = Button 預設 `text-foreground`(neutral-9 / 85% 黑)**,**對齊 DS 一致設計語言**(M23):
- Icon-only Button 預設 = neutral-9(本 DS 既有 canonical)
- `fg-muted`(45%)專屬 dismiss / inline action / placeholder(spec.md 既有定義)
- chevron nav 是 functional navigation,不是 dismiss → 不該套 fg-muted 自開新 tier

歷史(2026-05-03):v6-v8 曾以未驗證的「Ant chevron muted」印象覆蓋 DS canonical,已撤回(M23 防再犯)。

⚠️ RDP `PreviousMonthButton` override 必丟 `children`(RDP 把 `<Chevron>` 當 children 傳)否則 double svg(2026-05-03 v8 抓到 bug)。

## Weekday header canonical(2026-05-03 v9)

`text-foreground text-body font-medium`(neutral-9 + 500 weight + body size)。對齊 caption「April 2026」同視覺權重(都屬 calendar header 區),不弱化。撤銷 v3 用 `fg-secondary font-normal` 的 mistake(M23)。

## Range track canonical(2026-05-03 v8)

Range 起訖使用 stadium 端點，讓連續區間有清楚的開始、延伸與結束：
- `range_start` / `range_end` cell pseudo:左 / 右半圓 stadium,向 middle 側外擴 2px bridge gap(class 細節見 tsx `range_start` / `range_end`)
- `range_middle` cell pseudo:滿 cell 高矩形、左右各外擴 2px,無 rounding(class 細節見 tsx)
- pseudo 蓋全 cell + bridge 4px gap → button 圓的 corner triangle 看到 pseudo bg(對齊 button 圓的左/右半弧,無「凸出」)
- `bg-neutral-selected`(semantic = neutral-2)— 對齊 TimePicker 選中項目樣式

---

## 禁止事項

- ❌ **不改視覺 token 為硬色值**(`bg-primary` 必須來自 semantic,不可 `bg-blue-500`)
- ❌ **不用 `.rdp-*` 原生 class 直接樣式化**(繞過本元件 classNames prop 會跨版本斷掉)
- ❌ **不自包 Popover**(DateGrid 是 inline primitive;需要浮層由 consumer 包 Popover,見 DatePicker)
- ❌ **不混用其他 calendar library**(若 DateRange / DateTime 需求出現,擴充本元件 `mode="range"` 或新 prop,不引第二套)
- ❌ **Consumer 不可外加 padding wrapper**(canonical 2026-05-02)— DateGrid 的內距自帶在**每一張月曆**上(2026-09-18 從根搬過去,見上方 Spacing canonical);`<div className="p-2"><DateGrid /></div>` 會造成 popover edge → 第一個 day cell 雙重 padding(8 + 12 = 20px),違反 mindset #2「優先消費既有 SSOT」。直接放 `<DateGrid />` 在 Popover/parent 內即可。Hook `check_pattern_invariants.sh` C.3(P0 BLOCK,PRIMITIVES_REGEX 含 DateGrid)機械攔截

---

## A11y 預設

react-day-picker v9 自動處理:
- **鍵盤**：ArrowLeft/Right 切日,ArrowUp/Down 切週,Shift+ArrowLeft/Right 切月、Shift+ArrowUp/Down 切年,PageUp/Down 切月、Shift+PageUp/Down 切年,Home/End 切週首尾
- **ARIA**：`role="grid"` + 日格 `role="gridcell" aria-selected`
- **Focus**：`autoFocus` prop 自動 focus 到選中日(或今天)
- **Locale**：`locale` prop 控制週首日、星期標頭語言

**DS 自訂部分**:day button 的焦點框由本元件 classNames 覆寫為 DS 焦點幾何(`focus-visible:focus-ring-inset`,填色格 `focus-ring-inset-emphasis`,見上方 cell state 表「focus-visible」列;非 RDP 預設樣式。2026-09-23 前本句寫的 `focus-visible:ring-2 ring-ring` 是 2026-09-07 焦點幾何收斂前的舊寫法);SR 文案經 RDP `labels` API 提供中文 default(nav「上一個月 / 下一個月」、day / weekday / grid 等全繁中,對齊 2026-07-04 全庫 SR label 中文 canonical),consumer 傳 `labels` 可逐鍵覆寫(i18n),不在 components override 內 hardcode `aria-label`(會蓋死覆寫通道)。其餘 consumer 無需額外處理,保留 react-day-picker API 即可。

---

## shadcn passthrough 例外說明

DateGrid 本元件是**對 `react-day-picker` 的 `<DayPicker>` 元件薄包裝**,用於橋接 DS token(classNames 覆寫 + components 注入自訂 `PreviousMonthButton` / `NextMonthButton`)。

**ref 處理**:採 **DS 統一 `React.forwardRef` 慣例**(`forwardRef<HTMLDivElement, DateGridProps>`),但因 react-day-picker v9 的 `DayPicker` 內部是多 `<div>` 結構、未對外 forward ref 到單一 DOM 節點,故 **ref 簽名保留但不附著**(真要取 DOM 由 consumer 包一層 wrapper)。保留 forwardRef 簽名是為了跟 Radix / shadcn 其餘元件的一致設計語言對齊,即使 ref 不附著。

**props passthrough**:`DateGridProps = React.ComponentProps<typeof DayPicker>`,經 `{...props}` 直接 spread 至 `DayPicker`(declarative API:selected / onSelect / mode / classNames / components 等)。

`displayName = 'DateGrid'` 讓 React DevTools / Storybook 辨識。

**何時應改 ref 附著**:若未來 react-day-picker 升級提供單節點 `ref` prop,或我們決定包一層自有 DOM 容器(如加 footer action buttons),再把 ref 接到該容器上。

---

## 邊界案例

- **Disabled day**:`disabled` prop 走 react-day-picker matcher;disabled cell 視覺 `text-fg-disabled`(M24)、`cursor-not-allowed`、click 不觸發 onSelect、鍵盤導覽自動 skip。
- **Loading(server-rendered grid)**:DateGrid 為 sync render(date math 在 client),非 async surface。consumer 若需 async disabled-dates fetch(如後端 holiday list),應先 disable trigger 直到 fetch 完成,DateGrid 開啟後立即 ready。
- **Empty(全 disabled days)**:極端場景(所有日期都被 disabled matcher 命中),DateGrid 渲完整 grid 但全部 cell 為 disabled state,鍵盤焦點停留無導覽目標(react-day-picker v9 內建)。Enter / Space 在 disabled cell 上無動作不報錯(RDP DayButton 對 disabled day 渲染 native `disabled`,focus target 時改掛 `aria-disabled`),Tab 走 roving tabIndex 整個 grid 只停一格。
- **Dark mode**:走 semantic token(primary / neutral / fg-muted)自動 adapt。
- **Density**:DateGrid day cell 走 `h-field-sm w-[var(--field-height-sm)]`,**隨 density 縮放**(md = 28×28 / lg = 32×32,token `--field-height-sm` 在 `[data-density="lg"]` override 為 `2rem`),跟 popup 內 Input / Button 等 field 家族一起放大保持比例(見 L128 + L120)。grid 寬度為 intrinsic(7 × cell + 4px gap + `p-3`),lg 下整體變寬;DateGrid 無內部 overflow / responsive 縮排機制,容器(Popover / parent)以內容寬呈現。

---

## 相關

- `../DatePicker/date-picker.spec.md` — **本元件 consumer**:DatePicker 消費 DateGrid 作為選日 popup
- `../../tokens/color/color.spec.md` — semantic token 來源（primary / neutral / fg-muted 等）
- react-day-picker 官方文件 — `https://react-day-picker.js.org`

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `calendar.spec.md`
- `date-picker.spec.md`
