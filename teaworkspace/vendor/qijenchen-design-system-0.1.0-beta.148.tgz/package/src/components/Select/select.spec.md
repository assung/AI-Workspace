---
component: Select
family: 4
variants: {}
sizes: {}
traits:
  - hasInteractiveStates
  - isInputLike
benchmark:
  - Radix Select primitive: github.com/radix-ui/primitives/tree/main/packages/react/select
  - Ant Design Select: github.com/ant-design/ant-design/tree/master/components/select
  - MUI Select: github.com/mui/material-ui/tree/master/packages/mui-material/src/Select
  - Polaris Select: github.com/Shopify/polaris/tree/main/polaris-react/src/components/Select
---

<!-- @spec-budget-exception: SSOT-heavy 例外(`AGENTS.md`「行數預算」的 foundational SSOT 例外 ≤800-1200)— 本檔持有跨元件 SSOT:「與 RadioGroup 的分界」(~40 行)+ 3 筆拍板記錄(2026-07-13 D2 hidden-input mirror / 2026-05-21 D3 dual-mode / 2026-06-12 R2 open-pair 例外);2026-07-14 knowledge-prune P2 結論「殘餘超標內容全是 canonical,再砍必動 meaning」(該次掃描明細留在 provider home 的 log,屬歷史 provenance,不是本例外的 authority —— 例外成立與否只看本句陳述的理由)。 -->

# Select 設計原則

## 定位

> 寬度軸:`width="fill|hug"`(default fill;hug = 依內容收縮,detail pane inline metadata 用)— SSOT → `Field/field-controls.spec.md`「寬度軸(width: fill / hug)」。

Select 是**單選下拉的表單 control**——從 3+ 選項中挑恰好一個，選項收在 dropdown 內展開。**裝置自適應雙路徑**:觸控裝置(`pointer: coarse`)走原生 `<select>` 取平台原生 picker;桌機走自建 combobox(`role="combobox"` + Radix Popover + Command 渲染 SelectMenu)。詳下方「實作:裝置自適應雙路徑」段。

共用規則見 `field-controls.spec.md`。本文件只記錄 Select 特有的原則。

**Layout Family**：本元件是 `components/Field/field-controls.spec.md` 所擁有的 **Family 4（Field control layout）** 消費者。結構繼承其 `fieldWrapperStyles + [startIcon?] [<editable>] [endAction?]` 規格,視覺對齊 Family 1（Menu item）讓 SelectMenu trigger + options 連續一致。

## 實作：裝置自適應雙路徑

`Select` public component 在 render 時用 `useIsTouchDevice()`（內部 `matchMedia('(pointer: coarse)')`）分流（`select.tsx`）：

| 裝置 | 路徑 | 實作 | 為什麼 |
|---|---|---|---|
| 觸控（`pointer: coarse`，手機 / 平板）| `NativeSelect` | 真原生 `<select>` + CSS 客製 trigger | 行動裝置的原生 picker（iOS wheel / Android dialog）是平台最佳 a11y + 操作體驗，自建選單無法取代 |
| 桌機（精確指標）| `CustomSelect` | 自建 combobox（`role="combobox"` + Radix Popover + Command + SelectMenu）| 桌機需可控渲染：搜尋輸入、選項內頭像 / 描述 / 分組、自訂鍵盤導覽——原生 `<select>` 都做不到 |

**此分流是「裝置」軸，與 `searchable` 正交**：`searchable` 只決定桌機 combobox 的 trigger 要不要顯搜尋輸入框，**不**決定走原生還是 combobox。一個不可搜尋的桌機 Select 仍是完整自建 combobox（可捲動 / 點選，只是沒搜尋框）。

### 原生表單參與(desktop hidden input mirror,2026-07-13 D2 拍板)

`name` / `required` / `form` 在型別 allowlist 內(`SelectProps` 以 `Pick<SelectHTMLAttributes>` 顯式允收,2026-07-14 API 策展 D),兩路徑提交語義必須一致(歷史上桌機靜默丟棄 name、mobile 生效 — 此不對稱從未被拍板,屬 footgun,2026-07-13 修):

| 路徑 | 機制 |
|---|---|
| 觸控(NativeSelect)| 真原生 `<select>`,`name` / `required` / `form` 直接生效 |
| 桌機(CustomSelect)| **visually-hidden `<input>` 鏡像**(`aria-hidden` + `tabIndex={-1}` + opacity-0,絕對定位於 trigger 內):`value` 單向鏡射受控 state,`name` / `form` forward → 裸 `<form>` submit 收得到值;顯式 `required` prop forward → 原生 required 擋 submit |

**設計規則**:

- **型別 = allowlist,不 extends 全開(2026-07-14 API 策展 D,user 拍板「全部收窄」)**:`SelectProps` 只 `Pick<>` 兩路徑皆有實作出口的原生屬性(`id`/`className`/`style`/`name`/`form`/`required`/`disabled`/`onFocus`/`onBlur`/`onKeyDown`/`aria-label`/`aria-describedby`/`aria-errormessage` + mobile-only `autoFocus`/`autoComplete` + `data-*` passthrough);「型別承諾 ≠ 實作出口」者(`multiple`/`aria-labelledby`/`tabIndex` 等)不進型別,需要時先接線(兩路徑等效)再入表 — 完整盤點依據見 `select.tsx` SelectProps docblock
- **單向 projection,非第二 SSOT(M17)**:mirror 的 value 恆來自既有 canonical state(`useControllable`);唯一寫回通道是瀏覽器 autofill,且僅在 match 既有非 disabled option 時經 canonical setter 生效(MUI SelectInput 同款 guard)
- **空值 = `value=''`**:無選擇時送空字串,**不** default 第一項——採 MUI 式**單一 hidden input**而非 Radix BubbleSelect 完整 `<select>` option tree(後者無空 option 時 default 第一項,radix-ui/primitives issue #3521 documented footgun;2026-07-13 codex 辯論 verdict)
- **原生 required 僅收顯式 `required` prop**(裸表單 opt-in):`<Field required>` 的 context required 續走 `aria-required` + `useFormValidation`(RHF)方法論(`form-validation.spec.md` 規則 1-9),不對既有 Field+RHF consumer 注入瀏覽器原生 bubble
- **a11y 不變**:mirror `aria-hidden` + 不入 Tab 序,semantics 仍由 `role="combobox"` trigger own;顯式 `required` prop 同步進 trigger `aria-required`(對齊 mobile 原生 `<select required>` 播報)
- **副作用(升級)**:`useFormValidation` 規則 8(focus-first-error 以 DOM name 定位)桌機 Select 現在可被定位——focus 落 mirror → trigger `focus-within` 顯示 focus 邊框,不再落入 v1 邊界 (b)「控件沒有帶 name 的元素就不移焦點」那一支

**世界級對照**:MUI Select 非原生模式同步 opacity-0 hidden input 攜 `name`/`required`(官方測試涵蓋 required 阻止提交 + FormData 值,[github.com/mui/material-ui Select.test.js](https://github.com/mui/material-ui/blob/master/packages/mui-material/src/Select/Select.test.js))/ React Spectrum [HiddenSelect](https://github.com/adobe/react-spectrum/blob/main/packages/%40react-aria/select/src/HiddenSelect.tsx) / Headless UI Listbox `name` → [hidden input kept in sync](https://headlessui.com/react/listbox#using-with-html-forms)。Ant 走純 Form.Item(React state)派;本 DS 因型別已承諾 `name`/`form`/`required`,「同一 public API 依裝置改變提交語義」比補 projection 更危險(codex verdict),故補鏡像。

---

## Controlled / Uncontrolled dual-mode(Dim 26,2026-05-21 D3 audit ship)

本元件支援 **dual-mode**:consumer 可選 controlled OR uncontrolled,對齊 React `<input>` / Radix Select / shadcn Select 共識。**互斥規則**:同時傳 `value` + `defaultValue` 走 controlled(value 勝),`defaultValue` 僅 first-mount 用。

### Controlled 模式(consumer 自管 state)

傳 `value` + `onChange`(如 `<Select value={country} onChange={setCountry}>`),Select **不**自管 state。**何時用**:Form library(react-hook-form / Formik)/ Redux / 跨元件 sync / server-state driven。

### Uncontrolled 模式(Select 自管 state)

不傳 `value`(可傳 `defaultValue` 設初始值,如 `<Select defaultValue="tw" onChange={...}>`),Select 內部自管,變更時 fire `onChange` 通知 consumer。**何時用**:純展示 / 一次性表單 submit / consumer 不需要 read 當前值。

### 為什麼支援 dual-mode(非 controlled-only)

- **React canonical**:`<input>` / `<select>` 原生兩模式並存,Radix / shadcn / MUI / Ant 共識 form-like primitive 必支援 dual-mode
- **Consumer ergonomics**:簡單場景不該強制管 state(prototype / 一次性 form / a11y testing)
- **互斥規則消除 ambiguity**:`value !== undefined` 為 controlled signal,decisive 不模糊

### 歷史

原刻意 controlled-only(「內部狀態複雜易 race」);**2026-05-21 D3 audit** per Dim 26 verify + user 拍板(「決策三照妳建議」)補 `defaultValue` + 互斥 signal — NativeSelect / CustomSelect 統一走既有 `useControllable` hook,`valueProp !== undefined` 為 controlled signal(M17 SSOT)。

### Open-pair 例外:open 軸維持 uncontrolled-only(2026-06-12 deep-audit R2 補)

value 軸 dual-mode,open 軸**刻意只有** `defaultOpen`(初始開)+ `onOpenChange`(通知 callback),無 controlled `open` prop:

- **已知需求只要「初始開 + 知道何時關」**:(1) 視覺快照 — Storybook OpenSnapshot / visual-audit(M15)需「免互動即開」state,`defaultOpen` 一行達成;(2) DataTable cell-as-input(`DataTable/cell-registry.tsx`)— click → 1-step 開選單靠 `defaultOpen`,dismiss 後 `onOpenChange(false)` → cell exit edit mode
- **受控成本高**:open 是內部 interaction state machine 的一環 — 關閉自動清 search(`../SelectMenu/select-menu.tsx`「浮層關閉 → 清空搜尋關鍵字」,經 `onSearchChange('')` 叫本元件清;規則 `../SelectMenu/select-menu.spec.md`「搜尋關鍵字何時保留、何時清空」)/ searchable trigger 在 open 時切 input 顯示模式 / Enter / Space / ArrowDown opener + Esc dismiss 全是內部 intent。controlled `open` 要 consumer 忠實 echo 每一條,漏接任一 → 卡開 / 卡關 / search 殘留
- **世界級對照**:Radix Popover([radix-ui.com/primitives/docs/components/popover](https://www.radix-ui.com/primitives/docs/components/popover))/ Ant Select([ant.design/components/select](https://ant.design/components/select))/ MUI Select([mui.com/material-ui/api/select](https://mui.com/material-ui/api/select/))皆提供 controlled `open` — 它們是泛用 primitive / library,必須支援任意 orchestration;本 DS 是 opinionated form control,無真實 consumer 需求前不為「可能性」付受控成本(Rule-of-3)

**若未來要開 controlled open**:同 value 軸走既有 `useControllable` hook(M17 SSOT)+ 測 controlled↔uncontrolled switch,屬 major API 擴充,目前不在 scope。

---

## 何時用

- **表單中節省垂直空間**：create user 的 role、profile settings 的 timezone、product form 的 category
- **Toolbar / filter 的選擇**：table 上方的 category filter、sort by、狀態篩選
- **Table cell 的 inline edit**：Jira-style task 的 status / priority / assignee（見下文「即時 vs on-submit」）
- **選項 label 自帶語意**：國家、類別、時區——使用者看 label 就知道要選什麼，不需要額外 description
- **選項 10+ 且不需搜尋**：時區、國家這類使用者熟悉的清單，靠捲動瀏覽即可定位（type-to-jump 逐字定位只有手機原生 `<select>` 才有；桌機是自建 combobox，非搜尋模式無逐字定位，選項偏多時建議直接開 searchable）

## 何時不用

| 場景 | 改用 | 原因 |
|------|------|------|
| 2-5 個選項且選擇是「決策節點」 | `RadioGroup` | 使用者需要看到全部選項比較——見下「與 RadioGroup 的分界」 |
| 2-5 個緊湊切換（filter / view mode） | `SegmentedControl` | 更 compact，跟 Button / Input 並排不違和。詳見 `segmented-control.spec.md` |
| 選項需要多行描述或圖文並列 | `RadioGroup` | Select option 是單行純文字，無法承載複雜排版 |
| 多選 | `Combobox` | Select 永遠單選 |
| 布林切換（on / off） | `Switch` | 布林不需要「選一個」的心智模型 |

---

## 與 RadioGroup 的分界

兩者都能「從 N 個選項中挑一個」，在 2-5 個選項的範圍內常被誤用互換。判斷**不是數量**，而是以下三個角度——**任何一個明確傾向哪邊就選哪邊**：

### 1. Progressive disclosure 成本

- **Select**：選項隱藏，使用者多一次點擊才看到。適合「label 本身就夠清楚」的場景（國家、類別、角色）——使用者已經知道自己要選什麼，只是需要一個 picker
- **RadioGroup**：全部選項一次可見。適合「使用者需要看完所有選項才能決定」——付款方式、訂閱方案、票種，選擇本身是決策動作

### 2. 視覺重量

- **Select**：O(1)——永遠佔 field height 一格空間，無論 3 個或 300 個選項
- **RadioGroup**：O(n)——每個選項各佔一行（block 模式），總高度隨選項數線性增加。超過 5 個 option 會開始主導 form 的視覺節奏

### 3. 評估深度

- **Select**：使用者已經知道要選什麼，label 只是確認。例：我知道我要選「Electronics」，dropdown 只是找到它的工具
- **RadioGroup**：使用者需要仔細讀每個選項的 label（有時連帶 description 比較價格 / 權限 / 時長），評估才做選擇

### Fallback heuristic

- **表單中要節省垂直空間 / label 自帶語意 / 使用者熟悉選項 → Select**
- **選擇本身是決策節點（使用者需要對比評估） → RadioGroup**
- **灰色地帶時，問：「使用者看一眼 label 就能下決定嗎？」** 能 → Select；不能、需要閱讀 → RadioGroup

### 情境對照表

| 場景 | 選哪個 | 原因 |
|------|-------|------|
| 國家 / 時區選擇 | Select（可配 searchable） | label 自帶語意、使用者熟悉、選項數多 |
| Table cell 的 status 切換 | Select | 空間受限、使用者熟悉 status 名 |
| 類別（Electronics / Furniture / Food）| Select 或 RadioGroup | 看容器空間；3-4 個且在 form 中傾向 RadioGroup |
| **付款方式**（信用卡 / 轉帳 / 現金）| RadioGroup | 決策節點、通常連帶手續費或處理時間 description |
| **訂閱方案**（Basic / Pro / Enterprise）| RadioGroup | 決策節點、通常連帶價格比較與 feature list |
| **票種**（成人 / 兒童 / 敬老）| RadioGroup | 決策節點、通常連帶價格 |
| 使用者角色（Admin / Editor / Viewer）| Select 或 RadioGroup | 新手用 RadioGroup（要解釋權限）、熟悉使用者 Select |
| 時區選擇 | Select + searchable | 選項 > 100 個、使用者記得時區名 |

**本節是 Select vs RadioGroup 的 SSOT**，`radio-group.spec.md` 和 `checkbox.spec.md` 點回本節，不重複書寫。

---

## 即時 vs on-submit

Select 的值套用時機是**由 onChange handler 的副作用決定**，不是 Select 本身的屬性——兩種場景都是正當用法：

### 即時套用（change → API）

選值一變就直接觸發外部動作，不經 form submit：

- **Jira-style view/edit**：task 的 status / priority / assignee 欄位，改了立刻寫回 DB
- **篩選器**：table 上方的 category / status filter，改了立刻篩 table
- **即時設定**：notification preference、theme dropdown
- **URL param 綁定**：改 value 立刻 push URL（deep-linkable）

這類場景的 onChange 通常呼叫 mutation / API / setState 更新父層。**沒有「取消」的概念**——改了就是改了。

### 隨 form 送出（change → local state → submit）

選值先寫進 local state，等 form submit 才套用：

- **建立 / 編輯表單**：create project 裡的 type、edit user 的 role
- **對話框設定**：dialog 內的選項，按確認才生效
- **精靈流程**：多步驟表單的中間選擇

這類場景 onChange 只更新 React state，直到 submit handler 才送出。**有「取消」可回復**。

### 設計規則

- 即時場景：用 `aria-label` 或旁邊的 label 明確告知「這個改了會立刻套用」
- on-submit 場景：搭配 `<Field>` 容器 + submit button，使用者清楚哪個動作觸發儲存
- **不要讓使用者搞不清楚是哪種**——這是 DS 最常見的信任破壞點

---

## Searchable 開啟判斷

`searchable` 啟用後 field 變 input，打字即篩選 options。判斷依以下順序：

**開啟時已選值怎麼顯示**(指標,不在這裡重寫):已選值讓位給搜尋輸入框 —— 打開還沒打字時,值以灰色提示疊在同一個位置(讀屏略過),一打字就消失,字從 `--field-px` 那條線開始,字刪光又回來(`select.tsx` `CustomSelectTriggerContent` 的 `showSelectedOverlay`)。規則住 `../PeoplePicker/people-picker.spec.md` §B「open + inline-search、選 1 人」列與 §E 提示字公式(:194),Combobox 只選「不限」× 欄位內搜尋同一條(`../SelectMenu/select-menu-unrestricted.spec.md`「欄位顯示」)。

**searchable 開關前後欄寬不變(2026-10-13,待辦 K7)**:打開時框裡換成搜尋輸入框,那一格的寬 = 關著時那一段值的寬(值的圖示 / `selectedItemRenderer` / Tag / 提示字,同一支函式畫的看不見的量尺)與打的字取大 —— 依內容寬(`width="hug"`)的欄位打開前後欄寬一樣,打的字比值寬才跟著長;有起始圖示時圖示與輸入處的間距同關著時(欄位外框的 gap)。修前打開就撐成原生輸入框的固有寬(PeoplePicker 單人依內容寬 151 → 204px),有起始圖示時字往左跳 8px。規則 `../Field/field-controls.spec.md`「寬度軸」;閘 `scripts/searchable-field-keys-invariant.mjs` K7 兩列。

**searchable × tag 模式的內距(2026-09-15 user 裁定)**:searchable 是單選、關閉時框裡仍是「輸入」語意,已選的 Tag 跟其他文字選項一樣貼 `--field-px`(12px),**不套** `fieldTagInsetX` 的四邊等距公式(那是非 searchable tag 模式與 Combobox 的);開啟時同一個框放搜尋輸入,套了會在開關之間跳 9px。code:`select.tsx` `!searchable && tagPadding[size]`。

### 主判準：label 性質

- ✅ **需要 searchable**：label 是獨特關鍵字 / 代碼 / 非自然語言，使用者**無法靠捲動快速定位**
  - 產品代碼：`SKU-4837`、`ORDER-2024-001`
  - 郵遞區號、機場代碼（TPE / NRT / JFK）
  - 使用者 ID、專案 slug、ticket number
  - 中文姓名（同姓大量集中，字母跳不動）
- ❌ **不需要 searchable**：label 是流暢自然語言、品類名稱，且選項數量在捲動可輕鬆掃完的範圍
  - `Electronics`、`Furniture`、`Food`
  - `Draft` / `In progress` / `Done`
  - 國家英文名（清單不長時捲動即可；注意桌機自建 combobox 無逐字定位，國家這類長清單仍建議開 searchable）

### 次要啟發：選項數量

數量只是啟發，主判準永遠是 label 性質。

- **< 10** + 自然語言 label → 不開
- **10-50** → 往搜尋傾斜（但仍看 label 性質）
- **> 50** → 幾乎必開

### 為什麼不用純數量 threshold

- 100 個 `a` / `b` / `c` / ... 因 label 有序好掃，捲動定位心智成本低（手機原生 `<select>` 另有 type-to-jump 加成；桌機若清單真的很長仍可開 searchable）
- 5 個 `SKU-4837` / `SKU-8210` / ... 需要搜尋（使用者記不起哪個代碼對應哪個產品）

純量化規則會誤判這兩端。label 性質是唯一可靠的主判準。

### 建立新選項（`creatable`，2026-07-18 決策11）

- `creatable` **需搭配 `searchable`**——搜尋字串非空且無完全同名既有選項時,dropdown 底部出現 create row(`Plus` icon + `createLabel`,預設「直接使用「{query}」」),點擊觸發 `onCreate(query)`。
- **邏輯 / 顯示 / 互動 SSOT 住在 `SelectMenu`**(與 `Combobox.creatable` 同一底層):Select 的 trigger 內嵌搜尋 input 以**受控 `search`** 驅動 SelectMenu 的 create-row 顯隱(`SelectMenu.search` prop,選配受控;不傳 = 內部 uncontrolled,既有 consumer 零影響)。
- `onCreate` 由 consumer 實作(通常:加進 options + 選取新值);create row 選取後 SelectMenu 清 search(受控時回呼 `onSearchChange`;同表「選建立列」那一列,`../SelectMenu/select-menu.spec.md`「搜尋關鍵字何時保留、何時清空」)。
- **非 searchable 時無 create 通道**(沒有輸入處);`creatable` 單獨傳無效。
- 何時用:label 是使用者自訂的自由文字集合(標籤 / 分類 / 專案名),清單非窮舉、允許擴充。何時不用:固定 enum(狀態 / 角色 / 國家)——不該讓使用者新增。

---

## 顯示模式（`display` prop）

| 模式 | 何時使用 |
|------|---------|
| `plain`（預設） | 選項語意靠文字表達（類別、國家、角色） |
| `tag` | 選項有色彩語意，顏色加速掃視（狀態：紅黃綠） |

**命名 rationale**(2026-05-01 從 `'text'` 改 `'plain'`):跨元件 prop value 衝突防避 — `Button variant="text"` 表「無 chrome 文字按鈕」,跟 Select.display 的「純文字呈現」是兩個不同概念,共用 `'text'` 字面值會造成 consumer 認知衝突(命名三 test 第 3 條)。改 `'plain'` 後語意專屬:plain = 樸素文字呈現,對立 tag = 用 Tag 元件呈現。

**`selectedItemRenderer` 優先於兩種顯示模式**(2026-07-08 A 案回歸修正):設定時已選值改渲 consumer renderer 輸出(status icon+text / PersonDisplay 等),且 **edit / view / readonly / disabled 4 mode 共享同一 renderer**(`field-controls.spec.md` 共享 contract (a),禁 edit-only)。renderer 輸出屬「值內容」— `mode="view"` 照常渲染(無 chrome 無 chevron);與 affordance(chevron/outline)分層見 `field.spec.md` L6。

**雙分支同 SSOT(2026-08-05 修)**:觸控 NativeSelect edit 有值時同樣渲 renderer 輸出為可見層(native `<select>` 沿 tag 模式既有透明 overlay pattern,tap 開原生 picker;空值走原生 placeholder)——先前 native edit 只顯 option 純文字,PeoplePicker 手機單人因此無 avatar = touch 分支漏接 display 層(canonical 違反)。**Root invariant:display-layer renderer props 必雙分支(Custom/Native)同消費;新增 renderer-affecting prop 必同步 NativeSelect。**

### plain 模式

- 桌面使用 custom trigger + SelectMenu；觸控裝置使用 NativeSelect 的純文字 + ChevronDown(`selectedItemRenderer` 設定時觸控同渲 renderer 輸出,見「雙分支同 SSOT」段)
- **Icon-binding 矩陣**(icon kind canonical,2026-05-09 clarified):

| Icon 角色 | Prop | 語意 | 色彩 | 優先序 |
|---|---|---|---|---|
| **Indicator icon**(field-level leading hint)| `startIcon` | 提示 field 類型 / 屬性(`Mail` / `Globe` / `Lock` / `Flag`),與選中值無關 | muted(對齊 `Input.startIcon` search-icon pattern)| 設定時恆顯,優先 |
| **Value icon**(代表選中項)| `option.icon`(per-option)| 隨 selected option 變動 | fg-default(對齊 `MenuItem.startIcon` 跨元件 SSOT)| `startIcon` unset 時 fallback |

兩 prop 不互斥——同時設定時 `startIcon` 勝(渲染分支見 `select.tsx`)。

### tag 模式

- 桌面使用 Tag 呈現選中值並由 custom trigger 開啟 SelectMenu；觸控裝置才在 Tag 上疊隱藏的 native select overlay
- 觸控 overlay 路徑的 Tag 設為 `pointer-events-none`，點擊穿透到底層 select
- edit 模式：Tag + ChevronDown + 可選 clear
- readonly：Tag 顯示，**ChevronDown 不顯示**（純值、不可開選單）；disabled：Tag 顯示 + **ChevronDown 保留**（類型身份 indicator，fg-disabled），不可開選單

---

## 表單接線(`useFormValidation`,2026-10-01)

`onBlur` 以**觸發欄位 + 它的清單浮層 = 同一個欄位**判定(`../../lib/composite-field-focus.ts`,待辦總帳 N83):開啟時焦點搬進浮層(不可搜尋 → cmdk 殼;可搜尋 → 欄位內搜尋框)不算離開,`useFormValidation` 規則 2 的驗證只在真的離開時跑一次 —— 修前一開清單,必填錯誤就長出來(實測)。`onKeyDown` consumer 先跑(dim-9 既有);規則 4 的 Esc 回復只在那一下歸欄位時動作:清單開著按 Esc 只關清單、值不動(`../../lib/overlay-escape.ts`;`ds-canonical/references/keyboard-model-canonical.md`「焦點所在的控件自己那一層也算一層」)。

## Clearable

`clearable` 在有值時顯示 clear 按鈕。

- Clear 按鈕在 ChevronDown 左側
- 清除後回到 placeholder 狀態;可搜尋時打到一半的關鍵字一起清(2026-09-30,規則與三家查證住 `../SelectMenu/select-menu.spec.md`「搜尋關鍵字何時保留、何時清空」一鍵清空列)
- 只在 edit 模式顯示
- 清單開著時按它,反白回第一列(同打開一個空欄位;2026-10-07 待辦總帳 K2,規則住 `../SelectMenu/select-menu.spec.md`「搜尋關鍵字何時保留、何時清空」一鍵清空之後反白那一條)
- `searchable` + `clearable`:關鍵字空白時按 `Backspace` = 按這顆 ×(清值、反白回第一列、讀屏念「已移除『X』」);**沒開 clearable 時 `Backspace` 不清值** —— 必須有值的欄位 Backspace 不能做出 × 做不到的事(下方「何時開 clearable」)。規則與哪幾項是 AI 推導住 `../SelectMenu/select-menu.spec.md`「A11y 預設」Keyboard `Backspace` 列(2026-10-07 待辦總帳 K1)
- **清除後焦點**:按鈕隨清除卸載 —— 焦點在它身上(鍵盤按 `Enter` / 空白、Chrome 滑鼠按下)時交回觸發欄位(原生 `<select>` 路徑交回那顆 `<select>`),不掉到 `body`;可搜尋而且浮層開著、欄位內搜尋框握著焦點時按它,焦點留在搜尋框。交接只有一支 `../Field/field-wrapper.tsx` `keepFieldFocusBeforeUnmount`(Combobox / TimePicker / DatePicker 同用);四種搜尋框位置的焦點表住 `../SelectMenu/select-menu.spec.md`「A11y 預設」Focus 段。2026-09-30 前:鍵盤按「清除選取」後焦點落在 `body`(實測,PeoplePicker 單人「一鍵清空」)。

**何時開 clearable**：
- 「無選擇」是有效狀態（選填欄位、可清除的 filter）→ 開
- 必須有選擇（每個項目都必須有 status）→ 不開

---

## 常見誤解

**誤解**：「Select 只用於表單送出，即時套用應該用別的元件」。
**事實**：Select 的表單送出與即時套用都是正當用法。Jira、Linear、Notion 的 inline status dropdown 都是 Select + 即時 onChange。關鍵是 onChange 的副作用清楚，不是 Select 本身。

**誤解**：「3-5 個選項一定要用 RadioGroup」。
**事實**：看容器與決策性質，不看數量。Toolbar 的 3 個 filter 必須是 Select / SegmentedControl（RadioGroup 不符 toolbar 視覺）；form 中 3 個付款方式用 RadioGroup（決策節點）。見「與 RadioGroup 的分界」。

**誤解**：「選項超過 N 個一定要開 searchable」。
**事實**：主判準是 label 性質，不是數量。見「Searchable 開啟判斷」。

---

## Loading(2026-09-09 user 拍板:兩個字、兩件事)

| Prop | 意思 | 指示 | SSOT |
|---|---|---|---|
| `loading?: boolean` | **這個值**在讀取 / 驗證 / 儲存(與 Input `loading` 同義) | 觸發點右側、ChevronDown 左邊放列圖示尺寸的 `CircularProgress`(`select.tsx` `chevronEl`;native 分支同;`iconSize` sm/md 16 / lg 20)+ 觸發點 `aria-busy`;選單照常可開可選、與選項多寡無關 | `../Field/field-controls.spec.md`「Loading state」 |
| `optionsLoading?: boolean` | **選項清單**在抓(2026-09-09 改名自 `loading`) | forward 給 SelectMenu:只在選單內,沒有可顯示選項時一列「載入選項中」訊息列 + listbox `aria-busy`;**觸發點不轉圈**。本機過濾已有選項時保留、遠端搜尋抓資料中舊選項不顯示 | `../SelectMenu/select-menu.spec.md`「Loading」 |

歷史:2026-05-15 audit B 補 `loading` → 2026-07-04 Q3「不清空 stale options」→ 2026-09-08 兩處轉圈 → **2026-09-09 拆成兩個 prop、選項載入指示只在選單內**(同一時刻兩顆轉圈的病根是同字兩義,見 select-menu.spec.md「Loading」的世界級對照)。

**遠端搜尋**:`filterOption?: boolean`(預設 true)與 `onSearchChange?: (value: string) => void`(2026-09-08 user 拍板「併」):搜尋在觸發點時本機過濾由 SelectMenu 依受控 `search` 做(一條規則:label 含關鍵字、去頭尾空白、不分大小寫;2026-09-30 自本元件與 Combobox 各一份收回,`../SelectMenu/select-menu.spec.md`「遠端搜尋」段首),遠端搜尋傳 `filterOption={false}` 就不過濾、伺服器回什麼列什麼;搜尋字經 `onSearchChange` 回呼(含關閉時清空),並以受控 `search` 交給 SelectMenu。`suggestions?: SelectOption[]` / `suggestionsLabel?: string`(預設「建議」)/ `searchHintText?: string`(預設「輸入關鍵字搜尋」)三個 prop 機械 forward(2026-09-09):關鍵字空時列建議群組(必有標題)、抓資料中舊清單不顯示、沒建議也沒在載入時顯示提示列;從建議選到的值 `selectedOpt` 同時回查 `options` 與 `suggestions`。SSOT `select-menu.spec.md`「遠端搜尋」「Suggestions」。

---

## 邊界案例

- **搜尋結果空**:dropdown 顯一列 `MenuItem message` 的 `emptyText`(預設「沒有選項」,可覆寫;與 1 筆結果等高、無最小高度、不用 `Empty`)——只在真的沒有任何可選時;遠端搜尋還沒打字是建議群組或「輸入關鍵字搜尋」提示列,不是「沒有選項」。SSOT `select-menu.spec.md`「Empty state」「Suggestions」
- **disabled 選項**:`option.disabled` forward 至 menu item——不可點選,鍵盤導覽自動跳過(cmdk `aria-disabled` 行為)
- **大量選項**:選單固定最大高度內捲動(`--menu-max-height` 預設 300px),無分頁 / 虛擬捲動——長清單開 `searchable`(見「Searchable 開啟判斷」)
- **空值**:無選擇時顯 placeholder;「無選擇是有效狀態」場景開 `clearable`(見「Clearable」)

---

## 禁止事項

- ❌ `startIcon` 不可用於 tag 模式——Tag 本身已有視覺標記，startIcon 是冗餘的
- ❌ 在**觸控裝置**自建 dropdown——手機 / 平板必走原生 `<select>`（平台 picker 的 a11y + 操作體驗最佳）；桌機才走自建 combobox（見「實作：裝置自適應雙路徑」）
- ❌ 讓使用者搞不清楚是即時還是 on-submit——用 label / 按鈕位置明確傳達
- ❌ 把「決策節點」選擇塞進 Select（付款方式、訂閱方案）——使用者需要對比評估，用 RadioGroup

---

## 為何無 StateBehavior

Select 是 **Field Controls family 成員**——互動狀態(focus / invalid / disabled / readonly)完全繼承 `../Field/field-controls.spec.md` SSOT「Mode 狀態」。dropdown 開啟時的 MenuItem hover / selected 狀態由 MenuItem primitive own(`patterns/element-anatomy/item-anatomy.spec.md`)。Select 層級無自有 state 行為。重寫 StateBehavior = 複製 Field Controls + MenuItem SSOT 內容,雙邊漂移風險。

對應 anatomy story:保留 `Overview` + `Inspector` + `ColorMatrix` + `SizeMatrix`。Field-level state 見 Input `StateBehavior` + field-controls.spec.md;item-level state 見 MenuItem `ColorMatrix`。

---

## 相關

- `segmented-control.spec.md` — 2-5 個緊湊互斥切換；「何時不用」的主要去處
- `../Checkbox/checkbox.spec.md`（含 RadioGroup 設計原則）— RadioGroup 共用規則
- `combobox.spec.md` — 多選的對應元件
- `../Switch/switch.spec.md` — 布林切換
- `../Field/field-controls.spec.md` — Select 作為 Field control 時的共用規則（mode、size、endAction）

## A11y 預設

**ARIA / Pattern**:依裝置分兩條路徑。桌機(非觸控)觸發點是容器 `<div>`,標記 `role="combobox"` + `aria-expanded` / `aria-haspopup="listbox"`,選項在浮層 listbox 裡;searchable 模式時容器內另放可打字篩選的 `<input>`(開啟時實際聚焦的元素,帶 `aria-activedescendant` 指向反白的選項,規則 `../SelectMenu/select-menu.spec.md`「A11y 預設」Focus 段;accessible name 直接接在 input 本身:有 Field label 時 `aria-labelledby` 指向之、consumer `aria-label` 優先,兩者皆無時 fallback「搜尋選項」——與 Combobox 搜尋框 `searchAriaLabel` 同 canonical；這顆 input 不寫 `tabIndex`,但它只在開啟時存在,開著按 Tab 由下方 Keyboard 的 Tab 列接管(選定 + 收起 + 走到下一格),所以不會變成第二個 Tab 停靠點 —— 與 Combobox 欄位內搜尋框 `tabIndex=-1`「單一鍵盤聚焦點」同一個結果,2026-10-07 補記)。手機(觸控)改用瀏覽器原生 `<select>` element,直接取得作業系統內建的無障礙與 picker。兩路徑皆由 Field wrapper 補 `aria-invalid` / `aria-required` / `aria-describedby` / `aria-errormessage`。

**Keyboard 行為**:

- Tab — 聚焦到觸發點
- Enter / Space — 展開選單(searchable 模式則直接進入打字篩選)
- ↓ — 選單關閉時亦可直接展開(APG combobox 展開鍵,與 Combobox 同 pattern;展開後不攔,讓方向鍵導覽選單)
- ↑ / ↓ — 選單展開後在選項間移動
- Tab / Shift+Tab(選單展開時,searchable 與否皆同)— 選定反白那一項 → 收起 → 焦點落到觸發點的下一個 / 上一個可 Tab 元素(= 選單關著時從觸發點按 Tab / Shift+Tab 會到的那一格;在對話框 / 小面板裡則只在那一層裡走、到邊緣繞回)。2026-09-25 前(實測):不可打字時 Tab 卡在浮層裡或落到頁面外、Shift+Tab 跳到頁尾,都不選定;可打字時 Tab 收起但不選定、Shift+Tab 停在觸發點本身且選單不關。W3C 出處與逐字規則見 `../SelectMenu/select-menu.spec.md`「A11y 預設」(單選那一條);來源 = 待辦總帳 B11
- Esc — 關閉選單、不選定(清除值走右側 clear 按鈕,非 Esc);按過欄位上的東西(清除 ×、再點一下搜尋框)之後按 Esc 收起,焦點同樣回觸發點、不掉到頁面上(2026-10-07,`../SelectMenu/select-menu.spec.md`「A11y 預設」Focus 段「指標按在觸發欄位上不算按在外面」)
- 字母鍵(searchable,焦點在觸發點本身、選單關著:Tab 進來、Esc 收起、選完 / 清空之後)— 打開選單,這個字進搜尋框;輸入法第一鍵同樣(2026-10-07 待辦總帳 K3,規則住 `../SelectMenu/select-menu.spec.md`「A11y 預設」Keyboard 段)
- Backspace(searchable + clearable,關鍵字空白)— 清掉值,同按清除 ×(見上方「Clearable」)

**Focus**:Field 家族的焦點指示 = 邊框轉主色,**不分開著關著、不分滑鼠鍵盤**(owner = `ds-canonical/references/focus-canonical.md` 規則二「Field 家族控件本身」列 + 「問題一之二」C 類;2026-09-10 第二次更正:上午先寫成「關閉時鍵盤模態再加全域外框」,下午依一致性收斂 —— Combobox 焦點留在輸入框本來就沒有外框,Select 類關閉後焦點回 wrapper 若再疊外框就是同一家族兩種長相)。**開啟時**焦點在搜尋輸入框(插入點控件;滑鼠點選項與 `Enter` 相同,收起前焦點不離開它,`../SelectMenu/select-menu.spec.md`「A11y 預設」Focus 段)→ Field wrapper 邊框轉色;**關閉時**觸發器本身是焦點站(`tabIndex=0`,選完 / Esc 後 Radix 把焦點還給它;按 Tab 收起時焦點直接走到下一格,不回觸發器)→ 同樣只有邊框轉色,全域 `:focus-visible` 外框由 `fieldWrapperStyles` 的 `focus-visible:outline-none` 抑制。手機原生 `<select>` 另有系統 focus ring。閘:`virtual-cursor-modality-invariant.mjs` G 段(Select / SelectMenu / PeoplePicker)、H 段(DatePicker / TimePicker / Combobox 觸發器)。

**驗證**:Storybook a11y addon panel 應 0 critical violation;鍵盤完整可操作(無需滑鼠)。WCAG AA contrast ≥ 4.5:1(text)/ 3:1(UI)。

## 被引用(auto-maintained,Dim 3 reciprocal audit)

> 本節由 `scripts/add-reciprocal-pointers.mjs` 自動維護,列出在 SSOT 語境下指向本 spec 的其他 spec。若要手動補充,寫在本節之前。

- `checkbox.spec.md`
- `combobox.spec.md`
- `people-picker.spec.md`
- `radio-group.spec.md`
- `select-menu.spec.md`
- `uiSize.spec.md`
